-- phpMyAdmin SQL Dump
-- version 3.2.5
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: May 04, 2011 at 08:58 AM
-- Server version: 5.1.44
-- PHP Version: 5.3.2

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `danielmall_v3_ee2`
--

-- --------------------------------------------------------

--
-- Table structure for table `exp_accessories`
--

CREATE TABLE `exp_accessories` (
  `accessory_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(75) NOT NULL DEFAULT '',
  `member_groups` varchar(50) NOT NULL DEFAULT 'all',
  `controllers` text,
  `accessory_version` varchar(12) NOT NULL,
  PRIMARY KEY (`accessory_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `exp_accessories`
--

INSERT INTO `exp_accessories` VALUES(1, 'Expressionengine_info_acc', '1|5', 'addons|addons_accessories|addons_extensions|addons_fieldtypes|addons_modules|addons_plugins|admin_content|admin_system|content|content_edit|content_files|content_publish|design|homepage|members|myaccount|tools|tools_communicate|tools_data|tools_logs|tools_utilities', '1.0');
INSERT INTO `exp_accessories` VALUES(2, 'Nsm_morphine_theme_acc', '1|5', 'addons|addons_accessories|addons_extensions|addons_fieldtypes|addons_modules|addons_plugins|admin_content|admin_system|content|content_edit|content_files|content_publish|design|homepage|members|myaccount|tools|tools_communicate|tools_data|tools_logs|tools_utilities', '1.0.0');

-- --------------------------------------------------------

--
-- Table structure for table `exp_actions`
--

CREATE TABLE `exp_actions` (
  `action_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(50) NOT NULL,
  `method` varchar(50) NOT NULL,
  PRIMARY KEY (`action_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=23 ;

--
-- Dumping data for table `exp_actions`
--

INSERT INTO `exp_actions` VALUES(1, 'Comment', 'insert_new_comment');
INSERT INTO `exp_actions` VALUES(2, 'Comment_mcp', 'delete_comment_notification');
INSERT INTO `exp_actions` VALUES(3, 'Mailinglist', 'insert_new_email');
INSERT INTO `exp_actions` VALUES(4, 'Mailinglist', 'authorize_email');
INSERT INTO `exp_actions` VALUES(5, 'Mailinglist', 'unsubscribe');
INSERT INTO `exp_actions` VALUES(6, 'Member', 'registration_form');
INSERT INTO `exp_actions` VALUES(7, 'Member', 'register_member');
INSERT INTO `exp_actions` VALUES(8, 'Member', 'activate_member');
INSERT INTO `exp_actions` VALUES(9, 'Member', 'member_login');
INSERT INTO `exp_actions` VALUES(10, 'Member', 'member_logout');
INSERT INTO `exp_actions` VALUES(11, 'Member', 'retrieve_password');
INSERT INTO `exp_actions` VALUES(12, 'Member', 'reset_password');
INSERT INTO `exp_actions` VALUES(13, 'Member', 'send_member_email');
INSERT INTO `exp_actions` VALUES(14, 'Member', 'update_un_pw');
INSERT INTO `exp_actions` VALUES(15, 'Member', 'member_search');
INSERT INTO `exp_actions` VALUES(16, 'Member', 'member_delete');
INSERT INTO `exp_actions` VALUES(21, 'Channel', 'smiley_pop');
INSERT INTO `exp_actions` VALUES(18, 'Channel', 'insert_new_entry');
INSERT INTO `exp_actions` VALUES(19, 'Search', 'do_search');
INSERT INTO `exp_actions` VALUES(20, 'Jquery', 'output_javascript');
INSERT INTO `exp_actions` VALUES(22, 'Channel', 'filemanager_endpoint');

-- --------------------------------------------------------

--
-- Table structure for table `exp_captcha`
--

CREATE TABLE `exp_captcha` (
  `captcha_id` bigint(13) unsigned NOT NULL AUTO_INCREMENT,
  `date` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `word` varchar(20) NOT NULL,
  PRIMARY KEY (`captcha_id`),
  KEY `word` (`word`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_captcha`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_categories`
--

CREATE TABLE `exp_categories` (
  `cat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(6) unsigned NOT NULL,
  `parent_id` int(4) unsigned NOT NULL,
  `cat_name` varchar(100) NOT NULL,
  `cat_url_title` varchar(75) NOT NULL,
  `cat_description` text,
  `cat_image` varchar(120) DEFAULT NULL,
  `cat_order` int(4) unsigned NOT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `group_id` (`group_id`),
  KEY `cat_name` (`cat_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `exp_categories`
--

INSERT INTO `exp_categories` VALUES(4, 1, 1, 0, 'Flash', 'flash', '', '', 3);
INSERT INTO `exp_categories` VALUES(3, 1, 1, 0, 'Personal', 'Personal', '', '', 4);
INSERT INTO `exp_categories` VALUES(5, 1, 1, 0, 'Conferences', 'conferences', '', '', 1);
INSERT INTO `exp_categories` VALUES(6, 1, 1, 0, 'Design', 'design', '', '', 2);
INSERT INTO `exp_categories` VALUES(7, 1, 1, 0, 'Typography', 'typography', '', '', 5);
INSERT INTO `exp_categories` VALUES(8, 1, 2, 0, 'flash', 'flash', '', '', 4);
INSERT INTO `exp_categories` VALUES(9, 1, 2, 0, 'css', 'css', '', '', 2);
INSERT INTO `exp_categories` VALUES(10, 1, 2, 0, 'html', 'html', '', '', 5);
INSERT INTO `exp_categories` VALUES(11, 1, 2, 0, 'design', 'design', '', '', 3);
INSERT INTO `exp_categories` VALUES(12, 1, 2, 0, 'typography', 'typography', '', '', 7);
INSERT INTO `exp_categories` VALUES(13, 1, 2, 0, 'industry', 'industry', '', '', 6);
INSERT INTO `exp_categories` VALUES(14, 1, 2, 0, 'conferences', 'conferences', '', '', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exp_category_fields`
--

CREATE TABLE `exp_category_fields` (
  `field_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(4) unsigned NOT NULL,
  `field_name` varchar(32) NOT NULL DEFAULT '',
  `field_label` varchar(50) NOT NULL DEFAULT '',
  `field_type` varchar(12) NOT NULL DEFAULT 'text',
  `field_list_items` mediumtext NOT NULL,
  `field_maxl` smallint(3) NOT NULL DEFAULT '128',
  `field_ta_rows` tinyint(2) NOT NULL DEFAULT '8',
  `field_default_fmt` varchar(40) NOT NULL DEFAULT 'none',
  `field_show_fmt` char(1) NOT NULL DEFAULT 'y',
  `field_text_direction` char(3) NOT NULL DEFAULT 'ltr',
  `field_required` char(1) NOT NULL DEFAULT 'n',
  `field_order` int(3) unsigned NOT NULL,
  PRIMARY KEY (`field_id`),
  KEY `site_id` (`site_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_category_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_category_field_data`
--

CREATE TABLE `exp_category_field_data` (
  `cat_id` int(4) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(4) unsigned NOT NULL,
  PRIMARY KEY (`cat_id`),
  KEY `site_id` (`site_id`),
  KEY `group_id` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_category_field_data`
--

INSERT INTO `exp_category_field_data` VALUES(5, 1, 1);
INSERT INTO `exp_category_field_data` VALUES(4, 1, 1);
INSERT INTO `exp_category_field_data` VALUES(3, 1, 1);
INSERT INTO `exp_category_field_data` VALUES(6, 1, 1);
INSERT INTO `exp_category_field_data` VALUES(7, 1, 1);
INSERT INTO `exp_category_field_data` VALUES(8, 1, 2);
INSERT INTO `exp_category_field_data` VALUES(9, 1, 2);
INSERT INTO `exp_category_field_data` VALUES(10, 1, 2);
INSERT INTO `exp_category_field_data` VALUES(11, 1, 2);
INSERT INTO `exp_category_field_data` VALUES(12, 1, 2);
INSERT INTO `exp_category_field_data` VALUES(13, 1, 2);
INSERT INTO `exp_category_field_data` VALUES(14, 1, 2);

-- --------------------------------------------------------

--
-- Table structure for table `exp_category_groups`
--

CREATE TABLE `exp_category_groups` (
  `group_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_name` varchar(50) NOT NULL,
  `sort_order` char(1) NOT NULL DEFAULT 'a',
  `field_html_formatting` char(4) NOT NULL DEFAULT 'all',
  `can_edit_categories` text,
  `can_delete_categories` text,
  `is_user_blog` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `exp_category_groups`
--

INSERT INTO `exp_category_groups` VALUES(1, 1, 'Default Category Group', 'a', 'all', '', '', 'n');
INSERT INTO `exp_category_groups` VALUES(2, 1, 'article', 'a', 'all', '', '', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `exp_category_posts`
--

CREATE TABLE `exp_category_posts` (
  `entry_id` int(10) unsigned NOT NULL,
  `cat_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`entry_id`,`cat_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_category_posts`
--

INSERT INTO `exp_category_posts` VALUES(2, 12);
INSERT INTO `exp_category_posts` VALUES(3, 9);
INSERT INTO `exp_category_posts` VALUES(4, 14);
INSERT INTO `exp_category_posts` VALUES(5, 10);
INSERT INTO `exp_category_posts` VALUES(5, 11);
INSERT INTO `exp_category_posts` VALUES(7, 9);
INSERT INTO `exp_category_posts` VALUES(7, 10);

-- --------------------------------------------------------

--
-- Table structure for table `exp_channels`
--

CREATE TABLE `exp_channels` (
  `channel_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_name` varchar(40) NOT NULL,
  `channel_title` varchar(100) NOT NULL,
  `channel_url` varchar(100) NOT NULL,
  `channel_description` varchar(225) DEFAULT NULL,
  `channel_lang` varchar(12) NOT NULL,
  `total_entries` mediumint(8) NOT NULL DEFAULT '0',
  `total_comments` mediumint(8) NOT NULL DEFAULT '0',
  `last_entry_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `cat_group` varchar(225) DEFAULT NULL,
  `status_group` int(4) unsigned DEFAULT NULL,
  `deft_status` varchar(50) NOT NULL DEFAULT 'open',
  `field_group` int(4) unsigned DEFAULT NULL,
  `search_excerpt` int(4) unsigned DEFAULT NULL,
  `deft_category` varchar(60) DEFAULT NULL,
  `deft_comments` char(1) NOT NULL DEFAULT 'y',
  `channel_require_membership` char(1) NOT NULL DEFAULT 'y',
  `channel_max_chars` int(5) unsigned DEFAULT NULL,
  `channel_html_formatting` char(4) NOT NULL DEFAULT 'all',
  `channel_allow_img_urls` char(1) NOT NULL DEFAULT 'y',
  `channel_auto_link_urls` char(1) NOT NULL DEFAULT 'y',
  `channel_notify` char(1) NOT NULL DEFAULT 'n',
  `channel_notify_emails` varchar(255) DEFAULT NULL,
  `comment_url` varchar(80) DEFAULT NULL,
  `comment_system_enabled` char(1) NOT NULL DEFAULT 'y',
  `comment_require_membership` char(1) NOT NULL DEFAULT 'n',
  `comment_use_captcha` char(1) NOT NULL DEFAULT 'n',
  `comment_moderate` char(1) NOT NULL DEFAULT 'n',
  `comment_max_chars` int(5) unsigned DEFAULT '5000',
  `comment_timelock` int(5) unsigned NOT NULL DEFAULT '0',
  `comment_require_email` char(1) NOT NULL DEFAULT 'y',
  `comment_text_formatting` char(5) NOT NULL DEFAULT 'xhtml',
  `comment_html_formatting` char(4) NOT NULL DEFAULT 'safe',
  `comment_allow_img_urls` char(1) NOT NULL DEFAULT 'n',
  `comment_auto_link_urls` char(1) NOT NULL DEFAULT 'y',
  `comment_notify` char(1) NOT NULL DEFAULT 'n',
  `comment_notify_authors` char(1) NOT NULL DEFAULT 'n',
  `comment_notify_emails` varchar(255) DEFAULT NULL,
  `comment_expiration` int(4) unsigned NOT NULL DEFAULT '0',
  `search_results_url` varchar(80) DEFAULT NULL,
  `ping_return_url` varchar(80) DEFAULT NULL,
  `show_button_cluster` char(1) NOT NULL DEFAULT 'y',
  `rss_url` varchar(80) DEFAULT NULL,
  `enable_versioning` char(1) NOT NULL DEFAULT 'n',
  `max_revisions` smallint(4) unsigned NOT NULL DEFAULT '10',
  `default_entry_title` varchar(100) NOT NULL,
  `url_title_prefix` varchar(80) NOT NULL,
  `live_look_template` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`channel_id`),
  KEY `cat_group` (`cat_group`),
  KEY `status_group` (`status_group`),
  KEY `field_group` (`field_group`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `exp_channels`
--

INSERT INTO `exp_channels` VALUES(1, 1, 'default_site', 'Default Site Weblog', 'http://dan.local:8888/index.php/site/index/', '', 'en', 0, 0, 0, 0, '1', 1, 'open', 1, 2, '', 'y', 'y', 0, 'all', 'y', 'y', 'n', '', 'http://dan.local:8888/index.php/site/comments/', 'y', 'n', 'n', 'n', 5000, 0, 'y', 'xhtml', 'safe', 'n', 'y', 'n', 'n', '', 0, 'http://dan.local:8888/index.php/site/comments/', 'http://dan.local:8888/index.php', 'y', '', 'n', 10, '', '', 0);
INSERT INTO `exp_channels` VALUES(2, 1, 'articles', 'Articles', 'http://dan.local:8888/index.php', '', 'en', 3, 4, 1279496603, 1280402031, '2', 2, 'draft', 2, 5, '', 'y', 'y', 0, 'all', 'y', 'y', 'n', '', '', 'y', 'n', 'n', 'n', 0, 0, 'y', 'xhtml', 'safe', 'n', 'y', 'n', 'n', '', 0, '', '', 'n', '', 'n', 10, '', '', 39);
INSERT INTO `exp_channels` VALUES(4, 1, 'work', 'Work', 'http://dan.local:8888/work/', '', 'en', 18, 0, 1304508068, 0, NULL, NULL, 'draft', 4, NULL, '', 'y', 'y', NULL, 'all', 'y', 'y', 'n', '', '', 'y', 'n', 'n', 'n', 5000, 0, 'y', 'xhtml', 'safe', 'n', 'y', 'n', 'n', '', 0, '', '', 'y', '', 'n', 10, '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exp_channel_data`
--

CREATE TABLE `exp_channel_data` (
  `entry_id` int(10) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL,
  `field_id_1` text,
  `field_ft_1` text,
  `field_id_2` text,
  `field_ft_2` text,
  `field_id_3` text,
  `field_ft_3` text,
  `field_id_4` text,
  `field_ft_4` text,
  `field_id_5` text,
  `field_ft_5` text,
  `field_id_7` text,
  `field_ft_7` tinytext,
  `field_id_11` text,
  `field_ft_11` tinytext,
  `field_id_12` text,
  `field_ft_12` tinytext,
  `field_id_13` text,
  `field_ft_13` tinytext,
  `field_id_15` text,
  `field_ft_15` tinytext,
  `field_id_16` text,
  `field_ft_16` tinytext,
  `field_id_17` text,
  `field_ft_17` tinytext,
  PRIMARY KEY (`entry_id`),
  KEY `weblog_id` (`channel_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_channel_data`
--

INSERT INTO `exp_channel_data` VALUES(1, 1, 1, '', 'xhtml', '	Thank you for choosing ExpressionEngine! This entry contains helpful resources to help you <a href="http://expressionengine.com/docs/overview/get_most.html">get the most from ExpressionEngine</a> and the EllisLab Community.\n\n	[b]Technical Support:[/b]\n\n	All tech support is handled through our Community forums. Our staff and the community respond to issues in a timely manner. Please review the <a href="http://expressionengine.com/docs/overview/getting_help.html">Getting Help</a> section of the User Guide before posting in the forums.\n\n	[b]Learning resources:[/b]\n\n	<a href="http://expressionengine.com/docs/overview/">Getting Started Guide</a>\n	<a href="http://expressionengine.com/docs/quick_start/">Quick Start Tutorial</a>\n	<a href="http://expressionengine.com/tutorials/">Video Tutorials</a>\n\n	[b]Additional Support Resources:[/b]\n\n	<a href="http://expressionengine.com/docs/">ExpressionEngine User Guide</a>\n	<a href="http://expressionengine.com/knowledge_base/">Knowledge Base</a>\n	<a href="http://expressionengine.com/wiki/">ExpressionEngine Wiki</a>\n\n	If you need to hire a web developer consider our <a href="http://expressionengine.com/professionals/">Professionals Network</a>. You can also place an ad on our <a href="http://expressionengine.com/forums/viewforum/47/">Job Board</a> if you prefer that professionals find you.\n\n	Love ExpressionEngine?  Help spread the word and make some spare change with our <a href="http://expressionengine.com/affiliates/">Affiliates program</a>.\n\n	See you on the boards,\n\n	[size=4]The EllisLab Team[/size]', 'xhtml', '', 'xhtml', '', 'none', '', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(2, 1, 2, '', NULL, '', NULL, '', NULL, 'This is the main body of article one! This is the main body of article one! This is the main body of article one! This is the main body of article one! This is the main body of article one! This is the main body of article one! This is the main body of article one! This is the main body of article one! ', 'none', '<p>Excerpt 1, baby!</p>', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(3, 1, 2, '', NULL, '', NULL, '', NULL, 'Article 2. Muah ha ha. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'none', '<p>The second article.</p>', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(4, 1, 2, '', NULL, '', NULL, '', NULL, 'Article link 3. Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.', 'none', '<p>Article 3, except that it''s <a href="http://google.com/">a link</a>.</p>', 'none', '', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(5, 1, 2, '', NULL, '', NULL, '', NULL, '<div id="split">\n    \n    <div id="one">\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. <a href="#">Duis aute irure dolor</a> in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n</div>\n\n<div id="two">\n\n<p>Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.</p>\n\n</div>\n</div>', 'none', '<p>Fourth article excerpt.</p>', 'none', '<style>\n\n#article-area { background: #000; color: #fff; padding: 6em 0 3em; }\n#article-area a:link, .comment-list header h1 a:link { color: red; }\n#split { width: 800px; margin: 0 auto; }\n#one { width: 400px; float: left; }\n#two { width: 300px; margin-left: 300px; }\n\n</style>\n', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(7, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, '', 'none', '<p>Joseph Huckaby takes  Mark Ferrari&rsquo;s original <cite>Monkey Island</cite> art  and <a href="http://www.effectgames.com/effect/article.psp.html/joe/Old_School_Color_Cycling_with_HTML5">reproduces it with <abbr title="Hypertext Markup Language">HTML</abbr>5</a>.</p>', 'none', '', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(8, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, '<p><a href="http;//ohlife.com/">OhLife</a> is a personal journal you&rsquo;ll love to use. &ldquo;Every night we&rsquo;ll email you the question &lsquo;How did your day go?&rsquo; Just reply with your entry and it&rsquo;s saved here instantly.&rdquo;</p>', 'none', '<p><a href="http;//ohlife.com/">OhLife</a> is a personal journal you&rsquo;ll love to use. &ldquo;Every night we&rsquo;ll email you the question &lsquo;How did your day go?&rsquo; Just reply with your entry and it&rsquo;s saved here instantly.&rdquo;</p>', 'none', '', 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(10, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'A shared commitment to better health for more people. Together.', 'none', '<style>\n    .page-title { background-image: url(/assets/work/healthymagination/healthymagination.png); width: 586px; height: 58px; }\n    #project-header hgroup { top: 20px; } \n\n    .project-image { height: 1652px; background: transparent url(/assets/work/healthymagination/healthymagination-hero2.jpg) no-repeat center 0; }\n    .project-url { left: -70px; top: 33px; }\n    \n    #awards { background: transparent url(/assets/work/healthymagination/healthymagination-awards.png) no-repeat 0 0; height: 265px; }\n        #wordpress a { width: 192px; height: 50px; top: 135px; left: 0; }\n        #clio a { width: 126px; height: 63px; top: 133px; left: 248px; }\n        #commarts a { width: 197px; height: 56px; top: 130px; left: 608px; }\n        #creativity a { width: 114px; height: 68px; top: 129px; left: 431px; }\n\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://healthymagination.com/">http://healthymagination.com/</a></div>\n</div>\n\n       \n<section id="work-content">\n\n    <div class="wrap">\n    \n    <section id="awards">\n        \n        <h1 class="phark">Awards &amp; Recognition</h1>\n        \n        <ul>\n            <li id="wordpress"><a class="phark phark-link" href="http://wordpress.org/showcase/healthymagination/">WordPress</a></li>\n            <li id="clio"><a class="phark phark-link" href="http://www.cliohealthcare.com/winners/winners.cfm?medium_id=7">Clio Awards</a></li>\n            <li id="creativity"><a class="phark phark-link" href="http://creativity-online.com/work/general-electric-healthymagination/18932">Creativity</a></li>\n            <li id="commarts"><a class="phark phark-link" href="http://www.commarts.com/web-sites/healthymagination.html">Communication Arts</a></li>\n        </ul>\n        \n    </section>\n\n        <div class="main">\n\n            <p><abbr title="General Electric">GE</abbr> approached Big Spaceship with an unusual question: how can we get people to think about their health in a more positive way? We brainstormed for months about the possibilities, and came to a few important realizations: </p>\n    \n            <ol>\n                <li>We only think about their health when things go wrong, like when we get hurt or need an emergency procedure. This makes us view health as a negative topic.</li>\n                <li>We want to make healthy choices, but it&rsquo;s often difficult to do so.</li>\n            </ol>\n\n            <p>To that end, our task was to create ways that <abbr>GE</abbr> could empower consumers to be healthier, and feel good about it. Coinciding with the 2010 Winter Olympics, we created a number of platforms and partnerships, including an app called <a href="/work/morsel/">Morsel</a>, the <a href="http://www.webmd.com/a-to-z-guides/health-a-z-tools/better-health-conversation/default.htm">Better Health Evaluator with WebMD</a>, a <a href="http://info.howcast.com/physicalchallenge">video series</a> with <a href="http://www.howcast.com/">Howcast</a>, and a media buy called <a href="http://www.healthymagination.com/sharingideas/">Sharing Healthy Ideas</a>, among other things.</p>\n\n            <p>Healthymagination.com became the hub that housed these initiatives and gave people a centralized way to view the whole ecosystem.</p>\n\n        </div><!-- .main -->\n\n        <div class="sub">\n\n            <h2>Client</h2>\n            <p>General Electric</p>\n    \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>Strategy</li>\n            </ul>\n    \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://bigspaceship.com/">Michael Lebowitz</a>&mdash;Creative Direction</li>\n                <li><a href="http://www.ivanaskwith.com/">Ivan Askwith</a>&mdash;Strategy</li>\n                <li><a href="http://www.christophercocca.com/">Chris Cocca</a>&mdash;Strategy, <abbr title="User Experience">UX</abbr>, and <abbr title="Information Architecture">IA</abbr></a>\n                <li><a href="http://foughtthebattle.tumblr.com/">Josh Teixeira</a>&mdash;Content Strategy</li>\n                <li><a href="http://www.danielscheibel.com/">Daniel Scheibel</a>&mdash;Development &amp; Strategy</li>\n                <li>Ranae Heuer&mdash;Production &amp; Account Management</li>\n            </ul>\n    \n            <h2>Agency</h2>\n            <p><a href="http://bigspaceship.com/">Big Spaceship</a></p>\n    \n            <h2>Year</h2>\n            <p>2010</p>\n    \n            <h2>Live Site</h2>\n            <p><a href="http://healthymagination.com/">healthymagination</a></p>\n    \n        </div><!-- .sub -->\n    \n    <div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/design-swap/">Design Swap</a>', 'none', '', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(11, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '', 'none', '<style>\n.page-title { background-image: url(/assets/work/doghouse/doghouse.png); width: 504px; height: 90px; }\n</style>', 'none', '<p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n<p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>', 'none', NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(12, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'A Day in the Life of Brian Hoff', 'none', '<style>\n\n    .page-title { background-image: url(/assets/work/design-swap/design-swap.png); width: 567px; height: 85px; }\n    #project-header hgroup { top: 4px; }  \n\n    .project-image { height: 1162px; height: 532px; background: transparent url(/assets/work/design-swap/design-swap-hero3.jpg) no-repeat center 0; /*margin-bottom: -160px;*/ }\n    .project-url { left: 176px; top: 25px; left: 105px; top: 33px; }\n    h2 ins { background: none; color: #aaa; }\n\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://design-swap.danielmall.com/">http://design-swap.danielmall.com/</a></div>\n</div>\n\n<section id="work-content" class="wrap">\n\n    <div class="main">\n\n        <p>Just after <abbr title="South by Southwest">SXSW</abbr> 2010, <a href="http://yaronschoen.com/">Yaron Schoen</a> and <a href="http://trentwalton.com/">Trent Walton</a> started a little side project called <a href="http://design-swap.com/">Design Swap</a> to facilitate collaboration between designers. I was fortunate enough to be invited to participate as the next installment.</p> \n\n        <p>When asked if I had a particular person I&rsquo;d like to pair up with, I mentioned <a href="http://behoff.net/">Brian Hoff</a> because I&rsquo;d never met him. Yaron mentioned that Brian chose me too, so it seemed the stars were aligned. Since Brian and I didn&rsquo;t know each other aside from a few tweets and emails, we decided to use the opportunity to change that. After a few phone calls to brainstorm, we arrived at the idea of compulsively tracking everything we did for a full day, then giving the other carte blanche to do whatever he saw fit with the data. The only restriction was that the execution must look like it was designed by the other person.</p>\n\n        <p>Using the design direction of Brian&rsquo;s site&mdash;<a href="http://www.thedesigncubicle.com/">The Design Cubicle</a>&mdash;I presented his day in 3 views: a random view that displayed one illustrated and animated portion of Brian''s day, a chronological view that organized his daily activities against an analog clock (made entirely with CSS!), and a statistical view that charted objects from Brian&rsquo;s day.</p>\n\n        <p>All in all, I consider the exercise a huge success. It was my first opportunity to get my feet wet with HTML5, and I made a great friend in Brian through the process. (Cue sappy music&hellip;)</p>\n    \n    </div><!-- .main -->\n    \n    <div class="sub">\n    \n        <h2>Client</h2>\n        <ul>\n            <li><a href="http://design-swap.com/">Design Swap</a></li>\n            <li><a href="http://yaronschoen.com/">Yaron Schoen</a></li>\n            <li><a href="http://trentwalton.com/">Trent Walton</a></li>\n        </ul>\n        \n        <h2>Role</h2>\n        <ul>\n            <li>Design</li>\n            <li>Animation</li>\n            <li>Development</li>\n        </ul>\n        \n        <h2><del>Mortal Enemy</del> <ins>BFF</ins></h2>\n        <p><a href="http://thedesigncubicle.com/">Brian Hoff</a></p>        \n        \n        <h2>Year</h2>\n        <p>2010</p>\n        \n        <h2>Status</h2>\n        <p><a href="http://design-swap.danielmall.com/">A Day in the Life of Brian Hoff</a></p>\n        \n    </div><!-- .sub -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/morsel/">Morsel</a>', 'none', '<a href="/work/detail/healthymagination/">healthymagination</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(13, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'War for Cybertron: Teaser Pitch', 'none', '<style>\n    .page-title { background-image: url(/assets/work/transformers/transformers.png); width: 582px; height: 61px; }\n    #project-header hgroup { top: 10px; }\n\n    .project-image { height: 600px; background: transparent url(/assets/work/transformers/transformers-hero.jpg) no-repeat center 0; margin-bottom: 0; }\n</style>', 'none', '<div class="project-image"></div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Activision Blizzard</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <p><a href="http://bigspaceship.com/">Michael Lebowitz</a>&mdash;Creative Direction</p>        \n        \n            <h2>Year</h2>\n            <p>2010</p>\n        \n            <h2>Agency</h2>\n            <p><a href="http://bigspaceship.com/">Big Spaceship</a></p>\n        \n            <h2>Status</h2>\n            <p>Unsold</p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/typedia/">Typedia</a>', 'none', '<a href="/work/detail/always-beautiful/">Always Beautiful</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(14, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Science for the Benefit of Humanity', 'none', '<style>\n    .page-title { background-image: url(/assets/work/weizmann/weizmann.png); width: 558px; height: 80px; }\n\n    .project-image { height: 535px; background: transparent url(/assets/work/weizmann/weizmann-hero.jpg) no-repeat center 0; margin-bottom: 0; margin-top: -40px; }\n    .project-url { left: 135px; top: 69px;  }\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://weizmann-usa.org/">http://weizmann-usa.org/</a></div>\n</div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>American Committee for the Weizmann Institute of Science</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>Animation</li>\n                <li>Front-end Development</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://blog.damian-atkinson.com/">Damian Atkinson</a>&mdash;Design, Animation</li>\n                <li><a href="http://www.rachelhnash.com/">Rachel Nash</a>&mdash;Design</li>\n                <li><a href="http://mattkenefick.com/">Matt Kenefick</a>&mdash;Development</li>\n                <li><a href="http://danielscheibel.com/">Daniel Scheibel</a>&mdash;Development</li>\n                <li><a href="http://www.bbojko.de/">Benjamin Bojko</a>&mdash;Flash Development</li>\n                <li>Shannon Heuer&mdash;Production</li>\n                <li><a href="http://gilbertyeh.com/">Gil Yeh</a>&mdash;Information Architecture</li>\n            </ul>\n        \n            <h2>Year</h2>\n            <p>2010</p>\n        \n            <h2>Agency</h2>\n            <p><a href="http://bigspaceship.com/">Big Spaceship</a></p>\n        \n            <h2>Live Site</h2>\n            <p><a href="http://weizmann-usa.org/">Science for the Benefit of Humanity</a></p>\n        \n        </div><!-- .sub -->\n    \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/preventiv/">Pr&eacute;ventiv Water</a>', 'none', '<a href="/work/detail/typedia/">Typedia</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(15, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Heart Healthy Water with No Carbs or Sugars', 'none', '<style>\n.page-title { background-image: url(/assets/work/preventiv/preventiv.png); width: 599px; height: 57px; }\n#project-header hgroup { top: 18px; }\n\n    .project-image { height: 522px; background: transparent url(/assets/work/preventiv/preventiv-hero.jpg) no-repeat center 0 }\n\n</style>', 'none', '<div class="project-image"></div>\n        \n<section id="work-content">\n\n    <div class="wrap">\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Preventive Beverages, LLC.</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://chriscashdollar.com/">Chris Cashdollar</a>, Design</li>\n                <li><a href="http://kevinsharon.com/">Kevin Sharon</a>, Design</li>\n            </ul>\n        \n            <h2>Agency</h2>\n            <p><a href="http://happycog.com/">Happy Cog</a></p>\n        \n            <h2>Year</h2>\n            <p>2009</p>\n        \n            <h2>Status</h2>\n            <p>No longer online</p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/four24/">Four24</a>', 'none', '<a href="/work/detail/weizmann/">American Committee for the Weizmann Institute of Science</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(16, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'A Philadelphia-Based Contemporary-Christian Praise & Worship Band', 'none', '<style>\n.page-title { background-image: url(/assets/work/four24/four24.png); width: 515px; height: 110px; }\n\n    .project-image { height: 736px; background: transparent url(/assets/work/four24/four24-hero2.jpg) no-repeat center 0; margin-bottom: 0; }\n.project-url { left: 205px; top: 27px; }\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://four24.com/">http://four24.com/</a></div>\n</div>\n\n<section id="work-content" class="wrap">\n\n        <div class="main">\n\n            <p>I&rsquo;ve been playing keyboards and singing with Philadelphia-based contemporary Christian band Four24 since 2005. As a long-standing member of the band, I have the privilege of owning a piece of the brand and helping to shape the direction it moves. </p>\n\n            <p>The group itself has changed in many  ways. Starting as a 4-part harmony a capella group in 1999, it has evolved into a 9-man full band: 4 vocalists, 3 keyboardists, a guitarist, a bass player, and a drummer. Fittingly, I&rsquo;ve been responsible for evolving the band&rsquo;s aesthetic as its feel changes. From soulful and smooth to alternative and a bit raw, I&rsquo;m having a ton of fun providing creative direction that extends to many executions like CD artwork, websites, print material, identity, business cards, and more.</p> \n            \n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Four24</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Creative Direction</li>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>Animation</li>\n                <li>Development</li>\n            </ul>\n                \n            <h2>Years</h2>\n            <p>2004&ndash;present</p>        \n    \n            <h2>Live Site</h2>\n            <p><a href="http://four24.com/">Four24</a></p>\n        \n        </div><!-- .sub -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/mica/">Maryland Institute College of Art</a>', 'none', '<a href="/work/detail/preventiv/">Pr&acute;ventiv Water</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(17, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'An art school that shows art on its website. Imagine that!', 'none', '<style>\n    .page-title { background-image: url(/assets/work/mica/mica.png); width: 381px; height: 96px; }\n\n    .project-image { height: 478px; background: transparent url(/assets/work/mica/mica-hero.jpg) no-repeat center 0; margin-bottom: 0; }\n    .project-url { left: 177px; top: 19px; font-size: 9px; }\n\n    #work-content { background-position: 50% 0; min-width: 800px; }\n        #work-content .wrap { padding-top: 396px; position: relative; }\n    \n    #work-area-wrap #pullquote { background: #fff url(/assets/work/mica/mica-quote.png) no-repeat 0 0; height: 396px; position: relative; left: -6px; width: 807px; position: absolute; top: 0; }\n    \n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://mica.edu/">http://mica.edu/</a></div>\n</div>\n\n<section id="work-content">\n\n    <div class="wrap">\n    \n        <blockquote id="pullquote" class="phark">\n            <p>Working with Dan on the MICA website was a transformative experience for me. Dan opened my mind to solving front-end design challenges from a framework of design values as opposed to solving them by relying on expertise in a particular technology (<abbr title="eXtensible HyperText Markup Language">XHTML</abbr>, <abbr title="Cascading Style Sheets">CSS</abbr>, Flash, etc.). The dangers of stagnating in any of those waters is that you aren’t addressing the real problem, which is how the design supports and enhances the experience. At the end of the day, amazing things are possible with web standards, but those amazing things are created and discovered from a place of design thinking and creativity, and not inside a WC3 validator. Dan embodies this philosophy.</p>\n            <p><cite>Kevin Hoffman, Director of Web and Electronic Communications, MICA</cite></p>\n        </blockquote>\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n\n            <p>You can read <a href="http://heathershaw.com/mica.php">Heather&rsquo;s take on the project</a> as well as <a href="http://happycog.com/create/mica/">Happy Cog&rsquo;s case study</a>.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Maryland Institute College of Art</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Front-End Development</li>\n                <li>Flash Development</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <ul>                \n                <li><a href="http://heathershaw.com/">Heather Shaw</a>&mdash;Art Direction, Design</li>\n                <li><a href="http://jasonsantamaria.com/">Jason Santa Maria</a>&mdash;Design</li>\n                <li><a href="http://markhuot.com/">Mark Huot</a>&mdash;Development</li>\n            </ul>\n                \n            <h2>Year</h2>\n            <p>2009</p>        \n\n            <h2>Agency</h2>\n            <p><a href="http://happycog.com/">Happy Cog</a></p>   \n    \n            <h2>Live Site</h2>\n            <p><a href="http://mica.edu/">Maryland Institute College of Art</a></p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/jetwaders/">JetWaders</a>', 'none', '<a href="/work/detail/four24/">Four24</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(18, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Modern-day jelly shoes.', 'none', '<style>\n    .page-title { background-image: url(/assets/work/jetwaders/jetwaders.png); width: 580px; height: 80px; }\n    #project-header hgroup { top: 8px; } \n    .project-image { height: 459px; background: transparent url(/assets/work/jetwaders/jetwaders-hero.jpg) no-repeat center 0; margin-bottom: 0; }\n    #work-content { background-position: 50% 0; min-width: 800px; }\n</style>', 'none', '<div class="project-image"></div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <div class="main">\n\n            <p>A little quick hit project, I worked with JetWaders to put up a landing page to capture interest in their new prodigy, a jelly shoe for women. Great photography for a great product. Easy peasy.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>JetWaders</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Creative Direction</li>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>Development</li>\n            </ul>\n                \n            <h2>Year</h2>\n            <p>2009</p>        \n    \n            <h2>Status</h2>\n            <p>No longer online</p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/housing-works/">Housing Works</a>', 'none', '<a href="/work/detail/mica/">Maryland Institute College of Art</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(19, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Housing Prevents AIDS. Housing Saves Lives. ', 'none', '<style>\n.page-title { background-image: url(/assets/work/housing-works/housing-works.png); width: 580px; height: 73px; }\n#project-header hgroup { top: 15px; }\n\n    .project-image { height: 971px; background: transparent url(/assets/work/housing-works/housing-works-hero.jpg) no-repeat center 0; margin-bottom: 0; }\n    .project-url { left: 350px; top: 31px; }\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://housingworks.org/">http://housingworks.org/</a></div>\n</div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Housing Works</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://heathershaw.com/">Heather Shaw</a>&mdash;Design</li>\n                <li><a href="http://begoodnotbad.com/">Brian Warren</a>&mdash;Front-End Development</li>\n                <li><a href="http://markhuot.com/">Mark Huot</a>&mdash;Back-End Development</li>\n                <li><a href="http://happycog.com/about/deruchie/">Dave DeRuchie</a>&mdash;Project Management</li>\n            </ul>\n                \n            <h2>Year</h2>\n            <p>2008</p>       \n\n            <h2>Agency</h2>\n            <p><a href="http://happycog.com/">Happy Cog</a></p>    \n    \n            <h2>Live Site</h2>\n            <p><a href="http://housingworks.org/">Housing Works</a></p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/planeteye/">PlanetEye</a>', 'none', '<a href="/work/detail/jetwaders/">JetWaders</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(20, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Discover. Plan. Share.', 'none', '<style>\n    .page-title { background-image: url(/assets/work/planeteye/planeteye.png); width: 568px; height: 96px; }\n    .project-image { height: 686px; background: transparent url(/assets/work/planeteye/planeteye-hero2.jpg) no-repeat center 0; margin-bottom: 0; margin-top: -20px; }\n\n    #work-content { background-position: 50% 0; min-width: 800px; }\n\n    #pullquote { background: transparent url(/assets/work/planeteye/planeteye-quote.png) no-repeat 0 0; height: 235px; }\n\n</style>', 'none', '<div class="project-image"></div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <blockquote id="pullquote" class="phark">\n            <p>Working with Dan was a fantastic experience. He’s not only a talented designer, but also understands how to bring those designs to life within the browser. I’d work with him again any day&mdash;and everyone else should too.</p>\n            <p><cite>Adam Bullied, Director of Product Management, PlanetEye</cite></p>\n        </blockquote>\n\n        <div class="main">\n\n            <p>How do you design a travel site that uses photos as its primary form of wayfinding? With big freakin&rsquo; pictures. </p>\n\n            <p>I took an editorial approach to this design to showcase the interesting and beautiful places you could discover on the site. Though this design was ultimately not chosen, I love the way it turned out.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Planet Eye</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <p><a href="http://chriscashdollar.com/">Chris Cashdollar</a>&mdash;Creative Direction</p>\n                \n            <h2>Year</h2>\n            <p>2008</p>        \n\n            <h2>Agency</h2>\n            <p><a href="http://happycog.com/">Happy Cog</a></p>   \n    \n            <h2>Status</h2>\n            <p>Unsold</p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/posse-foundation/">The Posse Foundation</a>', 'none', '<a href="/work/detail/housing-works/">Housing Works</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(21, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Changing the face of leadership in America', 'none', '<style>\n.page-title { background-image: url(/assets/work/posse-foundation/posse-foundation.png); width: 661px; height: 47px; }\n#project-header hgroup { top: 18px; }\n\n    .project-image { height: 694px; background: transparent url(/assets/work/posse-foundation/posse-foundation-hero.jpg) no-repeat center 0; margin-bottom: 0; }\n\n    #pullquote { background: transparent url(/assets/work/posse-foundation/posse-foundation-quote.png) no-repeat 0 0; height: 263px; }\n</style>', 'none', '<div class="project-image"></div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <blockquote id="pullquote" class="phark">\n            <p>Dan’s a designer who uncovers the underlying elements of your company’s brand. And I don’t mean your logo, your typefaces, your color scheme, but the core things that symbolize the essence of your organization—which he then translates beautifully into designs that go beyond your expectations.</p>\n            <p><cite>Rico Blancaflor, Vice President, Strategic Projects, The Posse Foundation, Inc.</cite></p>\n        </blockquote>\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>The Posse Foundation</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <p><a href="http://chriscashdollar.com/">Chris Cashdollar</a>&mdash;Creative Direction</p>\n                \n            <h2>Year</h2>\n            <p>2008</p>\n\n            <h2>Agency</h2>\n            <p><a href="http://happycog.com/">Happy Cog</a></p>           \n    \n            <h2>Status</h2>\n            <p>Unsold</p>\n        \n        </div><!-- .sub -->\n    \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/krylon/">Krylon</a>', 'none', '<a href="/work/detail/planeteye/">PlanetEye</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(22, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'The Utimate Address. And a Lifestyle to Match.', 'none', '<style>\n.page-title { background-image: url(/assets/work/parc-rittenhouse/parc-rittenhouse.png); width: 640px; height: 57px; }\n#project-header hgroup { top: 15px; } \n</style>', 'none', '<section id="work-content">\n\n    <div class="main">\n\n        <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n        <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n    </div><!-- .main -->\n    \n    <div class="sub">\n    \n        <h2>Client</h2>\n        <p>Parc Rittenhouse</p>\n        \n        <h2>Role</h2>\n        <ul>\n            <li>Design</li>\n            <li>Animation</li>\n            <li>Development</li>\n        </ul>\n        \n        <h2>Team</h2>\n        <ul>\n            <li><a href="http://bearskinrug.co.uk/">Kevin Cornell</a>&mdash;Art Direction, Design, Illustration, Animation</li>\n        </ul>\n                \n        <h2>Year</h2>\n        <p>2006</p>\n        \n        <h2>Agency</h2>\n        <p>Pixelworthy</p>        \n    \n        <h2>Live Site</h2>\n        <p><a href="http://parcrittenhouse.com/">Parc Rittenhouse</a></p>\n        \n    </div><!-- .sub -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/swfir/">swfIR</a>', 'none', '<a href="/work/detail/krylon/">Krylon</a>', 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(23, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'The leader in color and inspiration', 'none', '<style>\n.page-title { background-image: url(/assets/work/krylon/krylon.png); width: 386px; height: 96px; }\n\n .project-image { height: 950px; background: transparent url(/assets/work/krylon/krylon-hero.jpg) no-repeat center 0; }\n    .project-url { left: 263px; top: 35px; }\n\n    #pullquote { background: transparent url(/assets/work/krylon/krylon-quote.png) no-repeat 0 0; height: 278px; }\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://krylon.com/">http://krylon.com/</a></div>\n</div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <blockquote id="pullquote" class="phark">\n            <p>Dan was amazing to work with. His design really captured the direction and audience that Krylon was looking for with the new design, and he was always available for questions and listened intently to our critiques. I would love the opportunity to work with him again in the future.</p>\n            <p><cite>Jonathan Linczak, Team Lead, HR/Portal Team, Sherwin-Williams Company</cite></p>\n        </blockquote>\n\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>The Sherwin-Williams Company</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>Information Architecture</li>\n                <li>Animation</li>\n                <li>Front-End Development</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://greghoy.com/">Greg Hoy</a>&mdash;Creative Direction, Project Management, Information Architecture</li>\n            </ul>\n                \n            <h2>Year</h2>\n            <p>2007</p>\n        \n            <h2>Agency</h2>\n            <p><a href="http://happycog.com/">Happy Cog</a></p>        \n    \n            <h2>Live Site</h2>\n            <p><a href="http://krylon.com/">Krylon</a></p>\n        \n        </div><!-- .sub -->\n    \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '', 'none', '<a href="/work/detail/posse-foundation/">The Posse Foundation</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(24, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, '<abbr title="Shockwave Format">swf</abbr> Image Replacement', 'none', '<style>\n.page-title { background-image: url(/assets/work/swfir/swfir.png); width: 437px; height: 111px; }\n</style>', 'none', '<section id="work-content">\n\n    <div class="main">\n\n        <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n        <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n    </div><!-- .main -->\n    \n    <div class="sub">\n        \n        <h2>Role</h2>\n        <ul>\n            <li>Concept</li>\n            <li>Front-end Development</li>\n        </ul>\n        \n        <h2>Team</h2>\n        <ul>\n            <li><a href="http://markhuot.com/">Mark Huot</a>&mdash;Development</li>\n            <li><a href="http://jonaldinger.com/">Jon Aldinger</a>&mdash;Development</li>\n            <li><a href="http://bearskinrug.co.uk/">Kevin Cornell</a>&mdash;Design</li>\n        </ul>\n                \n        <h2>Year</h2>\n        <p>2005</p>\n        \n        <h2>Agency</h2>\n        <p>Pixelworthy</p>        \n    \n        <h2>Status</h2>\n        <p><abbr title="Cascading Style Sheets">CSS</abbr>3 killed the swfIR star</p>\n        \n    </div><!-- .sub -->\n\n</section><!-- #work-content -->', 'none', '', 'none', '<a href="/work/detail/parc-rittenhouse/">Parc Rittenhouse</a>', 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(25, 1, 2, NULL, NULL, NULL, NULL, NULL, NULL, '<p>Introducing <a href="http://aralbalkan.com/3710">Tweaky</a>: Super Secret Twitter for Mac preferences for everyone by <a href="http://aralbalkan.com/">Aral</a>.</p>', 'none', '<p>Introducing <a href="http://aralbalkan.com/3710">Tweaky</a>: Super Secret Twitter for Mac preferences for everyone by <a href="http://aralbalkan.com/">Aral</a>.</p>', 'none', '', 'none', NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'none', NULL, 'none', NULL, 'none');
INSERT INTO `exp_channel_data` VALUES(26, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Your Daily Step Toward Better Health', 'none', '<style>\n    .page-title { background-image: url(/assets/work/morsel/morsel.png); width: 365px; height: 75px; }\n    #project-header hgroup { top: 4px; }  \n\n    .project-image { height: 790px; background: transparent url(/assets/work/morsel/morsel-hero.jpg) no-repeat center 0; margin-bottom: -50px; }\n    .project-url { left: 371px; top: 43px; }\n\n    #awards { background: transparent url(/assets/work/morsel/morsel-awards.png) no-repeat 0 0; height: 277px; }       \n        #contagious a { width: 102px; height: 113px; top: 109px; left: 55px; }\n        #fwa a { width: 137px; height: 64px; top: 131px; left: 343px; }\n        #creativity a { width: 114px; height: 68px; top: 127px; left: 604px; }\n\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://healthymagination.com/projects/morsel/">http://healthymagination.com/projects/morsel/</a></div>\n</div>\n\n<section id="work-content" class="wrap">\n\n    <section id="awards">\n        \n        <h1 class="phark">Awards &amp; Recognition</h1>\n        \n        <ul>\n            <li id="contagious"><a class="phark phark-link" href="http://www.contagiousmagazine.com/2011/03/general_electric_healthcare.php">Contagious Magazine</a></li>\n            <li id="fwa"><a class="phark phark-link" href="http://thefwa.com/mobile/morsel"><abbr title="Favourite Website Awards">FWA</abbr></a></li>\n            <li id="creativity"><a class="phark phark-link" href="http://creativity-online.com/work/general-electric-morsel-20-progress/20938">Creativity</a></li>            \n        </ul>\n        \n    </section>\n\n    <div class="main">\n\n        <p>Morsel is a mobile app that makes healthier decisions part of everyday life. It offers simple, fun daily tasks that help individuals get healthier, one step at a time. Using simple social motivation and a few gaming mechanics, Morsel seeks to make improving your own health just a little bit easier.</p>\n\n<p>After the first version of the app caught on as part of the healthymagination partnership with the 2010 Winter Olympics, we decided to give Morsel a well-needed upgrade. Adding offline capabilities, the ability to browse multiple categories of Morsels, and many different platforms for access (Facebook, mobile, web browser), Morsel hopefully makes being healthy one step easier.</p>\n    \n    </div><!-- .main -->\n    \n    <div class="sub">\n    \n        <h2>Client</h2>\n        <p>General Electric</p>\n        \n        <h2>Role</h2>\n        <ul>\n            <li>Art Direction</li>\n            <li>Design</li>\n            <li>Strategy</li>\n            <li>User Experience</li>\n        </ul>\n        \n        <h2>Team</h2>\n        <ul>\n            <li><a href="http://www.ivanaskwith.com/">Ivan Askwith</a>&mdash;Strategy</li>\n            <li><a href="http://www.christophercocca.com/">Chris Cocca</a>&mdash;Strategy, <abbr title="User Experience">UX</abbr>, and <abbr title="Information Architecture">IA</abbr></a>\n            <li><a href="http://foughtthebattle.tumblr.com/">Josh Teixeira</a>&mdash;Content Strategy</li>\n            <li><a href="http://www.danielscheibel.com/">Daniel Scheibel</a>&mdash;Technical Consulting &amp; Development</li>\n            <li>Ranae Heuer&mdash;Production &amp; Account Management</li>\n            <li><a href="http://two-bulls.com/">Two Bulls</a>&mdash;Development</li>\n        </ul>\n        \n        <h2>Agency</h2>\n        <p><a href="http://bigspaceship.com/">Big Spaceship</a></p>\n        \n        <h2>Year</h2>\n        <p>2010</p>\n        \n        <h2>Links</h2>\n        <p><a href="http://healthymagination.com/projects/morsel/">Morsel</a></p>\n        \n    </div><!-- .sub -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/always-beautiful/">Always Beautiful</a>  ', 'none', '<a href="/work/detail/design-swap/">Design Swap</a>', 'none', 'require_once(''http://dan.local:8888/assets/work/morsel/morsel-detail.php'');', 'none');
INSERT INTO `exp_channel_data` VALUES(27, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'Microsoft&rsquo;s Internet Explorer 9 Beta Launch', 'none', '<style>\n    .page-title { background-image: url(/assets/work/always-beautiful/always-beautiful.png); width: 606px; height: 66px; }\n    #project-header hgroup { top: 12px; }  \n\n    .project-image { height: 545px; background: transparent url(/assets/work/always-beautiful/always-beautiful-hero.jpg) no-repeat center 0; margin-bottom: 0; }\n    .project-url { left: 90px; top: 22px; font-size: 9px; }\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://always-beautiful.bigspaceship.com/">http://always-beautiful.bigspaceship.com/</a></div>\n</div>\n\n<section id="work-content">\n\n    <div class="wrap">\n\n        <div class="main">\n\n            <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n            <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n        </div><!-- .main -->\n    \n        <div class="sub">\n    \n            <h2>Client</h2>\n            <p>Microsoft</p>\n        \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>illustration</li>\n            </ul>\n        \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://lifeislottery.com/">Jarrod Riddle</a>&mdash;Design, Illustration</li>\n                <li><a href="http://ayakaito.com/">Ayaka Ito</a>&mdash;Design, Illustration</li>\n                <li><a href="http://www.christophercocca.com/">Chris Cocca</a>&mdash;User Experience</li>\n                <li><a href="http://mattkenefick.com/">Matt Kenefick</a>&mdash;Development</li>\n                <li><a href="http://danielscheibel.com/">Daniel Scheibel</a>&mdash;Development</li>\n                <li>Shannon Heuer&mdash;Production</li>\n                <li><a href="http://nookajones.com/">Nooka Jones</a>&mdash;Production</li>\n            </ul>\n        \n            <h2>Year</h2>\n            <p>2010</p>\n        \n            <h2>Agency</h2>\n            <p><a href="http://bigspaceship.com/">Big Spaceship</a></p>\n        \n            <h2>Live Site</h2>\n            <p><a href="http://always-beautiful.bigspaceship.com">Always Beautiful</a> (best viewed in <abbr title="Internet Explorer">IE</abbr>9&mdash;duh)</p>\n        \n        </div><!-- .sub -->\n        \n    </div><!-- .wrap -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/transformers">Transformers</a>', 'none', '<a href="/work/detail/morsel">Morsel</a>', 'none', '', 'none');
INSERT INTO `exp_channel_data` VALUES(28, 1, 4, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, NULL, 'A Shared Encyclopedia of Typefaces', 'none', '<style>\n    .page-title { background-image: url(/assets/work/typedia/typedia.png); width: 475px; height: 110px; }\n    #project-header hgroup { top: -4px; }  \n\n    .project-image { height: 1155px; background: transparent url(/assets/work/typedia/typedia-hero.jpg) no-repeat center 0; }\n    .project-url { left: 133px; top: 26px; }\n</style>', 'none', '<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://typedia.com/">http://typedia.com/</a></div>\n</div>\n\n<section id="work-content" class="wrap">\n\n    <div class="main">\n\n        <p>Neque porro quisquam est, qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit, sed quia non numquam eius modi tempora incidunt ut labore et dolore magnam aliquam quaerat voluptatem. Ut enim ad minima veniam, quis nostrum exercitationem ullam corporis suscipit laboriosam, nisi ut aliquid ex ea commodi consequatur? Quis autem vel eum iure reprehenderit qui in ea voluptate velit esse quam nihil molestiae consequatur, vel illum qui dolorem eum fugiat quo voluptas nulla pariatur.</p>\n\n        <p>Nam libero tempore, cum soluta nobis est eligendi optio cumque nihil impedit quo minus id quod maxime placeat facere possimus, omnis voluptas assumenda est, omnis dolor repellendus. Temporibus autem quibusdam et aut officiis debitis aut rerum necessitatibus saepe eveniet ut et voluptates repudiandae sint et molestiae non recusandae. Itaque earum rerum hic tenetur a sapiente delectus.</p>\n    \n    </div><!-- .main -->\n    \n    <div class="sub">\n        \n        <h2>Role</h2>\n        <ul>\n            <li>Co-Founder</li>\n            <li>Front-End Development</li>\n            <li>Flash Development</li>\n        </ul>\n        \n        <h2>Team</h2>\n        <ul>\n            <li><a href="http://jasonsantamaria.com/">Jason Santa Maria</a>&mdash;Creative Direction</li>\n            <li><a href="http://bobulate.com/">Liz Danzico</a>&mdash;<abbr title="User Experience">UX</abbr> &amp; <abbr title="Information Architecture">IA</abbr></li>\n            <li><a href="http://www.marksimonson.com/">Mark Simonson</a>&mdash;Typeface Classification</li>\n            <li><a href="http://www.markhuot.com/">Mark Huot</a>&mdash;Back-End Development</li>\n            <li><a href="http://begoodnotbad.com/">Brian Warren</a>&mdash;Back-End Development</li>\n            <li><a href="http://stewf.com/">Stephen Coles</a>&mdash;Typographic Consultant</li>\n            <li><a href="http://typedia.com/about/">More!</a></li>            \n        </ul>\n        \n        <h2>Year</h2>\n        <p>2009</p>\n        \n        <h2>Live Site</h2>\n        <p><a href="http://typedia.com/">Typedia</a></p>\n        \n    </div><!-- .sub -->\n\n</section><!-- #work-content -->', 'none', '<a href="/work/detail/weizmann/">American Committee for the Weizmann Institute of Science</a>', 'none', '<a href="/work/detail/transformers/">Transformers</a>', 'none', '', 'none');

-- --------------------------------------------------------

--
-- Table structure for table `exp_channel_entries_autosave`
--

CREATE TABLE `exp_channel_entries_autosave` (
  `entry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `original_entry_id` int(10) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `pentry_id` int(10) NOT NULL DEFAULT '0',
  `forum_topic_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(16) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url_title` varchar(75) NOT NULL,
  `status` varchar(50) NOT NULL,
  `versioning_enabled` char(1) NOT NULL DEFAULT 'n',
  `view_count_one` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_two` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_three` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_four` int(10) unsigned NOT NULL DEFAULT '0',
  `allow_comments` varchar(1) NOT NULL DEFAULT 'y',
  `sticky` varchar(1) NOT NULL DEFAULT 'n',
  `entry_date` int(10) NOT NULL,
  `dst_enabled` varchar(1) NOT NULL DEFAULT 'n',
  `year` char(4) NOT NULL,
  `month` char(2) NOT NULL,
  `day` char(3) NOT NULL,
  `expiration_date` int(10) NOT NULL DEFAULT '0',
  `comment_expiration_date` int(10) NOT NULL DEFAULT '0',
  `edit_date` bigint(14) DEFAULT NULL,
  `recent_comment_date` int(10) DEFAULT NULL,
  `comment_total` int(4) unsigned NOT NULL DEFAULT '0',
  `entry_data` text,
  PRIMARY KEY (`entry_id`),
  KEY `channel_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `url_title` (`url_title`),
  KEY `status` (`status`),
  KEY `entry_date` (`entry_date`),
  KEY `expiration_date` (`expiration_date`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=401 ;

--
-- Dumping data for table `exp_channel_entries_autosave`
--

INSERT INTO `exp_channel_entries_autosave` VALUES(321, 12, 1, 4, 1, 0, 0, '0.0.0.0', 'Design Swap', 'design-swap', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1285040830, 'n', '2010', '09', '20', 0, 0, 20110430181211, 0, 0, 'a:15:{s:10:"channel_id";s:1:"4";s:11:"field_ft_11";s:4:"none";s:11:"field_ft_12";s:4:"none";s:11:"field_ft_13";s:4:"none";s:11:"field_ft_17";s:4:"none";s:11:"field_ft_16";s:4:"none";s:11:"field_ft_15";s:4:"none";s:11:"field_id_11";s:31:"A Day in the Life of Brian Hoff";s:11:"field_id_12";s:467:"<style>\n\n    .page-title { background-image: url(/assets/work/design-swap/design-swap.png); width: 567px; height: 85px; }\n    #project-header hgroup { top: 4px; }  \n\n    .project-image { height: 1162px; height: 532px; background: transparent url(/assets/work/design-swap/design-swap-hero3.jpg) no-repeat center 0; /*margin-bottom: -160px;*/ }\n    .project-url { left: 176px; top: 25px; left: 105px; top: 33px; }\n    h2 ins { background: none; color: #aaa; }\n\n</style>";s:11:"field_id_13";s:2819:"<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://design-swap.danielmall.com/">http://design-swap.danielmall.com/</a></div>\n</div>\n\n<section id="work-content" class="wrap">\n\n    <div class="main">\n\n        <p>Just after <abbr title="South by Southwest">SXSW</abbr> 2010, <a href="http://yaronschoen.com/">Yaron Schoen</a> and <a href="http://trentwalton.com/">Trent Walton</a> started a little side project called <a href="http://design-swap.com/">Design Swap</a> to facilitate collaboration between designers. I was fortunate enough to be invited to participate as the next installment.</p> \n\n        <p>When asked if I had a particular person I&rsquo;d like to pair up with, I mentioned <a href="http://behoff.net/">Brian Hoff</a> because I&rsquo;d never met him. Yaron mentioned that Brian chose me too, so it seemed the stars were aligned. Since Brian and I didn&rsquo;t know each other aside from a few tweets and emails, we decided to use the opportunity to change that. After a few phone calls to brainstorm, we arrived at the idea of compulsively tracking everything we did for a full day, then giving the other carte blanche to do whatever he saw fit with the data. The only restriction was that the execution must look like it was designed by the other person.</p>\n\n        <p>Using the design direction of Brian&rsquo;s site&mdash;<a href="http://www.thedesigncubicle.com/">The Design Cubicle</a>&mdash;I presented his day in 3 views: a random view that displayed one illustrated and animated portion of Brian''s day, a chronological view that organized his daily activities against an analog clock (made entirely with CSS!), and a statistical view that charted objects from Brian&rsquo;s day.</p>\n\n        <p>All in all, I consider the exercise a huge success. It was my first opportunity to get my feet wet with HTML5, and I made a great friend in Brian through the process. (Cue sappy music&hellip;)</p>\n    \n    </div><!-- .main -->\n    \n    <div class="sub">\n    \n        <h2>Client</h2>\n        <ul>\n            <li><a href="http://design-swap.com/">Design Swap</a></li>\n            <li><a href="http://yaronschoen.com/">Yaron Schoen</a></li>\n            <li><a href="http://trentwalton.com/">Trent Walton</a></li>\n        </ul>\n        \n        <h2>Role</h2>\n        <ul>\n            <li>Design</li>\n            <li>Animation</li>\n            <li>Development</li>\n        </ul>\n        \n        <h2><del>Mortal Enemy</del> <ins>BFF</ins></h2>\n        <p><a href="http://thedesigncubicle.com/">Brian Hoff</a></p>        \n        \n        <h2>Year</h2>\n        <p>2010</p>\n        \n        <h2>Status</h2>\n        <p><a href="http://design-swap.danielmall.com/">A Day in the Life of Brian Hoff</a></p>\n        \n    </div><!-- .sub -->\n\n</section><!-- #work-content -->";s:11:"field_id_17";s:0:"";s:11:"field_id_16";s:63:"<a href="/work/detail/healthymagination/">healthymagination</a>";s:11:"field_id_15";s:41:"<a href="/work/detail/morsel/">Morsel</a>";s:8:"entry_id";s:2:"12";s:17:"original_entry_id";s:2:"12";}');
INSERT INTO `exp_channel_entries_autosave` VALUES(400, 10, 1, 4, 1, 0, 0, '0.0.0.0', 'healthymagination', 'healthymagination', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1285377536, 'n', '2010', '09', '24', 0, 0, 20110504085757, 0, 0, 'a:15:{s:10:"channel_id";s:1:"4";s:11:"field_ft_11";s:4:"none";s:11:"field_ft_12";s:4:"none";s:11:"field_ft_13";s:4:"none";s:11:"field_ft_17";s:4:"none";s:11:"field_ft_16";s:4:"none";s:11:"field_ft_15";s:4:"none";s:11:"field_id_11";s:63:"A shared commitment to better health for more people. Together.";s:11:"field_id_12";s:821:"<style>\n    .page-title { background-image: url(/assets/work/healthymagination/healthymagination.png); width: 586px; height: 58px; }\n    #project-header hgroup { top: 20px; } \n\n    .project-image { height: 1652px; background: transparent url(/assets/work/healthymagination/healthymagination-hero2.jpg) no-repeat center 0; }\n    .project-url { left: -70px; top: 33px; }\n    \n    #awards { background: transparent url(/assets/work/healthymagination/healthymagination-awards.png) no-repeat 0 0; height: 265px; }\n        #wordpress a { width: 192px; height: 50px; top: 135px; left: 0; }\n        #clio a { width: 126px; height: 63px; top: 133px; left: 248px; }\n        #commarts a { width: 197px; height: 56px; top: 130px; left: 608px; }\n        #creativity a { width: 114px; height: 68px; top: 129px; left: 431px; }\n\n</style>";s:11:"field_id_13";s:3872:"<div class="project-image">\n    <div class="wrap"><a class="project-url" href="http://healthymagination.com/">http://healthymagination.com/</a></div>\n</div>\n\n       \n<section id="work-content">\n\n    <div class="wrap">\n    \n    <section id="awards">\n        \n        <h1 class="phark">Awards &amp; Recognition</h1>\n        \n        <ul>\n            <li id="wordpress"><a class="phark phark-link" href="http://wordpress.org/showcase/healthymagination/">WordPress</a></li>\n            <li id="clio"><a class="phark phark-link" href="http://www.cliohealthcare.com/winners/winners.cfm?medium_id=7">Clio Awards</a></li>\n            <li id="creativity"><a class="phark phark-link" href="http://creativity-online.com/work/general-electric-healthymagination/18932">Creativity</a></li>\n            <li id="commarts"><a class="phark phark-link" href="http://www.commarts.com/web-sites/healthymagination.html">Communication Arts</a></li>\n        </ul>\n        \n    </section>\n\n        <div class="main">\n\n            <p><abbr title="General Electric">GE</abbr> approached Big Spaceship with an unusual question: how can we get people to think about their health in a more positive way? We brainstormed for months about the possibilities, and came to a few important realizations: </p>\n    \n            <ol>\n                <li>We only think about their health when things go wrong, like when we get hurt or need an emergency procedure. This makes us view health as a negative topic.</li>\n                <li>We want to make healthy choices, but it&rsquo;s often difficult to do so.</li>\n            </ol>\n\n            <p>To that end, our task was to create ways that <abbr>GE</abbr> could empower consumers to be healthier, and feel good about it. Coinciding with the 2010 Winter Olympics, we created a number of platforms and partnerships, including an app called <a href="/work/morsel/">Morsel</a>, the <a href="http://www.webmd.com/a-to-z-guides/health-a-z-tools/better-health-conversation/default.htm">Better Health Evaluator with WebMD</a>, a <a href="http://info.howcast.com/physicalchallenge">video series</a> with <a href="http://www.howcast.com/">Howcast</a>, and a media buy called <a href="http://www.healthymagination.com/sharingideas/">Sharing Healthy Ideas</a>, among other things.</p>\n\n            <p>Healthymagination.com became the hub that housed these initiatives and gave people a centralized way to view the whole ecosystem.</p>\n\n        </div><!-- .main -->\n\n        <div class="sub">\n\n            <h2>Client</h2>\n            <p>General Electric</p>\n    \n            <h2>Role</h2>\n            <ul>\n                <li>Art Direction</li>\n                <li>Design</li>\n                <li>Strategy</li>\n            </ul>\n    \n            <h2>Team</h2>\n            <ul>\n                <li><a href="http://bigspaceship.com/">Michael Lebowitz</a>&mdash;Creative Direction</li>\n                <li><a href="http://www.ivanaskwith.com/">Ivan Askwith</a>&mdash;Strategy</li>\n                <li><a href="http://www.christophercocca.com/">Chris Cocca</a>&mdash;Strategy, <abbr title="User Experience">UX</abbr>, and <abbr title="Information Architecture">IA</abbr></a>\n                <li><a href="http://foughtthebattle.tumblr.com/">Josh Teixeira</a>&mdash;Content Strategy</li>\n                <li><a href="http://www.danielscheibel.com/">Daniel Scheibel</a>&mdash;Development &amp; Strategy</li>\n                <li>Ranae Heuer&mdash;Production &amp; Account Management</li>\n            </ul>\n    \n            <h2>Agency</h2>\n            <p><a href="http://bigspaceship.com/">Big Spaceship</a></p>\n    \n            <h2>Year</h2>\n            <p>2010</p>\n    \n            <h2>Live Site</h2>\n            <p><a href="http://healthymagination.com/">healthymagination</a></p>\n    \n        </div><!-- .sub -->\n    \n    <div><!-- .wrap -->\n\n</section><!-- #work-content -->";s:11:"field_id_17";s:0:"";s:11:"field_id_16";s:0:"";s:11:"field_id_15";s:51:"<a href="/work/detail/design-swap/">Design Swap</a>";s:8:"entry_id";s:2:"10";s:17:"original_entry_id";s:2:"10";}');

-- --------------------------------------------------------

--
-- Table structure for table `exp_channel_fields`
--

CREATE TABLE `exp_channel_fields` (
  `field_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(4) unsigned NOT NULL,
  `field_name` varchar(32) NOT NULL,
  `field_label` varchar(50) NOT NULL,
  `field_instructions` text,
  `field_type` varchar(50) NOT NULL DEFAULT 'text',
  `field_list_items` mediumtext NOT NULL,
  `field_pre_populate` char(1) NOT NULL DEFAULT 'n',
  `field_pre_channel_id` int(6) unsigned DEFAULT NULL,
  `field_pre_field_id` int(6) unsigned DEFAULT NULL,
  `field_related_to` varchar(12) NOT NULL DEFAULT 'channel',
  `field_related_id` int(6) unsigned NOT NULL,
  `field_related_orderby` varchar(12) NOT NULL DEFAULT 'date',
  `field_related_sort` varchar(4) NOT NULL DEFAULT 'desc',
  `field_related_max` smallint(4) NOT NULL,
  `field_ta_rows` tinyint(2) DEFAULT '8',
  `field_maxl` smallint(3) DEFAULT NULL,
  `field_required` char(1) NOT NULL DEFAULT 'n',
  `field_text_direction` char(3) NOT NULL DEFAULT 'ltr',
  `field_search` char(1) NOT NULL DEFAULT 'n',
  `field_is_hidden` char(1) NOT NULL DEFAULT 'n',
  `field_fmt` varchar(40) NOT NULL DEFAULT 'xhtml',
  `field_show_fmt` char(1) NOT NULL DEFAULT 'y',
  `field_order` int(3) unsigned NOT NULL,
  `field_content_type` varchar(20) NOT NULL DEFAULT 'any',
  `field_settings` text,
  PRIMARY KEY (`field_id`),
  KEY `group_id` (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=18 ;

--
-- Dumping data for table `exp_channel_fields`
--

INSERT INTO `exp_channel_fields` VALUES(1, 1, 1, 'summary', 'Summary', '', 'textarea', '', 'n', 0, 0, 'channel', 0, 'date', 'desc', 0, 6, 0, 'n', 'ltr', 'n', 'y', 'xhtml', 'y', 1, 'any', 'YTo0OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToieSI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJ5IjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToieSI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6InkiO30=');
INSERT INTO `exp_channel_fields` VALUES(2, 1, 1, 'body', 'Body', '', 'textarea', '', 'n', 0, 0, 'channel', 0, 'date', 'desc', 0, 10, 0, 'n', 'ltr', 'y', 'n', 'xhtml', 'y', 2, 'any', 'YTo0OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToieSI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJ5IjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToieSI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6InkiO30=');
INSERT INTO `exp_channel_fields` VALUES(3, 1, 1, 'extended', 'Extended text', '', 'textarea', '', 'n', 0, 0, 'channel', 0, 'date', 'desc', 0, 12, 0, 'n', 'ltr', 'n', 'y', 'xhtml', 'y', 3, 'any', 'YTo0OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToieSI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJ5IjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToieSI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6InkiO30=');
INSERT INTO `exp_channel_fields` VALUES(4, 1, 2, 'article-body', 'Article Body', '', 'textarea', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 20, 128, 'n', 'ltr', 'y', 'n', 'none', 'n', 6, 'any', 'YTo2OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToieSI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJ5IjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToieSI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6InkiO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(5, 1, 2, 'article-excerpt', 'Article Excerpt', 'Don''t forget to add &lt;p&gt; tags. This prints directly to the page without any wrapping tags.', 'textarea', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 128, 'y', 'ltr', 'y', 'n', 'none', 'y', 5, 'any', 'YTo2OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToieSI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJ5IjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToieSI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6InkiO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(7, 1, 2, 'article-head', 'Article Head', 'Anything custom that would go in the <code>&lt;head&gt;</code> (CSS, JS, etc) could go here', 'textarea', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 128, 'n', 'ltr', 'n', 'y', 'none', 'n', 4, 'any', 'YTo2OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(13, 1, 4, 'work-body', 'Work Body', 'Don’t forget to add <code>&lt;p&gt;</code> tags. This prints directly to the page without any wrapping tags.', 'textarea', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 25, 128, 'n', 'ltr', 'y', 'n', 'none', 'n', 3, 'any', 'YTo2OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(12, 1, 4, 'work-head', 'Work <code>&lt;head&gt;</code>', 'Anything custom that would go in the <code>&lt;head&gt;</code> (CSS, JS, etc) could go here', 'textarea', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 128, 'n', 'ltr', 'n', 'n', 'none', 'n', 2, 'any', 'YTo2OntzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(11, 1, 4, 'work-subtitle', 'Work Subtitle', '', 'text', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 128, 'n', 'ltr', 'y', 'n', 'none', 'n', 1, 'any', 'YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3RleHQiO2I6MDtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(17, 1, 4, 'work-body-file', 'Work Body File to Include', 'The path for a file to include for the work body.', 'text', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 500, 'n', 'ltr', 'n', 'n', 'none', 'n', 4, 'any', 'YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3RleHQiO2I6MDtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(15, 1, 4, 'work-next', 'Next Project Link', 'Anchor to next project: <code>&lt;a href=&quot;/work/detail/project/&quot;&gt;Project Name&lt;/a&gt;</code>', 'text', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 128, 'n', 'ltr', 'n', 'n', 'none', 'n', 5, 'any', 'YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3RleHQiO2I6MDtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');
INSERT INTO `exp_channel_fields` VALUES(16, 1, 4, 'work-prev', 'Previous Project Link', 'Anchor to previous project: <code>&lt;a href=&quot;/work/detail/project/&quot;&gt;Project Name&lt;/a&gt;</code>', 'text', '', '0', 0, 0, 'channel', 2, 'title', 'desc', 0, 6, 128, 'n', 'ltr', 'n', 'n', 'none', 'n', 4, 'any', 'YTo3OntzOjE4OiJmaWVsZF9jb250ZW50X3RleHQiO2I6MDtzOjE4OiJmaWVsZF9zaG93X3NtaWxleXMiO3M6MToibiI7czoxOToiZmllbGRfc2hvd19nbG9zc2FyeSI7czoxOiJuIjtzOjIxOiJmaWVsZF9zaG93X3NwZWxsY2hlY2siO3M6MToibiI7czoyNjoiZmllbGRfc2hvd19mb3JtYXR0aW5nX2J0bnMiO3M6MToibiI7czoyNDoiZmllbGRfc2hvd19maWxlX3NlbGVjdG9yIjtzOjE6Im4iO3M6MjA6ImZpZWxkX3Nob3dfd3JpdGVtb2RlIjtzOjE6Im4iO30=');

-- --------------------------------------------------------

--
-- Table structure for table `exp_channel_member_groups`
--

CREATE TABLE `exp_channel_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `channel_id` int(6) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`channel_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_channel_member_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_channel_titles`
--

CREATE TABLE `exp_channel_titles` (
  `entry_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `pentry_id` int(10) NOT NULL DEFAULT '0',
  `forum_topic_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(16) NOT NULL,
  `title` varchar(100) NOT NULL,
  `url_title` varchar(75) NOT NULL,
  `status` varchar(50) NOT NULL,
  `versioning_enabled` char(1) NOT NULL DEFAULT 'n',
  `view_count_one` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_two` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_three` int(10) unsigned NOT NULL DEFAULT '0',
  `view_count_four` int(10) unsigned NOT NULL DEFAULT '0',
  `allow_comments` varchar(1) NOT NULL DEFAULT 'y',
  `sticky` varchar(1) NOT NULL DEFAULT 'n',
  `entry_date` int(10) NOT NULL,
  `dst_enabled` varchar(1) NOT NULL DEFAULT 'n',
  `year` char(4) NOT NULL,
  `month` char(2) NOT NULL,
  `day` char(3) NOT NULL,
  `expiration_date` int(10) NOT NULL DEFAULT '0',
  `comment_expiration_date` int(10) NOT NULL DEFAULT '0',
  `edit_date` bigint(14) DEFAULT NULL,
  `recent_comment_date` int(10) DEFAULT NULL,
  `comment_total` int(4) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`entry_id`),
  KEY `weblog_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `url_title` (`url_title`),
  KEY `status` (`status`),
  KEY `entry_date` (`entry_date`),
  KEY `expiration_date` (`expiration_date`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=29 ;

--
-- Dumping data for table `exp_channel_titles`
--

INSERT INTO `exp_channel_titles` VALUES(1, 1, 1, 1, 0, 0, '0.0.0.0', 'Getting Started with ExpressionEngine', 'getting_started', 'closed', 'y', 0, 0, 0, 0, 'y', 'n', 1279064948, 'n', '2010', '07', '13', 0, 0, 20100720064009, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(2, 1, 2, 1, 0, 0, '0.0.0.0', 'Test Article 1', 'test_article_1', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1279262360, 'n', '2010', '07', '16', 0, 0, 20100720063022, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(3, 1, 2, 1, 0, 0, '0.0.0.0', 'The Second Article', 'second-article', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1279262561, 'n', '2010', '07', '16', 0, 0, 20100721071242, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(4, 1, 2, 1, 0, 0, '0.0.0.0', 'Linky Article 3', 'linky_article_3', 'closed', 'y', 0, 0, 0, 0, 'y', 'n', 1279338225, 'n', '2010', '07', '16', 0, 0, 20110123161446, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(5, 1, 2, 1, 0, 0, '192.168.1.103', 'Fourth of July, Baybuh!', 'fourth_of_july', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1279496603, 'n', '2010', '07', '18', 0, 0, 20100729062624, 1280402031, 4);
INSERT INTO `exp_channel_titles` VALUES(7, 1, 2, 1, 0, 0, '0.0.0.0', 'Color Cycling with HTML5', 'html5-color-cycling', 'closed', 'y', 0, 0, 0, 0, 'y', 'n', 1280336701, 'n', '2010', '07', '28', 0, 0, 20110123161402, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(8, 1, 2, 1, 0, 0, '0.0.0.0', 'Oh Life', 'oh-life', 'closed', 'y', 0, 0, 0, 0, 'y', 'n', 1280277321, 'n', '2010', '07', '27', 0, 0, 20110123161422, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(10, 1, 4, 1, 0, 0, '0.0.0.0', 'healthymagination', 'healthymagination', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1285359511, 'n', '2010', '09', '24', 0, 0, 20110504065532, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(11, 1, 4, 1, 0, 0, '0.0.0.0', 'Doghouse', 'doghouse', 'open', 'y', 0, 0, 0, 0, 'n', 'n', 1284533205, 'n', '2010', '09', '15', 0, 0, 20110125073446, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(12, 1, 4, 1, 0, 0, '192.168.244.1', 'Design Swap', 'design-swap', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1285022844, 'n', '2010', '09', '20', 0, 0, 20110416205325, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(13, 1, 4, 1, 0, 0, '192.168.244.1', 'Transformers', 'transformers', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284763738, 'n', '2010', '09', '17', 0, 0, 20110502102059, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(14, 1, 4, 1, 0, 0, '0.0.0.0', 'American Committee for the Weizmann Institute of Science', 'weizmann', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284763708, 'n', '2010', '09', '17', 0, 0, 20110502130530, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(15, 1, 4, 1, 0, 0, '0.0.0.0', 'Pr&eacute;ventiv Water', 'preventiv', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284814145, 'n', '2010', '09', '18', 0, 0, 20110430161906, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(16, 1, 4, 1, 0, 0, '0.0.0.0', 'Four24', 'four24', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284691748, 'n', '2010', '09', '16', 0, 0, 20110504071109, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(17, 1, 4, 1, 0, 0, '0.0.0.0', 'Maryland Institute College of Art', 'mica', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284983452, 'n', '2010', '09', '20', 0, 0, 20110503075353, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(18, 1, 4, 1, 0, 0, '0.0.0.0', 'JetWaders', 'jetwaders', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284648569, 'n', '2010', '09', '16', 0, 0, 20110502123730, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(19, 1, 4, 1, 0, 0, '0.0.0.0', 'Housing Works', 'housing-works', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284760208, 'n', '2010', '09', '17', 0, 0, 20110430182709, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(20, 1, 4, 1, 0, 0, '0.0.0.0', 'PlanetEye', 'planeteye', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284871905, 'n', '2010', '09', '19', 0, 0, 20110502125746, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(21, 1, 4, 1, 0, 0, '0.0.0.0', 'The Posse Foundation', 'posse-foundation', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284702665, 'n', '2010', '09', '17', 0, 0, 20110502120706, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(22, 1, 4, 1, 0, 0, '0.0.0.0', 'Parc Rittenhouse', 'parc-rittenhouse', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284623465, 'n', '2010', '09', '16', 0, 0, 20110310072106, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(23, 1, 4, 1, 0, 0, '0.0.0.0', 'Krylon', 'krylon', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284727971, 'n', '2010', '09', '17', 0, 0, 20110504073252, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(24, 1, 4, 1, 0, 0, '0.0.0.0', 'swfIR', 'swfir', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1284623536, 'n', '2010', '09', '16', 0, 0, 20110310072417, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(25, 1, 2, 1, 0, 0, '0.0.0.0', 'Tweaky', 'tweaky', 'closed', 'y', 0, 0, 0, 0, 'y', 'n', 1294585982, 'n', '2011', '01', '09', 0, 0, 20110123161303, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(26, 1, 4, 1, 0, 0, '0.0.0.0', 'Morsel', 'morsel', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1300309290, 'n', '2011', '03', '16', 0, 0, 20110504065331, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(27, 1, 4, 1, 0, 0, '0.0.0.0', 'Always Beautiful', 'always-beautiful', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1299838026, 'n', '2011', '03', '11', 0, 0, 20110504065507, 0, 0);
INSERT INTO `exp_channel_titles` VALUES(28, 1, 4, 1, 0, 0, '0.0.0.0', 'Typedia', 'typedia', 'open', 'y', 0, 0, 0, 0, 'y', 'n', 1304508068, 'n', '2011', '05', '04', 0, 0, 20110502104809, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `exp_comments`
--

CREATE TABLE `exp_comments` (
  `comment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `entry_id` int(10) unsigned NOT NULL DEFAULT '0',
  `channel_id` int(4) unsigned NOT NULL DEFAULT '1',
  `author_id` int(10) unsigned NOT NULL DEFAULT '0',
  `status` char(1) NOT NULL DEFAULT 'o',
  `name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `url` varchar(75) NOT NULL,
  `location` varchar(50) NOT NULL,
  `ip_address` varchar(16) NOT NULL,
  `comment_date` int(10) NOT NULL,
  `edit_date` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  `comment` mediumtext NOT NULL,
  `notify` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`comment_id`),
  KEY `entry_id` (`entry_id`),
  KEY `weblog_id` (`channel_id`),
  KEY `author_id` (`author_id`),
  KEY `status` (`status`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `exp_comments`
--

INSERT INTO `exp_comments` VALUES(9, 1, 5, 2, 0, 'o', 'Dan Mall', 'dan@danielmall.com', 'http://www.danielmall.com', '', '192.168.1.103', 1280402031, '2010-07-29 07:13:51', 'Testing real gravatar', 'n');
INSERT INTO `exp_comments` VALUES(8, 1, 5, 2, 0, 'o', 'Third is the word', 'dan@danielmall.com', '', '', '192.168.1.103', 1280401013, '2010-07-29 06:56:53', 'No website', 'n');
INSERT INTO `exp_comments` VALUES(7, 1, 5, 2, 0, 'o', 'Dan the Second', 'dan@four24.com', 'http://www.four24.com/', '', '192.168.1.103', 1280400987, '2010-07-29 06:56:27', 'The second comment: email, Four24 website', 'n');
INSERT INTO `exp_comments` VALUES(6, 1, 5, 2, 0, 'o', 'Daniel Jesse Mall', 'dan@danielmall.com', '', '', '192.168.1.103', 1280400890, '2010-07-29 06:54:50', 'First comment: email, website, comment.', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `exp_cp_log`
--

CREATE TABLE `exp_cp_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) unsigned NOT NULL,
  `username` varchar(32) NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `act_date` int(10) NOT NULL,
  `action` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=114 ;

--
-- Dumping data for table `exp_cp_log`
--

INSERT INTO `exp_cp_log` VALUES(1, 1, 1, 'danielmall', '0.0.0.0', 1279046999, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(2, 1, 1, 'danielmall', '0.0.0.0', 1279160189, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(3, 1, 1, 'danielmall', '0.0.0.0', 1279160240, 'Weblog Created:&nbsp;&nbsp;Articles');
INSERT INTO `exp_cp_log` VALUES(4, 1, 1, 'danielmall', '0.0.0.0', 1279160250, 'Weblog Created:&nbsp;&nbsp;Work');
INSERT INTO `exp_cp_log` VALUES(5, 1, 1, 'danielmall', '0.0.0.0', 1279243976, 'Field Group Created:&nbsp;&nbsp;article');
INSERT INTO `exp_cp_log` VALUES(6, 1, 1, 'danielmall', '192.168.0.192', 1279516652, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(7, 1, 1, 'danielmall', '192.168.0.192', 1279516700, 'Member profile created:&nbsp;&nbsp;stinhambo');
INSERT INTO `exp_cp_log` VALUES(8, 1, 1, 'danielmall', '192.168.0.192', 1279517441, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(9, 1, 1, 'danielmall', '0.0.0.0', 1279520607, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(10, 1, 1, 'danielmall', '0.0.0.0', 1279537689, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(11, 1, 1, 'danielmall', '0.0.0.0', 1279618916, 'Category Group Created:&nbsp;&nbsp;article');
INSERT INTO `exp_cp_log` VALUES(12, 1, 1, 'danielmall', '0.0.0.0', 1279619023, 'Status Group Created:&nbsp;article');
INSERT INTO `exp_cp_log` VALUES(13, 1, 1, 'danielmall', '0.0.0.0', 1279680076, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(14, 1, 1, 'danielmall', '0.0.0.0', 1279709693, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(15, 1, 1, 'danielmall', '0.0.0.0', 1279867371, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(16, 1, 1, 'danielmall', '0.0.0.0', 1280091687, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(17, 1, 1, 'danielmall', '0.0.0.0', 1280229141, 'Screen name was changed to:&nbsp;&nbsp;Dan Mall\n');
INSERT INTO `exp_cp_log` VALUES(18, 1, 1, 'danielmall', '192.168.1.103', 1280397896, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(19, 1, 1, 'danielmall', '192.168.1.103', 1280398112, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(20, 1, 1, 'danielmall', '192.168.1.103', 1280398442, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(21, 1, 1, 'danielmall', '192.168.1.103', 1280398463, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(22, 1, 1, 'danielmall', '192.168.1.103', 1280398807, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(23, 1, 1, 'danielmall', '192.168.1.103', 1280400584, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(24, 1, 1, 'danielmall', '0.0.0.0', 1280400835, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(25, 1, 1, 'danielmall', '0.0.0.0', 1280487272, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(26, 1, 1, 'danielmall', '0.0.0.0', 1280665953, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(27, 1, 1, 'danielmall', '0.0.0.0', 1280741846, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(28, 1, 1, 'danielmall', '0.0.0.0', 1280838192, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(29, 1, 1, 'danielmall', '0.0.0.0', 1284481919, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(30, 1, 1, 'danielmall', '0.0.0.0', 1284490679, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(31, 1, 1, 'danielmall', '0.0.0.0', 1284491242, 'Field Group Created:&nbsp;work');
INSERT INTO `exp_cp_log` VALUES(32, 1, 1, 'danielmall', '0.0.0.0', 1284491579, 'Channel Deleted:&nbsp;&nbsp;Work');
INSERT INTO `exp_cp_log` VALUES(33, 1, 1, 'danielmall', '0.0.0.0', 1284491605, 'Channel Created:&nbsp;&nbsp;Work');
INSERT INTO `exp_cp_log` VALUES(34, 1, 1, 'danielmall', '0.0.0.0', 1284491842, 'Field group Deleted:&nbsp;&nbsp;work');
INSERT INTO `exp_cp_log` VALUES(35, 1, 1, 'danielmall', '0.0.0.0', 1284491859, 'Field Group Created:&nbsp;work');
INSERT INTO `exp_cp_log` VALUES(36, 1, 1, 'danielmall', '192.168.244.1', 1288215146, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(37, 1, 1, 'danielmall', '0.0.0.0', 1288215174, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(38, 1, 1, 'danielmall', '0.0.0.0', 1288215185, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(39, 1, 1, 'danielmall', '0.0.0.0', 1288215189, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(40, 1, 1, 'danielmall', '0.0.0.0', 1294544183, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(41, 1, 1, 'danielmall', '0.0.0.0', 1294547933, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(42, 1, 1, 'danielmall', '0.0.0.0', 1295405017, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(43, 1, 1, 'danielmall', '0.0.0.0', 1295817033, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(44, 1, 1, 'danielmall', '0.0.0.0', 1295817077, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(45, 1, 1, 'danielmall', '0.0.0.0', 1295817931, 'Custom Field Deleted:&nbsp;Article Format');
INSERT INTO `exp_cp_log` VALUES(46, 1, 1, 'danielmall', '0.0.0.0', 1295825043, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(47, 1, 1, 'danielmall', '0.0.0.0', 1295957756, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(48, 1, 1, 'danielmall', '0.0.0.0', 1297167981, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(49, 1, 1, 'danielmall', '192.168.244.1', 1299294706, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(50, 1, 1, 'danielmall', '0.0.0.0', 1299556473, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(51, 1, 1, 'danielmall', '0.0.0.0', 1299560664, 'Custom Field Deleted:&nbsp;Work Order');
INSERT INTO `exp_cp_log` VALUES(52, 1, 1, 'danielmall', '172.16.62.1', 1299561421, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(53, 1, 1, 'danielmall', '0.0.0.0', 1299561593, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(54, 1, 1, 'danielmall', '0.0.0.0', 1299652614, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(55, 1, 1, 'danielmall', '0.0.0.0', 1299676127, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(56, 1, 1, 'danielmall', '0.0.0.0', 1300273540, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(57, 1, 1, 'danielmall', '0.0.0.0', 1301694290, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(58, 1, 1, 'danielmall', '192.168.244.1', 1301698376, 'Logged out');
INSERT INTO `exp_cp_log` VALUES(59, 1, 1, 'danielmall', '192.168.244.1', 1301698382, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(60, 1, 1, 'danielmall', '0.0.0.0', 1301698527, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(61, 1, 1, 'danielmall', '0.0.0.0', 1301712617, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(62, 1, 1, 'danielmall', '192.168.244.1', 1301713463, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(63, 1, 1, 'danielmall', '0.0.0.0', 1301844944, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(64, 1, 1, 'danielmall', '192.168.244.1', 1301846298, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(65, 1, 1, 'danielmall', '192.168.244.1', 1301846609, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(66, 1, 1, 'danielmall', '192.168.244.1', 1301847202, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(67, 1, 1, 'danielmall', '0.0.0.0', 1301847491, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(68, 1, 1, 'danielmall', '192.168.244.1', 1301847522, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(69, 1, 1, 'danielmall', '192.168.244.1', 1301847636, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(70, 1, 1, 'danielmall', '192.168.244.1', 1301850587, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(71, 1, 1, 'danielmall', '0.0.0.0', 1301850624, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(72, 1, 1, 'danielmall', '0.0.0.0', 1301868694, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(73, 1, 1, 'danielmall', '0.0.0.0', 1301870697, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(74, 1, 1, 'danielmall', '0.0.0.0', 1301871794, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(75, 1, 1, 'danielmall', '0.0.0.0', 1301883557, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(76, 1, 1, 'danielmall', '0.0.0.0', 1301916283, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(77, 1, 1, 'danielmall', '192.168.244.1', 1301916371, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(78, 1, 1, 'danielmall', '0.0.0.0', 1301916377, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(79, 1, 1, 'danielmall', '0.0.0.0', 1302995326, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(80, 1, 1, 'danielmall', '192.168.244.1', 1302999760, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(81, 1, 1, 'danielmall', '192.168.244.1', 1302999992, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(82, 1, 1, 'danielmall', '0.0.0.0', 1303000159, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(83, 1, 1, 'danielmall', '192.168.244.1', 1303001561, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(84, 1, 1, 'danielmall', '0.0.0.0', 1303041389, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(85, 1, 1, 'danielmall', '0.0.0.0', 1304176586, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(86, 1, 1, 'danielmall', '192.168.244.1', 1304194591, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(87, 1, 1, 'danielmall', '0.0.0.0', 1304194698, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(88, 1, 1, 'danielmall', '192.168.244.1', 1304199884, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(89, 1, 1, 'danielmall', '0.0.0.0', 1304200431, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(90, 1, 1, 'danielmall', '0.0.0.0', 1304342114, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(91, 1, 1, 'danielmall', '192.168.244.1', 1304342345, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(92, 1, 1, 'danielmall', '192.168.244.1', 1304346213, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(93, 1, 1, 'danielmall', '0.0.0.0', 1304346218, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(94, 1, 1, 'danielmall', '0.0.0.0', 1304346221, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(95, 1, 1, 'danielmall', '192.168.244.1', 1304346244, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(96, 1, 1, 'danielmall', '0.0.0.0', 1304346299, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(97, 1, 1, 'danielmall', '192.168.244.1', 1304350051, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(98, 1, 1, 'danielmall', '0.0.0.0', 1304350242, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(99, 1, 1, 'danielmall', '192.168.244.1', 1304350549, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(100, 1, 1, 'danielmall', '0.0.0.0', 1304352263, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(101, 1, 1, 'danielmall', '192.168.244.1', 1304352962, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(102, 1, 1, 'danielmall', '0.0.0.0', 1304352998, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(103, 1, 1, 'danielmall', '0.0.0.0', 1304353000, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(104, 1, 1, 'danielmall', '192.168.244.1', 1304353095, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(105, 1, 1, 'danielmall', '0.0.0.0', 1304353145, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(106, 1, 1, 'danielmall', '0.0.0.0', 1304353167, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(107, 1, 1, 'danielmall', '192.168.244.1', 1304353238, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(108, 1, 1, 'danielmall', '0.0.0.0', 1304353273, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(109, 1, 1, 'danielmall', '192.168.244.1', 1304355379, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(110, 1, 1, 'danielmall', '0.0.0.0', 1304355455, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(111, 1, 1, 'danielmall', '192.168.244.1', 1304371851, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(112, 1, 1, 'danielmall', '0.0.0.0', 1304372026, 'Logged in');
INSERT INTO `exp_cp_log` VALUES(113, 1, 1, 'danielmall', '0.0.0.0', 1304505239, 'Logged in');

-- --------------------------------------------------------

--
-- Table structure for table `exp_cp_search_index`
--

CREATE TABLE `exp_cp_search_index` (
  `search_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `controller` varchar(20) DEFAULT NULL,
  `method` varchar(50) DEFAULT NULL,
  `language` varchar(20) DEFAULT NULL,
  `access` varchar(50) DEFAULT NULL,
  `keywords` text,
  PRIMARY KEY (`search_id`),
  FULLTEXT KEY `keywords` (`keywords`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_cp_search_index`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_email_cache`
--

CREATE TABLE `exp_email_cache` (
  `cache_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `cache_date` int(10) unsigned NOT NULL DEFAULT '0',
  `total_sent` int(6) unsigned NOT NULL,
  `from_name` varchar(70) NOT NULL,
  `from_email` varchar(70) NOT NULL,
  `recipient` mediumtext NOT NULL,
  `cc` mediumtext NOT NULL,
  `bcc` mediumtext NOT NULL,
  `recipient_array` longtext NOT NULL,
  `subject` varchar(120) NOT NULL,
  `message` longtext NOT NULL,
  `plaintext_alt` longtext NOT NULL,
  `mailinglist` char(1) NOT NULL DEFAULT 'n',
  `mailtype` varchar(6) NOT NULL,
  `text_fmt` varchar(40) NOT NULL,
  `wordwrap` char(1) NOT NULL DEFAULT 'y',
  `priority` char(1) NOT NULL DEFAULT '3',
  PRIMARY KEY (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_email_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_email_cache_mg`
--

CREATE TABLE `exp_email_cache_mg` (
  `cache_id` int(6) unsigned NOT NULL,
  `group_id` smallint(4) NOT NULL,
  PRIMARY KEY (`cache_id`,`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_email_cache_mg`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_email_cache_ml`
--

CREATE TABLE `exp_email_cache_ml` (
  `cache_id` int(6) unsigned NOT NULL,
  `list_id` smallint(4) NOT NULL,
  PRIMARY KEY (`cache_id`,`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_email_cache_ml`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_email_console_cache`
--

CREATE TABLE `exp_email_console_cache` (
  `cache_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `cache_date` int(10) unsigned NOT NULL DEFAULT '0',
  `member_id` int(10) unsigned NOT NULL,
  `member_name` varchar(50) NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `recipient` varchar(70) NOT NULL,
  `recipient_name` varchar(50) NOT NULL,
  `subject` varchar(120) NOT NULL,
  `message` longtext NOT NULL,
  PRIMARY KEY (`cache_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_email_console_cache`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_email_tracker`
--

CREATE TABLE `exp_email_tracker` (
  `email_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email_date` int(10) unsigned NOT NULL DEFAULT '0',
  `sender_ip` varchar(16) NOT NULL,
  `sender_email` varchar(75) NOT NULL,
  `sender_username` varchar(50) NOT NULL,
  `number_recipients` int(4) unsigned NOT NULL DEFAULT '1',
  PRIMARY KEY (`email_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_email_tracker`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_entry_ping_status`
--

CREATE TABLE `exp_entry_ping_status` (
  `entry_id` int(10) unsigned NOT NULL,
  `ping_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`entry_id`,`ping_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_entry_ping_status`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_entry_versioning`
--

CREATE TABLE `exp_entry_versioning` (
  `version_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `entry_id` int(10) unsigned NOT NULL,
  `channel_id` int(4) unsigned NOT NULL,
  `author_id` int(10) unsigned NOT NULL,
  `version_date` int(10) NOT NULL,
  `version_data` longtext NOT NULL,
  PRIMARY KEY (`version_id`),
  KEY `entry_id` (`entry_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_entry_versioning`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_extensions`
--

CREATE TABLE `exp_extensions` (
  `extension_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `class` varchar(50) NOT NULL DEFAULT '',
  `method` varchar(50) NOT NULL DEFAULT '',
  `hook` varchar(50) NOT NULL DEFAULT '',
  `settings` mediumtext NOT NULL,
  `priority` int(2) NOT NULL DEFAULT '10',
  `version` varchar(10) NOT NULL DEFAULT '',
  `enabled` char(1) NOT NULL DEFAULT 'y',
  PRIMARY KEY (`extension_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `exp_extensions`
--

INSERT INTO `exp_extensions` VALUES(4, 'Cp_jquery', 'add_js', 'show_full_control_panel_end', 'a:2:{s:10:"jquery_src";s:63:"http://ajax.googleapis.com/ajax/libs/jquery/1.3.2/jquery.min.js";s:13:"jquery_ui_src";s:68:"http://ajax.googleapis.com/ajax/libs/jqueryui/1.7.1/jquery-ui.min.js";}', 1, '1.1.1', 'n');
INSERT INTO `exp_extensions` VALUES(5, 'Nsm_htaccess_generator_ext', 'entry_submission_end', 'entry_submission_end', 'a:0:{}', 10, '1.0.0', 'y');
INSERT INTO `exp_extensions` VALUES(6, 'Nsm_htaccess_generator_ext', 'update_template_end', 'update_template_end', 'a:0:{}', 10, '1.0.0', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `exp_fieldtypes`
--

CREATE TABLE `exp_fieldtypes` (
  `fieldtype_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(50) NOT NULL,
  `version` varchar(12) NOT NULL,
  `settings` text,
  `has_global_settings` char(1) DEFAULT 'n',
  PRIMARY KEY (`fieldtype_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=11 ;

--
-- Dumping data for table `exp_fieldtypes`
--

INSERT INTO `exp_fieldtypes` VALUES(1, 'select', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(2, 'text', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(3, 'textarea', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(4, 'date', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(5, 'file', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(6, 'multi_select', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(7, 'checkboxes', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(8, 'radio', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(9, 'rel', '1.0', 'YTowOnt9', 'n');
INSERT INTO `exp_fieldtypes` VALUES(10, 'nsm_morphine_theme', '1.0.0', 'YTowOnt9', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `exp_field_formatting`
--

CREATE TABLE `exp_field_formatting` (
  `formatting_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `field_id` int(10) unsigned NOT NULL,
  `field_fmt` varchar(40) NOT NULL,
  PRIMARY KEY (`formatting_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=55 ;

--
-- Dumping data for table `exp_field_formatting`
--

INSERT INTO `exp_field_formatting` VALUES(1, 1, 'none');
INSERT INTO `exp_field_formatting` VALUES(2, 1, 'br');
INSERT INTO `exp_field_formatting` VALUES(3, 1, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(4, 2, 'none');
INSERT INTO `exp_field_formatting` VALUES(5, 2, 'br');
INSERT INTO `exp_field_formatting` VALUES(6, 2, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(7, 3, 'none');
INSERT INTO `exp_field_formatting` VALUES(8, 3, 'br');
INSERT INTO `exp_field_formatting` VALUES(9, 3, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(10, 4, 'none');
INSERT INTO `exp_field_formatting` VALUES(11, 4, 'br');
INSERT INTO `exp_field_formatting` VALUES(12, 4, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(13, 5, 'none');
INSERT INTO `exp_field_formatting` VALUES(14, 5, 'br');
INSERT INTO `exp_field_formatting` VALUES(15, 5, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(54, 17, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(53, 17, 'br');
INSERT INTO `exp_field_formatting` VALUES(52, 17, 'none');
INSERT INTO `exp_field_formatting` VALUES(19, 7, 'none');
INSERT INTO `exp_field_formatting` VALUES(20, 7, 'br');
INSERT INTO `exp_field_formatting` VALUES(21, 7, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(42, 13, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(41, 13, 'br');
INSERT INTO `exp_field_formatting` VALUES(40, 13, 'none');
INSERT INTO `exp_field_formatting` VALUES(39, 12, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(38, 12, 'br');
INSERT INTO `exp_field_formatting` VALUES(37, 12, 'none');
INSERT INTO `exp_field_formatting` VALUES(36, 11, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(35, 11, 'br');
INSERT INTO `exp_field_formatting` VALUES(34, 11, 'none');
INSERT INTO `exp_field_formatting` VALUES(46, 15, 'none');
INSERT INTO `exp_field_formatting` VALUES(47, 15, 'br');
INSERT INTO `exp_field_formatting` VALUES(48, 15, 'xhtml');
INSERT INTO `exp_field_formatting` VALUES(49, 16, 'none');
INSERT INTO `exp_field_formatting` VALUES(50, 16, 'br');
INSERT INTO `exp_field_formatting` VALUES(51, 16, 'xhtml');

-- --------------------------------------------------------

--
-- Table structure for table `exp_field_groups`
--

CREATE TABLE `exp_field_groups` (
  `group_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_name` varchar(50) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

--
-- Dumping data for table `exp_field_groups`
--

INSERT INTO `exp_field_groups` VALUES(1, 1, 'Default Field Group');
INSERT INTO `exp_field_groups` VALUES(2, 1, 'article');
INSERT INTO `exp_field_groups` VALUES(4, 1, 'work');

-- --------------------------------------------------------

--
-- Table structure for table `exp_global_variables`
--

CREATE TABLE `exp_global_variables` (
  `variable_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `variable_name` varchar(50) NOT NULL,
  `variable_data` mediumtext NOT NULL,
  PRIMARY KEY (`variable_id`),
  KEY `variable_name` (`variable_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_global_variables`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_html_buttons`
--

CREATE TABLE `exp_html_buttons` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `tag_name` varchar(32) NOT NULL,
  `tag_open` varchar(120) NOT NULL,
  `tag_close` varchar(120) NOT NULL,
  `accesskey` varchar(32) NOT NULL,
  `tag_order` int(3) unsigned NOT NULL,
  `tag_row` char(1) NOT NULL DEFAULT '1',
  `classname` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=10 ;

--
-- Dumping data for table `exp_html_buttons`
--

INSERT INTO `exp_html_buttons` VALUES(7, 1, 0, 'blockquote', '<blockquote>', '</blockquote>', 'q', 3, '1', 'btn_blockquote');
INSERT INTO `exp_html_buttons` VALUES(6, 1, 0, 'i', '<em>', '</em>', 'i', 2, '1', 'btn_i');
INSERT INTO `exp_html_buttons` VALUES(5, 1, 0, 'b', '<strong>', '</strong>', 'b', 1, '1', 'btn_b');
INSERT INTO `exp_html_buttons` VALUES(8, 1, 0, 'a', '<a href="[![Link:!:http://]!]"(!( title="[![Title]!]")!)>', '</a>', 'a', 4, '1', 'btn_a');
INSERT INTO `exp_html_buttons` VALUES(9, 1, 0, 'img', '<img src="[![Link:!:http://]!]" alt="[![Alternative text]!]" />', '', '', 5, '1', 'btn_img');

-- --------------------------------------------------------

--
-- Table structure for table `exp_layout_publish`
--

CREATE TABLE `exp_layout_publish` (
  `layout_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_group` int(4) unsigned NOT NULL DEFAULT '0',
  `channel_id` int(4) unsigned NOT NULL DEFAULT '0',
  `field_layout` text,
  PRIMARY KEY (`layout_id`),
  KEY `site_id` (`site_id`),
  KEY `member_group` (`member_group`),
  KEY `channel_id` (`channel_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=latin1 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exp_layout_publish`
--

INSERT INTO `exp_layout_publish` VALUES(1, 1, 1, 2, 'a:5:{s:7:"publish";a:5:{s:5:"title";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}s:9:"url_title";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}i:7;a:4:{s:7:"visible";s:4:"true";s:8:"collapse";s:4:"true";s:11:"htmlbuttons";s:5:"false";s:5:"width";s:4:"100%";}i:5;a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}i:4;a:4:{s:7:"visible";s:4:"true";s:8:"collapse";s:5:"false";s:11:"htmlbuttons";s:5:"false";s:5:"width";s:4:"100%";}}s:4:"date";a:3:{s:10:"entry_date";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}s:15:"expiration_date";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}s:23:"comment_expiration_date";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}}s:5:"pings";a:1:{s:4:"ping";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}}s:7:"options";a:4:{s:11:"new_channel";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}s:6:"status";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}s:6:"author";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}s:7:"options";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}}s:10:"categories";a:1:{s:8:"category";a:4:{s:7:"visible";b:1;s:8:"collapse";b:0;s:11:"htmlbuttons";b:1;s:5:"width";s:4:"100%";}}}');

-- --------------------------------------------------------

--
-- Table structure for table `exp_mailing_list`
--

CREATE TABLE `exp_mailing_list` (
  `user_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `list_id` int(7) unsigned NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL,
  `authcode` varchar(10) NOT NULL,
  `email` varchar(50) NOT NULL,
  PRIMARY KEY (`user_id`),
  KEY `list_id` (`list_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_mailing_list`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_mailing_lists`
--

CREATE TABLE `exp_mailing_lists` (
  `list_id` int(7) unsigned NOT NULL AUTO_INCREMENT,
  `list_name` varchar(40) NOT NULL,
  `list_title` varchar(100) NOT NULL,
  `list_template` mediumtext NOT NULL,
  PRIMARY KEY (`list_id`),
  KEY `list_name` (`list_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exp_mailing_lists`
--

INSERT INTO `exp_mailing_lists` VALUES(1, 'default', 'Default Mailing List', '{message_text}\n\nTo remove your email from this mailing list, click here:\n{if html_email}<a href="{unsubscribe_url}">{unsubscribe_url}</a>{/if}\n{if plain_email}{unsubscribe_url}{/if}');

-- --------------------------------------------------------

--
-- Table structure for table `exp_mailing_list_queue`
--

CREATE TABLE `exp_mailing_list_queue` (
  `queue_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(50) NOT NULL,
  `list_id` int(7) unsigned NOT NULL DEFAULT '0',
  `authcode` varchar(10) NOT NULL,
  `date` int(10) NOT NULL,
  PRIMARY KEY (`queue_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_mailing_list_queue`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_members`
--

CREATE TABLE `exp_members` (
  `member_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `group_id` smallint(4) NOT NULL DEFAULT '0',
  `username` varchar(50) NOT NULL,
  `screen_name` varchar(50) NOT NULL,
  `password` varchar(40) NOT NULL,
  `unique_id` varchar(40) NOT NULL,
  `crypt_key` varchar(40) DEFAULT NULL,
  `authcode` varchar(10) DEFAULT NULL,
  `email` varchar(72) NOT NULL,
  `url` varchar(150) DEFAULT NULL,
  `location` varchar(50) DEFAULT NULL,
  `occupation` varchar(80) DEFAULT NULL,
  `interests` varchar(120) DEFAULT NULL,
  `bday_d` int(2) DEFAULT NULL,
  `bday_m` int(2) DEFAULT NULL,
  `bday_y` int(4) DEFAULT NULL,
  `aol_im` varchar(50) DEFAULT NULL,
  `yahoo_im` varchar(50) DEFAULT NULL,
  `msn_im` varchar(50) DEFAULT NULL,
  `icq` varchar(50) DEFAULT NULL,
  `bio` text,
  `signature` text,
  `avatar_filename` varchar(120) DEFAULT NULL,
  `avatar_width` int(4) unsigned DEFAULT NULL,
  `avatar_height` int(4) unsigned DEFAULT NULL,
  `photo_filename` varchar(120) DEFAULT NULL,
  `photo_width` int(4) unsigned DEFAULT NULL,
  `photo_height` int(4) unsigned DEFAULT NULL,
  `sig_img_filename` varchar(120) DEFAULT NULL,
  `sig_img_width` int(4) unsigned DEFAULT NULL,
  `sig_img_height` int(4) unsigned DEFAULT NULL,
  `ignore_list` text,
  `private_messages` int(4) unsigned NOT NULL DEFAULT '0',
  `accept_messages` char(1) NOT NULL DEFAULT 'y',
  `last_view_bulletins` int(10) NOT NULL DEFAULT '0',
  `last_bulletin_date` int(10) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `join_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_visit` int(10) unsigned NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `total_entries` smallint(5) unsigned NOT NULL DEFAULT '0',
  `total_comments` smallint(5) unsigned NOT NULL DEFAULT '0',
  `total_forum_topics` mediumint(8) NOT NULL DEFAULT '0',
  `total_forum_posts` mediumint(8) NOT NULL DEFAULT '0',
  `last_entry_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_forum_post_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_email_date` int(10) unsigned NOT NULL DEFAULT '0',
  `in_authorlist` char(1) NOT NULL DEFAULT 'n',
  `accept_admin_email` char(1) NOT NULL DEFAULT 'y',
  `accept_user_email` char(1) NOT NULL DEFAULT 'y',
  `notify_by_default` char(1) NOT NULL DEFAULT 'y',
  `notify_of_pm` char(1) NOT NULL DEFAULT 'y',
  `display_avatars` char(1) NOT NULL DEFAULT 'y',
  `display_signatures` char(1) NOT NULL DEFAULT 'y',
  `parse_smileys` char(1) NOT NULL DEFAULT 'y',
  `smart_notifications` char(1) NOT NULL DEFAULT 'y',
  `language` varchar(50) NOT NULL,
  `timezone` varchar(8) NOT NULL,
  `daylight_savings` char(1) NOT NULL DEFAULT 'n',
  `localization_is_site_default` char(1) NOT NULL DEFAULT 'n',
  `time_format` char(2) NOT NULL DEFAULT 'us',
  `cp_theme` varchar(32) DEFAULT NULL,
  `profile_theme` varchar(32) DEFAULT NULL,
  `forum_theme` varchar(32) DEFAULT NULL,
  `tracker` text,
  `template_size` varchar(2) NOT NULL DEFAULT '28',
  `notepad` text,
  `notepad_size` varchar(2) NOT NULL DEFAULT '18',
  `quick_links` text,
  `quick_tabs` text,
  `pmember_id` int(10) NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`),
  KEY `group_id` (`group_id`),
  KEY `unique_id` (`unique_id`),
  KEY `password` (`password`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `exp_members`
--

INSERT INTO `exp_members` VALUES(1, 1, 'danielmall', 'Dan Mall', 'a0f13f25851404c2a18499839a282c3c8392c32d', 'b3998f1b36ca488dd4ffdb36221e2ba3c84ccdbe', 'a7e23c13a77f1dec5d3effe636a7cba92b8a6942', '', 'dan@danielmall.com', '', '', '', '', 0, 0, 0, '', '', '', '', '', '', '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 'y', 0, 0, 'fe80::223:12ff:f', 1279046957, 1304423416, 1304513818, 26, 0, 0, 0, 1304346103, 0, 0, 0, 'n', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'english', 'UM5', 'n', 'n', 'us', '', '', '', '', '28', '', '18', 'My Site|http://dan.local:8888/index.php|1', '', 0);
INSERT INTO `exp_members` VALUES(2, 1, 'stinhambo', 'Steven Hambleton', '4b54b6550f783e73b16f2a6ef6b4a00b962806cf', '13423001cc637bbb98e021cdca6018537fcf2ccb', NULL, '', 'steven.hambleton@gmail.com', '', '', '', '', 0, 0, 0, '', '', '', '', '', '', '', 0, 0, '', 0, 0, '', 0, 0, '', 0, 'y', 0, 0, '192.168.0.192', 1279516700, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 'n', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', '', '', 'n', 'n', 'us', '', '', '', '', '28', '', '18', '', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exp_member_bulletin_board`
--

CREATE TABLE `exp_member_bulletin_board` (
  `bulletin_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL,
  `bulletin_group` int(8) unsigned NOT NULL,
  `bulletin_date` int(10) unsigned NOT NULL,
  `hash` varchar(10) NOT NULL DEFAULT '',
  `bulletin_expires` int(10) unsigned NOT NULL DEFAULT '0',
  `bulletin_message` mediumtext NOT NULL,
  PRIMARY KEY (`bulletin_id`),
  KEY `sender_id` (`sender_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_member_bulletin_board`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_member_data`
--

CREATE TABLE `exp_member_data` (
  `member_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_member_data`
--

INSERT INTO `exp_member_data` VALUES(1);
INSERT INTO `exp_member_data` VALUES(2);

-- --------------------------------------------------------

--
-- Table structure for table `exp_member_fields`
--

CREATE TABLE `exp_member_fields` (
  `m_field_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `m_field_name` varchar(32) NOT NULL,
  `m_field_label` varchar(50) NOT NULL,
  `m_field_description` mediumtext NOT NULL,
  `m_field_type` varchar(12) NOT NULL DEFAULT 'text',
  `m_field_list_items` mediumtext NOT NULL,
  `m_field_ta_rows` tinyint(2) DEFAULT '8',
  `m_field_maxl` smallint(3) NOT NULL,
  `m_field_width` varchar(6) NOT NULL,
  `m_field_search` char(1) NOT NULL DEFAULT 'y',
  `m_field_required` char(1) NOT NULL DEFAULT 'n',
  `m_field_public` char(1) NOT NULL DEFAULT 'y',
  `m_field_reg` char(1) NOT NULL DEFAULT 'n',
  `m_field_fmt` char(5) NOT NULL DEFAULT 'none',
  `m_field_order` int(3) unsigned NOT NULL,
  PRIMARY KEY (`m_field_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_member_fields`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_member_groups`
--

CREATE TABLE `exp_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_title` varchar(100) NOT NULL,
  `group_description` mediumtext NOT NULL,
  `is_locked` char(1) NOT NULL DEFAULT 'y',
  `can_view_offline_system` char(1) NOT NULL DEFAULT 'n',
  `can_view_online_system` char(1) NOT NULL DEFAULT 'y',
  `can_access_cp` char(1) NOT NULL DEFAULT 'y',
  `can_access_content` char(1) NOT NULL DEFAULT 'n',
  `can_access_publish` char(1) NOT NULL DEFAULT 'n',
  `can_access_edit` char(1) NOT NULL DEFAULT 'n',
  `can_access_files` char(1) NOT NULL DEFAULT 'n',
  `can_access_fieldtypes` char(1) NOT NULL DEFAULT 'n',
  `can_access_design` char(1) NOT NULL DEFAULT 'n',
  `can_access_addons` char(1) NOT NULL DEFAULT 'n',
  `can_access_modules` char(1) NOT NULL DEFAULT 'n',
  `can_access_extensions` char(1) NOT NULL DEFAULT 'n',
  `can_access_accessories` char(1) NOT NULL DEFAULT 'n',
  `can_access_plugins` char(1) NOT NULL DEFAULT 'n',
  `can_access_members` char(1) NOT NULL DEFAULT 'n',
  `can_access_comm` char(1) NOT NULL DEFAULT 'n',
  `can_access_utilities` char(1) NOT NULL DEFAULT 'n',
  `can_access_data` char(1) NOT NULL DEFAULT 'n',
  `can_access_logs` char(1) NOT NULL DEFAULT 'n',
  `can_access_admin` char(1) NOT NULL DEFAULT 'n',
  `can_access_sys_prefs` char(1) NOT NULL DEFAULT 'n',
  `can_access_content_prefs` char(1) NOT NULL DEFAULT 'n',
  `can_access_tools` char(1) NOT NULL DEFAULT 'n',
  `can_admin_channels` char(1) NOT NULL DEFAULT 'n',
  `can_admin_design` char(1) NOT NULL DEFAULT 'n',
  `can_admin_members` char(1) NOT NULL DEFAULT 'n',
  `can_delete_members` char(1) NOT NULL DEFAULT 'n',
  `can_admin_mbr_groups` char(1) NOT NULL DEFAULT 'n',
  `can_admin_mbr_templates` char(1) NOT NULL DEFAULT 'n',
  `can_ban_users` char(1) NOT NULL DEFAULT 'n',
  `can_admin_modules` char(1) NOT NULL DEFAULT 'n',
  `can_admin_templates` char(1) NOT NULL DEFAULT 'n',
  `can_edit_categories` char(1) NOT NULL DEFAULT 'n',
  `can_delete_categories` char(1) NOT NULL DEFAULT 'n',
  `can_view_other_entries` char(1) NOT NULL DEFAULT 'n',
  `can_edit_other_entries` char(1) NOT NULL DEFAULT 'n',
  `can_assign_post_authors` char(1) NOT NULL DEFAULT 'n',
  `can_delete_self_entries` char(1) NOT NULL DEFAULT 'n',
  `can_delete_all_entries` char(1) NOT NULL DEFAULT 'n',
  `can_view_other_comments` char(1) NOT NULL DEFAULT 'n',
  `can_edit_own_comments` char(1) NOT NULL DEFAULT 'n',
  `can_delete_own_comments` char(1) NOT NULL DEFAULT 'n',
  `can_edit_all_comments` char(1) NOT NULL DEFAULT 'n',
  `can_delete_all_comments` char(1) NOT NULL DEFAULT 'n',
  `can_moderate_comments` char(1) NOT NULL DEFAULT 'n',
  `can_send_email` char(1) NOT NULL DEFAULT 'n',
  `can_send_cached_email` char(1) NOT NULL DEFAULT 'n',
  `can_email_member_groups` char(1) NOT NULL DEFAULT 'n',
  `can_email_mailinglist` char(1) NOT NULL DEFAULT 'n',
  `can_email_from_profile` char(1) NOT NULL DEFAULT 'n',
  `can_view_profiles` char(1) NOT NULL DEFAULT 'n',
  `can_delete_self` char(1) NOT NULL DEFAULT 'n',
  `mbr_delete_notify_emails` varchar(255) DEFAULT NULL,
  `can_post_comments` char(1) NOT NULL DEFAULT 'n',
  `exclude_from_moderation` char(1) NOT NULL DEFAULT 'n',
  `can_search` char(1) NOT NULL DEFAULT 'n',
  `search_flood_control` mediumint(5) unsigned NOT NULL,
  `can_send_private_messages` char(1) NOT NULL DEFAULT 'n',
  `prv_msg_send_limit` smallint(5) unsigned NOT NULL DEFAULT '20',
  `prv_msg_storage_limit` smallint(5) unsigned NOT NULL DEFAULT '60',
  `can_attach_in_private_messages` char(1) NOT NULL DEFAULT 'n',
  `can_send_bulletins` char(1) NOT NULL DEFAULT 'n',
  `include_in_authorlist` char(1) NOT NULL DEFAULT 'n',
  `include_in_memberlist` char(1) NOT NULL DEFAULT 'y',
  `include_in_mailinglists` char(1) NOT NULL DEFAULT 'y',
  PRIMARY KEY (`group_id`,`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_member_groups`
--

INSERT INTO `exp_member_groups` VALUES(1, 1, 'Super Admins', '', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', 'y', '', 'y', 'y', 'y', 0, 'y', 20, 60, 'y', 'y', 'y', 'y', 'y');
INSERT INTO `exp_member_groups` VALUES(2, 1, 'Banned', '', 'y', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', '', 'n', 'n', 'n', 60, 'n', 20, 60, 'n', 'n', 'n', 'n', 'n');
INSERT INTO `exp_member_groups` VALUES(3, 1, 'Guests', '', 'y', 'n', 'y', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'y', 'n', '', 'y', 'n', 'y', 15, 'n', 20, 60, 'n', 'n', 'n', 'n', 'n');
INSERT INTO `exp_member_groups` VALUES(4, 1, 'Pending', '', 'y', 'n', 'y', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'y', 'n', '', 'y', 'n', 'y', 15, 'n', 20, 60, 'n', 'n', 'n', 'n', 'n');
INSERT INTO `exp_member_groups` VALUES(5, 1, 'Members', '', 'y', 'n', 'y', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'n', 'y', 'y', 'n', '', 'y', 'n', 'y', 10, 'y', 20, 60, 'y', 'n', 'n', 'y', 'y');

-- --------------------------------------------------------

--
-- Table structure for table `exp_member_homepage`
--

CREATE TABLE `exp_member_homepage` (
  `member_id` int(10) unsigned NOT NULL,
  `recent_entries` char(1) NOT NULL DEFAULT 'l',
  `recent_entries_order` int(3) unsigned NOT NULL DEFAULT '0',
  `recent_comments` char(1) NOT NULL DEFAULT 'l',
  `recent_comments_order` int(3) unsigned NOT NULL DEFAULT '0',
  `recent_members` char(1) NOT NULL DEFAULT 'n',
  `recent_members_order` int(3) unsigned NOT NULL DEFAULT '0',
  `site_statistics` char(1) NOT NULL DEFAULT 'r',
  `site_statistics_order` int(3) unsigned NOT NULL DEFAULT '0',
  `member_search_form` char(1) NOT NULL DEFAULT 'n',
  `member_search_form_order` int(3) unsigned NOT NULL DEFAULT '0',
  `notepad` char(1) NOT NULL DEFAULT 'r',
  `notepad_order` int(3) unsigned NOT NULL DEFAULT '0',
  `bulletin_board` char(1) NOT NULL DEFAULT 'r',
  `bulletin_board_order` int(3) unsigned NOT NULL DEFAULT '0',
  `pmachine_news_feed` char(1) NOT NULL DEFAULT 'n',
  `pmachine_news_feed_order` int(3) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_member_homepage`
--

INSERT INTO `exp_member_homepage` VALUES(1, 'l', 1, 'l', 2, 'n', 0, 'r', 1, 'n', 0, 'r', 2, 'r', 0, 'l', 0);
INSERT INTO `exp_member_homepage` VALUES(2, 'l', 0, 'l', 0, 'n', 0, 'r', 0, 'n', 0, 'r', 0, 'r', 0, 'n', 0);

-- --------------------------------------------------------

--
-- Table structure for table `exp_member_search`
--

CREATE TABLE `exp_member_search` (
  `search_id` varchar(32) NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `search_date` int(10) unsigned NOT NULL,
  `keywords` varchar(200) NOT NULL,
  `fields` varchar(200) NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL,
  `total_results` int(8) unsigned NOT NULL,
  `query` mediumtext NOT NULL,
  PRIMARY KEY (`search_id`),
  KEY `member_id` (`member_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_member_search`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_message_attachments`
--

CREATE TABLE `exp_message_attachments` (
  `attachment_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_id` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment_name` varchar(50) NOT NULL DEFAULT '',
  `attachment_hash` varchar(40) NOT NULL DEFAULT '',
  `attachment_extension` varchar(20) NOT NULL DEFAULT '',
  `attachment_location` varchar(150) NOT NULL DEFAULT '',
  `attachment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment_size` int(10) unsigned NOT NULL DEFAULT '0',
  `is_temp` char(1) NOT NULL DEFAULT 'y',
  PRIMARY KEY (`attachment_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_message_attachments`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_message_copies`
--

CREATE TABLE `exp_message_copies` (
  `copy_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `message_id` int(10) unsigned NOT NULL DEFAULT '0',
  `sender_id` int(10) unsigned NOT NULL DEFAULT '0',
  `recipient_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_received` char(1) NOT NULL DEFAULT 'n',
  `message_read` char(1) NOT NULL DEFAULT 'n',
  `message_time_read` int(10) unsigned NOT NULL DEFAULT '0',
  `attachment_downloaded` char(1) NOT NULL DEFAULT 'n',
  `message_folder` int(10) unsigned NOT NULL DEFAULT '1',
  `message_authcode` varchar(10) NOT NULL DEFAULT '',
  `message_deleted` char(1) NOT NULL DEFAULT 'n',
  `message_status` varchar(10) NOT NULL DEFAULT '',
  PRIMARY KEY (`copy_id`),
  KEY `message_id` (`message_id`),
  KEY `recipient_id` (`recipient_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_message_copies`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_message_data`
--

CREATE TABLE `exp_message_data` (
  `message_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sender_id` int(10) unsigned NOT NULL DEFAULT '0',
  `message_date` int(10) unsigned NOT NULL DEFAULT '0',
  `message_subject` varchar(255) NOT NULL DEFAULT '',
  `message_body` mediumtext NOT NULL,
  `message_tracking` char(1) NOT NULL DEFAULT 'y',
  `message_attachments` char(1) NOT NULL DEFAULT 'n',
  `message_recipients` varchar(200) NOT NULL DEFAULT '',
  `message_cc` varchar(200) NOT NULL DEFAULT '',
  `message_hide_cc` char(1) NOT NULL DEFAULT 'n',
  `message_sent_copy` char(1) NOT NULL DEFAULT 'n',
  `total_recipients` int(5) unsigned NOT NULL DEFAULT '0',
  `message_status` varchar(25) NOT NULL DEFAULT '',
  PRIMARY KEY (`message_id`),
  KEY `sender_id` (`sender_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_message_data`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_message_folders`
--

CREATE TABLE `exp_message_folders` (
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `folder1_name` varchar(50) NOT NULL DEFAULT 'InBox',
  `folder2_name` varchar(50) NOT NULL DEFAULT 'Sent',
  `folder3_name` varchar(50) NOT NULL DEFAULT '',
  `folder4_name` varchar(50) NOT NULL DEFAULT '',
  `folder5_name` varchar(50) NOT NULL DEFAULT '',
  `folder6_name` varchar(50) NOT NULL DEFAULT '',
  `folder7_name` varchar(50) NOT NULL DEFAULT '',
  `folder8_name` varchar(50) NOT NULL DEFAULT '',
  `folder9_name` varchar(50) NOT NULL DEFAULT '',
  `folder10_name` varchar(50) NOT NULL DEFAULT '',
  PRIMARY KEY (`member_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_message_folders`
--

INSERT INTO `exp_message_folders` VALUES(1, 'InBox', 'Sent', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `exp_message_listed`
--

CREATE TABLE `exp_message_listed` (
  `listed_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL DEFAULT '0',
  `listed_member` int(10) unsigned NOT NULL DEFAULT '0',
  `listed_description` varchar(100) NOT NULL DEFAULT '',
  `listed_type` varchar(10) NOT NULL DEFAULT 'blocked',
  PRIMARY KEY (`listed_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_message_listed`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_modules`
--

CREATE TABLE `exp_modules` (
  `module_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `module_name` varchar(50) NOT NULL,
  `module_version` varchar(12) NOT NULL,
  `has_cp_backend` char(1) NOT NULL DEFAULT 'n',
  `has_publish_fields` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`module_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `exp_modules`
--

INSERT INTO `exp_modules` VALUES(1, 'Comment', '2.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(2, 'Emoticon', '1.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(3, 'Mailinglist', '3.0', 'y', 'n');
INSERT INTO `exp_modules` VALUES(4, 'Member', '2.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(5, 'Query', '1.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(6, 'Referrer', '2.0', 'y', 'n');
INSERT INTO `exp_modules` VALUES(7, 'Rss', '1.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(8, 'Stats', '2.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(12, 'Nsm_morphine_theme', '1.0.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(10, 'Channel', '2.0.1', 'n', 'n');
INSERT INTO `exp_modules` VALUES(11, 'Search', '2.0', 'n', 'n');
INSERT INTO `exp_modules` VALUES(13, 'Jquery', '1.0', 'n', 'n');

-- --------------------------------------------------------

--
-- Table structure for table `exp_module_member_groups`
--

CREATE TABLE `exp_module_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `module_id` mediumint(5) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`module_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_module_member_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_nsm_addon_settings`
--

CREATE TABLE `exp_nsm_addon_settings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(5) unsigned NOT NULL DEFAULT '1',
  `addon_id` varchar(255) NOT NULL,
  `settings` mediumtext NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exp_nsm_addon_settings`
--

INSERT INTO `exp_nsm_addon_settings` VALUES(1, 1, 'nsm_htaccess_generator', '{"enabled":"1","path":"\\/Users\\/danielmall\\/Sites\\/hybrid\\/branches\\/ee2.1\\/bin\\/.htaccess\\t\\t\\t\\t\\t\\t","template":"# secure .htaccess file\\n<Files .htaccess>\\n order allow,deny\\n deny from all\\n<\\/Files>\\n\\n# EE 404 page for missing pages\\nErrorDocument 404 \\/index.php\\/{ee:404}\\n\\n# Simple 404 for missing files\\n<FilesMatch \\"(\\\\.jpe?g|gif|png|bmp|css|js|flv)$\\">\\n  ErrorDocument 404 \\"File Not Found\\"\\n<\\/FilesMatch>\\n\\n# Although highly unlikely, your host may have +FollowSymLinks enabled at the root level, yet disallow its addition in .htaccess; in which case, adding +FollowSymLinks will break your setup (probably a 500 error), so just remove it, and your rules should work fine.\\nOptions +FollowSymlinks\\nRewriteEngine On\\nRewriteBase \\/\\n\\n# remove the www - Uncomment to activate\\n# RewriteCond %{HTTP_HOST} ^www\\\\.(.*) [NC]\\n# RewriteRule ^(.*)$ http:\\/\\/%1\\/$1 [R=301,NC,L]\\n\\n# Remove the trailing slash to paths without an extension\\n# Uncomment to activate\\n# RewriteCond %{REQUEST_URI} \\/$\\n# RewriteCond %{REQUEST_FILENAME} !-d\\n# RewriteRule ^(.+)\\/$ $1 [L,R=301]\\n\\n# Remove index.php\\n# Uses the \\"include method\\"\\n# http:\\/\\/expressionengine.com\\/wiki\\/Remove_index.php_From_URLs\\/#Include_List_Method\\nRewriteCond %{QUERY_STRING} !^(ACT=.*)$ [NC]\\nRewriteCond %{REQUEST_URI} !(\\\\.[a-zA-Z0-9]{1,5})$\\nRewriteCond %{REQUEST_FILENAME} !-f\\nRewriteCond %{REQUEST_FILENAME} !-d\\nRewriteCond %{REQUEST_URI} ^\\/({ee:template_groups}{ee:pages}members|P[0-9]{2,8}) [NC]\\nRewriteRule (.*) \\/index.php\\/$1 [L]"}');

-- --------------------------------------------------------

--
-- Table structure for table `exp_online_users`
--

CREATE TABLE `exp_online_users` (
  `online_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `in_forum` char(1) NOT NULL DEFAULT 'n',
  `name` varchar(50) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `date` int(10) unsigned NOT NULL DEFAULT '0',
  `anon` char(1) NOT NULL,
  PRIMARY KEY (`online_id`),
  KEY `date` (`date`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=232 ;

--
-- Dumping data for table `exp_online_users`
--

INSERT INTO `exp_online_users` VALUES(228, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(231, 1, 1, 'n', 'Dan Mall', '192.168.244.1', 1304509958, 'y');
INSERT INTO `exp_online_users` VALUES(215, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(224, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(208, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(209, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(210, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(211, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(216, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(213, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(201, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(212, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(203, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(219, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(226, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(221, 1, 1, 'n', 'Dan Mall', '0.0.0.0', 1304510412, 'y');
INSERT INTO `exp_online_users` VALUES(230, 1, 1, 'n', 'Dan Mall', '192.168.244.1', 1304509056, 'y');

-- --------------------------------------------------------

--
-- Table structure for table `exp_password_lockout`
--

CREATE TABLE `exp_password_lockout` (
  `lockout_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `login_date` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) NOT NULL,
  `username` varchar(50) NOT NULL,
  PRIMARY KEY (`lockout_id`),
  KEY `login_date` (`login_date`),
  KEY `ip_address` (`ip_address`),
  KEY `user_agent` (`user_agent`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `exp_password_lockout`
--

INSERT INTO `exp_password_lockout` VALUES(1, 1279552637, '192.168.0.192', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; ', 'admin');
INSERT INTO `exp_password_lockout` VALUES(2, 1279552643, '192.168.0.192', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_4; ', 'root');

-- --------------------------------------------------------

--
-- Table structure for table `exp_ping_servers`
--

CREATE TABLE `exp_ping_servers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `server_name` varchar(32) NOT NULL,
  `server_url` varchar(150) NOT NULL,
  `port` varchar(4) NOT NULL DEFAULT '80',
  `ping_protocol` varchar(12) NOT NULL DEFAULT 'xmlrpc',
  `is_default` char(1) NOT NULL DEFAULT 'y',
  `server_order` int(3) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_ping_servers`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_referrers`
--

CREATE TABLE `exp_referrers` (
  `ref_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `ref_from` varchar(150) NOT NULL,
  `ref_to` varchar(120) NOT NULL,
  `ref_ip` varchar(16) NOT NULL DEFAULT '0',
  `ref_date` int(10) unsigned NOT NULL DEFAULT '0',
  `ref_agent` varchar(100) NOT NULL,
  PRIMARY KEY (`ref_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=14 ;

--
-- Dumping data for table `exp_referrers`
--

INSERT INTO `exp_referrers` VALUES(1, 1, 'http://hybrid2.danielmall.com/?URL=http://dan.local:8888/index.php', 'http://dan.local:8888', '0.0.0.0', 1280486899, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_5_8; en-us) AppleWebKit/533.16 (KHTML, like Gecko) Vers');
INSERT INTO `exp_referrers` VALUES(2, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525369, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(3, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525369, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(4, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525371, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(5, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525371, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(6, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525377, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(7, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525377, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(8, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525379, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(9, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525379, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(10, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525408, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(11, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525408, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(12, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525410, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');
INSERT INTO `exp_referrers` VALUES(13, 1, 'http://192.168.1.100:8888/work/speaking/', 'http://dan.local:8888', '192.168.1.100', 1296525410, 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_6; en-us) AppleWebKit/533.19.4 (KHTML, like Gecko) Ve');

-- --------------------------------------------------------

--
-- Table structure for table `exp_relationships`
--

CREATE TABLE `exp_relationships` (
  `rel_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `rel_parent_id` int(10) NOT NULL DEFAULT '0',
  `rel_child_id` int(10) NOT NULL DEFAULT '0',
  `rel_type` varchar(12) NOT NULL,
  `rel_data` longtext NOT NULL,
  `reverse_rel_data` longtext NOT NULL,
  PRIMARY KEY (`rel_id`),
  KEY `rel_parent_id` (`rel_parent_id`),
  KEY `rel_child_id` (`rel_child_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_relationships`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_reset_password`
--

CREATE TABLE `exp_reset_password` (
  `reset_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `member_id` int(10) unsigned NOT NULL,
  `resetcode` varchar(12) NOT NULL,
  `date` int(10) NOT NULL,
  PRIMARY KEY (`reset_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_reset_password`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_revision_tracker`
--

CREATE TABLE `exp_revision_tracker` (
  `tracker_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `item_id` int(10) unsigned NOT NULL,
  `item_table` varchar(20) NOT NULL,
  `item_field` varchar(20) NOT NULL,
  `item_date` int(10) NOT NULL,
  `item_author_id` int(10) unsigned NOT NULL,
  `item_data` longtext NOT NULL,
  PRIMARY KEY (`tracker_id`),
  KEY `item_id` (`item_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=24 ;

--
-- Dumping data for table `exp_revision_tracker`
--

INSERT INTO `exp_revision_tracker` VALUES(16, 38, 'exp_templates', 'template_data', 1279860259, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(2, 1, 'exp_templates', 'template_data', 1279521723, 1, '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n\n<div id="blog">\n\n{exp:channel:category_heading channel="{my_channel}"}\n<h2>{category_name}</h2>\n{if category_description}\n<p>{category_description}</p>\n{/if}\n{/exp:channel:category_heading}\n\n\n{exp:channel:entries channel="{my_channel}" orderby="date" sort="desc" limit="15" disable="member_data|trackbacks"}\n\n<div class="entry">\n\n{date_heading}\n<h3 class="date">{entry_date format='' %l, %F %d, %Y ''}</h3>\n{/date_heading}\n\n<h2 class="title">{title}</h2>\n{summary}\n\n{body}\n\n{extended}\n\n<div class="posted">Posted by <a href="{profile_path=member/index}">{author}</a> on {entry_date format=''%m/%d''} at {entry_date format=''%h:%i %A''}\n\n<br />\n\n{categories}\n<a href="{path=site_index}">{category_name}</a> &#8226;\n{/categories}\n\n{if allow_comments}\n({comment_total}) <a href="{url_title_path="{my_template_group}/comments"}">Comments</a> &#8226;\n{/if}\n\n{if allow_trackbacks}\n({trackback_total}) <a href="{trackback_path="{my_template_group}/trackbacks"}">Trackbacks</a> &#8226;\n{/if}\n<a href="{title_permalink={my_template_group}/index}">Permalink</a>\n\n</div>\n\n{paginate}\n\n<div class="paginate">\n\n<span class="pagecount">Page {current_page} of {total_pages} pages</span>  {pagination_links}\n\n</div>\n\n{/paginate}\n\n</div>\n\n{/exp:channel:entries}\n\n</div>\n\n<div id="sidebar">\n\n\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n{exp:channel:calendar switch="calendarToday|calendarCell"}\n\n<table class="calendarBG" border="0" cellpadding="5" cellspacing="1" summary="My Calendar">\n<tr>\n<th class="calendarHeader"><div class="calendarMonthLinks"><a href="{previous_path={my_template_group}/index}">&lt;&lt;</a></div></th>\n<th class="calendarHeader" colspan="5">{date format="%F %Y"}</th>\n<th class="calendarHeader"><div class="calendarMonthLinks"><a class="calendarMonthLinks" href="{next_path={my_template_group}/index}">&gt;&gt;</a></div></th>\n</tr>\n<tr>\n{calendar_heading}\n<td class="calendarDayHeading">{lang:weekday_abrev}</td>\n{/calendar_heading}\n</tr>\n{calendar_rows }\n{row_start}<tr>{/row_start}\n{if entries}<td class=''{switch}'' align=''center''><a href="{day_path={my_template_group}/index}">{day_number}</a></td>{/if}\n{if not_entries}<td class=''{switch}'' align=''center''>{day_number}</td>{/if}\n{if blank}<td class=''calendarBlank''>&nbsp;</td>{/if}\n{row_end}</tr>{/row_end}\n{/calendar_rows}\n</table>\n{/exp:channel:calendar}\n\n\n{exp:search:simple_form search_in="everywhere"}\n<h2 class="sidetitle">Search</h2>\n<p>\n<input type="text" name="keywords" value="" class="input" size="18" maxlength="100" />\n<br />\n<a href="{path=search/index}">Advanced Search</a>\n</p>\n\n<p><input type="submit" value="submit"  class="submit" /></p>\n\n{/exp:search:simple_form}\n\n\n<h2 class="sidetitle">Categories</h2>\n<p>\n{exp:channel:categories channel="{my_channel}" style="nested"}\n<a href="{path={my_template_group}/index}">{category_name}</a>\n{/exp:channel:categories}\n</p>\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n\n\n\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\n<div class="entry">\n<h2 class="sidetitle">Site Statistics</h2>\n\n<p>\nThis page has been viewed {hits} times<br />\nPage rendered in {elapsed_time} seconds<br />\n\n{exp:stats}\nTotal Entries: {total_entries}<br />\nTotal Comments: {total_comments}<br />\nTotal Trackbacks: {total_trackbacks}<br />\nMost Recent Entry: {last_entry_date format="%m/%d/%Y %h:%i %a"}<br />\nMost Recent Comment on:  {last_comment_date format="%m/%d/%Y %h:%i %a"}<br />\nTotal Members: {total_members}<br />\nTotal Logged in members: {total_logged_in}<br />\nTotal guests: {total_guests}<br />\nTotal anonymous users: {total_anon}<br />\nMost Recent Visitor on:  {last_visitor_date format="%m/%d/%Y %h:%i %a"}<br />\nThe most visitors ever was {most_visitors} on  {most_visitor_date format="%m/%d/%Y %h:%i %a"}\n\n{if member_names}\n<p>Current Logged-in Members:&nbsp;\n{member_names  backspace=''6''}\n<a href="{member_path=member/index}">{name}</a>&nbsp;\n{/member_names}\n</p>\n{/if}\n\n{/exp:stats}\n</p>\n\n<p><a href="{path={my_template_group}/referrers}">Referrers</a></p>\n</div>\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n');
INSERT INTO `exp_revision_tracker` VALUES(3, 17, 'exp_templates', 'template_data', 1279619149, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(4, 20, 'exp_templates', 'template_data', 1279619156, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(5, 18, 'exp_templates', 'template_data', 1279619215, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(6, 19, 'exp_templates', 'template_data', 1279619225, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(7, 27, 'exp_templates', 'template_data', 1279619492, 1, '</body>\n</html>\n');
INSERT INTO `exp_revision_tracker` VALUES(8, 28, 'exp_templates', 'template_data', 1279619518, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(9, 29, 'exp_templates', 'template_data', 1279619630, 1, '<!DOCTYPE html> \n<html dir="ltr" lang="en-US">\n');
INSERT INTO `exp_revision_tracker` VALUES(10, 30, 'exp_templates', 'template_data', 1279619647, 1, '<footer>\n	\n	<ul>\n		<li>&copy; 2005&ndash;<?php echo date(''Y''); ?> Dan Mall.</li>\n		<li><a href="#"><abbr title="HyperText Markup Language">HTML</abbr>5</a></li>\n		<li><a href="#"><abbr title="Cascading Style Sheets">CSS</abbr></a></li>\n		<li>Powered by <a href="http://www.expressionengine.com/">ExpressionEngine</a></li>\n		<li>Hosted by <a href="http://www.mediatemple.net/">MediaTemple</a></li>\n	</ul>\n	\n</footer>');
INSERT INTO `exp_revision_tracker` VALUES(11, 31, 'exp_templates', 'template_data', 1279619664, 1, '<div id="masthead-wrap">\n    \n    <section id="masthead" role="banner">\n        <header>\n            <h1><a href="/">Daniel Mall</a></h1>\n        </header>\n	\n    	<nav id="nav">\n        	<ul>\n        		<li><a href="/work/">Work</a></li>\n        		<li><a href="/articles/">Articles</a></li>\n        		<li><a href="/about/">About</a></li>\n        		<li><a href="/contact/">Contact</a></li>\n        	</ul>\n        </nav><?php ''/#nav'' ?>\n\n        <?php /* ?>\n    	<form id="site-search" action="#" method="post">\n	\n    		<p>\n    			<label for="site-search-box">Search this site</label>\n    			<input type="text" class="filled" id="site-search-box" value="Semantic Flash" />\n    		</p>\n    		<p class="submit"><input type="image" src="/i/widgets/search.gif" alt="Search" /></p>\n	\n    	</form><?php ''/#site-search'' */ ?>\n\n\n    </section><?php ''/#masthead'' ?>\n    \n\n</div><?php ''/#masthead-wrap'' ?>');
INSERT INTO `exp_revision_tracker` VALUES(12, 32, 'exp_templates', 'template_data', 1279619694, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(13, 33, 'exp_templates', 'template_data', 1279619723, 1, '<meta charset="UTF-8" /> \n    <meta name="author" content="Dan Mall" />\n    <meta name="description" content="" />\n    <meta name="viewport" content="width=800" />\n    <link rel="shortcut icon" type="image/ico" href="/favicon.ico" />');
INSERT INTO `exp_revision_tracker` VALUES(14, 29, 'exp_templates', 'template_data', 1279619937, 1, '<!DOCTYPE html> \n<html dir="ltr" lang="en-US">\n');
INSERT INTO `exp_revision_tracker` VALUES(15, 16, 'exp_templates', 'template_data', 1279623746, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(17, 38, 'exp_templates', 'template_data', 1280396062, 1, '<div id="fusion">\n    \n    <span class="fusionentire"> <a href="#"><img src="/i/fusion-test.png" width="130" height="100" alt="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." title="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." border="0" class="fusionimg"></a><br><span class="fusiontext"><a href="#">Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple.</a></span></span><div id="beacon_a57a4f432e" style="position: absolute; left: 0px; top: 0px; visibility: hidden;" class="fusionbeacon"></div>\n    <br><a class="powered" href="#" title="Powered by Fusion Ads">Powered by Fusion</a>\n\n    \n\n</div><?php ''/#fusion'' ?>');
INSERT INTO `exp_revision_tracker` VALUES(18, 39, 'exp_templates', 'template_data', 1280666646, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(19, 41, 'exp_templates', 'template_data', 1280745111, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(20, 40, 'exp_templates', 'template_data', 1280745117, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(21, 42, 'exp_templates', 'template_data', 1284490727, 1, '');
INSERT INTO `exp_revision_tracker` VALUES(22, 43, 'exp_templates', 'template_data', 1299298788, 1, '<div id="fusion">\n    \n    <span class="fusionentire"> <a href="#"><img src="/i/fusion-test.png" width="130" height="100" alt="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." title="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." border="0" class="fusionimg"></a><br><span class="fusiontext"><a href="#">Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple.</a></span></span><div id="beacon_a57a4f432e" style="position: absolute; left: 0px; top: 0px; visibility: hidden;" class="fusionbeacon"></div>\n    <br><a class="powered" href="#" title="Powered by Fusion Ads">Powered by Fusion</a>\n\n    \n\n</div><?php ''/#fusion'' ?>');
INSERT INTO `exp_revision_tracker` VALUES(23, 42, 'exp_templates', 'template_data', 1301847083, 1, '{exp:channel:entries channel="work" limit="1" orderby="work-order" sort="desc" status="open" show_future_entries="yes"}\n{embed="_inc/.doctype"}\n<head>\n    <title>&ldquo;{title},&rdquo; work by Dan Mall</title>\n    {embed="_inc/.meta"}\n    {embed="_inc/.cssReference"}\n    {embed="_inc/.jsReference"}   \n    {if work-head != ""}\n    \n    <!-- custom styles and script for this page -->\n    {work-head}\n    {/if}\n</head>\n\n<body id="work">	\n	\n	{embed="_inc/.header"}\n	\n	<div id="work-area-wrap">\n	    \n	    <section id="work-area" class="wrap800">\n	        \n	        <nav class="breadcrumbs">	            \n	            <ul>\n	                <li id="breadcrumbs-home"><a href="/">Home</a></li>\n	                <li id="breadcrumbs-work"><a href="/work/">Work</a></li>\n	            </ul>\n	        </nav><!-- .breadcrumbs -->\n	        \n	        <div id="project-header">\n    	        <hgroup>\n        	        <h1 class="page-title phark">{title}</h1>\n        	        {if work-subtitle}<h2 class="project-subtitle">{work-subtitle}</h2>{/if}\n        	    </hgroup>\n        	    \n        	    <ul id="project-nav" class="no-marker">\n        	        {if work-prev}\n        	        <li class="prev">        	            \n            	        {work-prev}\n        	        </li>\n        	        {/if}\n        	        {if work-next}\n        	        <li class="next">            	        \n            	        {work-next}            	        \n        	        </li>\n        	        {/if}\n        	    </ul><!-- #project-nav -->\n        	    \n    	    </div><!-- #project-header -->\n	        \n	    </section><!-- #work-area -->\n	    \n	    {work-body-file}\n	    \n	    <?php\n\n	        $yeyeyeye = \\{work-body-file\\};\n	        \n	    ?>\n	    \n	    \n	</div><!-- #work-area-wrap -->\n	\n	{/exp:channel:entries}\n	\n	<div class="wrap">\n    	\n    	{embed="_inc/.footer"}\n    	\n    	\n    </div><!-- #wrap -->\n    \n	\n{embed="_inc/.close"}');

-- --------------------------------------------------------

--
-- Table structure for table `exp_search`
--

CREATE TABLE `exp_search` (
  `search_id` varchar(32) NOT NULL,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `search_date` int(10) NOT NULL,
  `keywords` varchar(60) NOT NULL,
  `member_id` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL,
  `total_results` int(6) NOT NULL,
  `per_page` smallint(3) unsigned NOT NULL,
  `query` longtext,
  `custom_fields` longtext,
  `result_page` varchar(70) NOT NULL,
  PRIMARY KEY (`search_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_search`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_search_log`
--

CREATE TABLE `exp_search_log` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) unsigned NOT NULL,
  `screen_name` varchar(50) NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `search_date` int(10) NOT NULL,
  `search_type` varchar(32) NOT NULL,
  `search_terms` varchar(200) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_search_log`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_security_hashes`
--

CREATE TABLE `exp_security_hashes` (
  `hash_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `date` int(10) unsigned NOT NULL,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `hash` varchar(40) NOT NULL,
  PRIMARY KEY (`hash_id`),
  KEY `hash` (`hash`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4966 ;

--
-- Dumping data for table `exp_security_hashes`
--

INSERT INTO `exp_security_hashes` VALUES(4964, 1304513818, '0.0.0.0', 'fdb6c14515bd72520e98ca4e6ade07e8d8f54bf1');
INSERT INTO `exp_security_hashes` VALUES(4965, 1304513877, '0.0.0.0', 'b7349c34035ef94224d7a0f7be0ae2ef4cc81e44');
INSERT INTO `exp_security_hashes` VALUES(4961, 1304513637, '0.0.0.0', 'd755a80265fc993cc15c0e482b17ac710095565d');
INSERT INTO `exp_security_hashes` VALUES(4962, 1304513698, '0.0.0.0', 'e812b5b24a419fd6f6d809e1fe90ab17e9279f6b');
INSERT INTO `exp_security_hashes` VALUES(4963, 1304513757, '0.0.0.0', '42dcb4506aab00f17451bb0858bf10c9f130e464');
INSERT INTO `exp_security_hashes` VALUES(4958, 1304513518, '0.0.0.0', '46484c88c4a1ffaed253ef525f47c8bca7b1600b');
INSERT INTO `exp_security_hashes` VALUES(4959, 1304513518, '0.0.0.0', '74b71f1f03a7a71f2f63207d96a60b76f1f87792');
INSERT INTO `exp_security_hashes` VALUES(4960, 1304513578, '0.0.0.0', 'd338a70698e7b8ec7b3303e11f6c4c8424a31e6b');
INSERT INTO `exp_security_hashes` VALUES(4956, 1304513514, '0.0.0.0', 'f11b4d98fe66b6e51ee009e5a451d4a283aec7bc');
INSERT INTO `exp_security_hashes` VALUES(4957, 1304513517, '0.0.0.0', '834efb3f817fa980e58bc52d526175849d82aea5');
INSERT INTO `exp_security_hashes` VALUES(4954, 1304513511, '0.0.0.0', 'fc52c4b63e02c90e1cd7f40fc750a4f217b146e4');
INSERT INTO `exp_security_hashes` VALUES(4955, 1304513513, '0.0.0.0', '7e69cd3734cb2304e09d19dd853f5a58c9867f79');
INSERT INTO `exp_security_hashes` VALUES(4946, 1304508766, '0.0.0.0', '40c88060a36084143bd492eddf1e252f0db03815');
INSERT INTO `exp_security_hashes` VALUES(4947, 1304508767, '0.0.0.0', '19d83de5e762705a961e2cacdea6742c09e8b7a9');
INSERT INTO `exp_security_hashes` VALUES(4948, 1304508767, '0.0.0.0', 'c0440c7618a61384d76ef83feaf70cf9d1787d65');
INSERT INTO `exp_security_hashes` VALUES(4949, 1304508772, '0.0.0.0', 'feb002d74bf352bac40072c167c908711cb7b800');
INSERT INTO `exp_security_hashes` VALUES(4950, 1304508773, '0.0.0.0', '5dd9bab88ba31a9424460341a2628080b6666690');
INSERT INTO `exp_security_hashes` VALUES(4951, 1304508773, '0.0.0.0', 'df01add6e206676913f5e3dd00a79b7033de13fb');
INSERT INTO `exp_security_hashes` VALUES(4952, 1304508773, '0.0.0.0', '5fa09218080e4bb13bf179861ba06a0806b8ce0d');
INSERT INTO `exp_security_hashes` VALUES(4953, 1304508773, '192.168.244.1', '8ea9e8634c594f34c2b24f35848a7d28d3cdeeda');
INSERT INTO `exp_security_hashes` VALUES(4945, 1304508765, '0.0.0.0', 'bebe24a566d785ae5247309880893397f49cfb1a');
INSERT INTO `exp_security_hashes` VALUES(4944, 1304508764, '0.0.0.0', '0e95b204e2e189b3ebcf91515d1344c209a11b1f');
INSERT INTO `exp_security_hashes` VALUES(4943, 1304508763, '192.168.244.1', '3c5a07943690278d53e7b39b63d99b5742723848');
INSERT INTO `exp_security_hashes` VALUES(4942, 1304508762, '0.0.0.0', '8ceff582ae2ee34c74e6571e92e9cc916f6bfa54');
INSERT INTO `exp_security_hashes` VALUES(4941, 1304507469, '0.0.0.0', '8d380235019dab0290c15e9bf69d1c967e5f2d94');
INSERT INTO `exp_security_hashes` VALUES(4940, 1304507469, '0.0.0.0', 'a5170416da9dc7d6515a76450613e06f8e811f55');
INSERT INTO `exp_security_hashes` VALUES(4939, 1304507469, '0.0.0.0', 'e136a48f27c077cc4c5d2a8625bffe0cf010ecf7');
INSERT INTO `exp_security_hashes` VALUES(4935, 1304507371, '0.0.0.0', 'a907857b23105bd02787edc5e3a983f3c2b77fb3');
INSERT INTO `exp_security_hashes` VALUES(4936, 1304507417, '0.0.0.0', 'c93142234cfbcba6cac1b42e2083adc76ae115ab');
INSERT INTO `exp_security_hashes` VALUES(4937, 1304507417, '0.0.0.0', 'd7f90e655b7f0c383f9b4281e235e066e0d06c05');
INSERT INTO `exp_security_hashes` VALUES(4938, 1304507469, '0.0.0.0', 'fa020c6d851737b0d9006d945f7f9d42fa5ef0ee');
INSERT INTO `exp_security_hashes` VALUES(4934, 1304507371, '0.0.0.0', '07bae38c8f31ea26ab1fce2c3bc59b3cf36ff6eb');
INSERT INTO `exp_security_hashes` VALUES(4933, 1304507330, '0.0.0.0', '45a423a73a925d2e1b6b26ecec9d3e82352c17c8');
INSERT INTO `exp_security_hashes` VALUES(4932, 1304507330, '0.0.0.0', '6e0c5215cfb2c12987f1d655f8dc903071b785e2');
INSERT INTO `exp_security_hashes` VALUES(4931, 1304507329, '0.0.0.0', 'e9f73513ed1ed66ee556b51a16b391f156b31de1');
INSERT INTO `exp_security_hashes` VALUES(4930, 1304507272, '0.0.0.0', '1f9ca942be5e0bafd6181bbd5b31bd5b50666179');
INSERT INTO `exp_security_hashes` VALUES(4929, 1304507272, '0.0.0.0', '9ecb5d4333429e9cee2227cc4f6f5b57bee96f94');
INSERT INTO `exp_security_hashes` VALUES(4928, 1304507235, '0.0.0.0', '918a9f535ac4f302d5a64f4196b19464943b6efe');
INSERT INTO `exp_security_hashes` VALUES(4925, 1304507226, '0.0.0.0', '3a1040f4c12fa553aecf6eb6374ca84bb81ce780');
INSERT INTO `exp_security_hashes` VALUES(4926, 1304507226, '0.0.0.0', 'a7b566686d20ebe062b6af25f7f0260f3a5e2172');
INSERT INTO `exp_security_hashes` VALUES(4927, 1304507235, '0.0.0.0', '36612c852a46c9ecbae77e68b48e5b5691fb9511');
INSERT INTO `exp_security_hashes` VALUES(4924, 1304507226, '0.0.0.0', 'ae36dc79a04db345587c70e19f2597137a176fec');
INSERT INTO `exp_security_hashes` VALUES(4921, 1304507222, '0.0.0.0', '8c86871ab3466153920958563ba9014d9b25508d');
INSERT INTO `exp_security_hashes` VALUES(4922, 1304507222, '0.0.0.0', '63ae0d8c5935b61f98f71e6e66e6a120d204cafd');
INSERT INTO `exp_security_hashes` VALUES(4923, 1304507224, '0.0.0.0', '46c9d131a065e9fe646315ba6f9358d3395f3d97');
INSERT INTO `exp_security_hashes` VALUES(4918, 1304507027, '192.168.244.1', 'fda1c1fa08b120188f92727edfe7d29e92051e1b');
INSERT INTO `exp_security_hashes` VALUES(4919, 1304507027, '192.168.244.1', '1607e93ed143b3aae55c03f1fc4c7ce75b67f7be');
INSERT INTO `exp_security_hashes` VALUES(4920, 1304507220, '0.0.0.0', '6f7bc916f5a852fb62fb3ee20971f2aa9a43f9ff');
INSERT INTO `exp_security_hashes` VALUES(4917, 1304506966, '0.0.0.0', '3e2f218661317b43490d9a72607b3cc53157a89d');
INSERT INTO `exp_security_hashes` VALUES(4916, 1304506906, '0.0.0.0', '17123203c9fb84ed15853de01fe702d3d8445081');
INSERT INTO `exp_security_hashes` VALUES(4915, 1304506846, '0.0.0.0', '9cfefd075c1e83529843738c88e52af1821ac043');
INSERT INTO `exp_security_hashes` VALUES(4914, 1304506786, '0.0.0.0', '3f93b46a56852f7253d47b65aa065b571bac175a');
INSERT INTO `exp_security_hashes` VALUES(4913, 1304506726, '0.0.0.0', 'b9da8072ac37ef6a3ee7a6a6bafc89f5a33089db');
INSERT INTO `exp_security_hashes` VALUES(4912, 1304506666, '0.0.0.0', '86d8dd0d2ff052f1c7953de2eba5aba5d910ee5a');
INSERT INTO `exp_security_hashes` VALUES(4911, 1304506606, '0.0.0.0', 'fb3ab7ad9940e37241b13dec85f68665841b0621');
INSERT INTO `exp_security_hashes` VALUES(4910, 1304506606, '0.0.0.0', '928010fd010e391da65e17d394e6a21e011882ee');
INSERT INTO `exp_security_hashes` VALUES(4909, 1304506605, '0.0.0.0', 'defceb967da422bac0b149cc1d96fdc916b2b176');
INSERT INTO `exp_security_hashes` VALUES(4908, 1304506603, '0.0.0.0', '26710bd9f0eae06dc0479a971a5eb696d89a74a2');
INSERT INTO `exp_security_hashes` VALUES(4907, 1304506602, '192.168.244.1', '892f65ce37a174cfafb92e0c6b46edb0111ac683');
INSERT INTO `exp_security_hashes` VALUES(4906, 1304506602, '0.0.0.0', 'f1b6715d6ca0505988318978bece5fc395e3707b');
INSERT INTO `exp_security_hashes` VALUES(4905, 1304506532, '192.168.244.1', '9c96ccda529cfc8f1ef17278880790b9f0e3bd70');
INSERT INTO `exp_security_hashes` VALUES(4832, 1304505224, '0.0.0.0', '5a2a28b999be71316d0197b92e90bc45a0f1f6ee');
INSERT INTO `exp_security_hashes` VALUES(4904, 1304506532, '192.168.244.1', '6317afd12a39d78acead16596e4f9b8c128cb88b');
INSERT INTO `exp_security_hashes` VALUES(4903, 1304506532, '192.168.244.1', '539e552e9539315358d9d85dc62dc142008d3b38');
INSERT INTO `exp_security_hashes` VALUES(4902, 1304506532, '0.0.0.0', '95074dd2dea2a36bd4b53c1bf7e7db2a2b93fba7');
INSERT INTO `exp_security_hashes` VALUES(4900, 1304506532, '0.0.0.0', 'f5afbb7443f7caaba74ab3cbc18ba9a888403c2c');
INSERT INTO `exp_security_hashes` VALUES(4901, 1304506532, '0.0.0.0', 'ce3926953a8e5f8e0c19903500873cf2ca0dfc3e');
INSERT INTO `exp_security_hashes` VALUES(4825, 1304423626, '192.168.244.1', '81ab646d56af6c2da38172e34c92fe823bb6bed2');
INSERT INTO `exp_security_hashes` VALUES(4899, 1304506530, '0.0.0.0', '4ae4b1d7cc36da01914a0a152889f40805277369');
INSERT INTO `exp_security_hashes` VALUES(4898, 1304506530, '0.0.0.0', '3a1890f8a1571700c4c9643f2328516c56127261');
INSERT INTO `exp_security_hashes` VALUES(4823, 1304423608, '192.168.244.1', '4f8a4d306844d16fbd7235c9e19303c9a4819c2f');
INSERT INTO `exp_security_hashes` VALUES(4897, 1304506530, '0.0.0.0', '1a333fbf37f57fcc5b49f30f74fef5c2fe0fe6ad');
INSERT INTO `exp_security_hashes` VALUES(4896, 1304506529, '0.0.0.0', '2f987356836f53148b7ddedaca8d42cdeaa6f9ed');
INSERT INTO `exp_security_hashes` VALUES(4895, 1304506513, '0.0.0.0', 'beca142f6b8c561dcf297aedee317958872008d1');
INSERT INTO `exp_security_hashes` VALUES(4894, 1304506512, '0.0.0.0', '9578cd5fd8bd3057122230adfec591099ab68539');
INSERT INTO `exp_security_hashes` VALUES(4893, 1304506508, '0.0.0.0', 'bf69e0bd54ee0b1ffb2fe55c5ebc9344bb27e335');
INSERT INTO `exp_security_hashes` VALUES(4889, 1304506496, '0.0.0.0', '3d2caeef6e54dc751541f353df937cbc2c688c5e');
INSERT INTO `exp_security_hashes` VALUES(4890, 1304506496, '0.0.0.0', 'd0e43ea8ddd508de1da2eee814e5b056e4a3dbc8');
INSERT INTO `exp_security_hashes` VALUES(4891, 1304506496, '0.0.0.0', 'ed907a5c433df2393a317eb09862dd8ac97bd44d');
INSERT INTO `exp_security_hashes` VALUES(4892, 1304506507, '0.0.0.0', '7b9e36df0de7460f601fa52dfaa9a62ac9effe94');
INSERT INTO `exp_security_hashes` VALUES(4885, 1304506491, '0.0.0.0', '7e1be17b83289ae0df587c12e9cb5d0cabf0ff9b');
INSERT INTO `exp_security_hashes` VALUES(4886, 1304506492, '0.0.0.0', '64cd5a86bce92f199090fd15a6f39d0485c1b66a');
INSERT INTO `exp_security_hashes` VALUES(4887, 1304506492, '0.0.0.0', 'abcd04fddd3764dda794d31710aef8213ed942ee');
INSERT INTO `exp_security_hashes` VALUES(4888, 1304506495, '0.0.0.0', 'cce160dcdeb84c240b20eb417eb03be4143b710c');
INSERT INTO `exp_security_hashes` VALUES(4884, 1304506487, '0.0.0.0', '3e1f24cd58ad2a046974195db934d3198947f308');
INSERT INTO `exp_security_hashes` VALUES(4883, 1304506487, '0.0.0.0', '513511eaa7e5cf5ad168622dc19e4bedfc1f6f59');
INSERT INTO `exp_security_hashes` VALUES(4882, 1304506483, '0.0.0.0', '6fbd8e703e53664299ab756686497b5e6af140a8');
INSERT INTO `exp_security_hashes` VALUES(4881, 1304506482, '0.0.0.0', 'fcc2a61706a1ce92aeeb9c807e6b1ba44ce41f26');
INSERT INTO `exp_security_hashes` VALUES(4880, 1304506451, '192.168.244.1', 'f5232ddf3f4848fdaa1e1b5842e321ba0c6284b1');
INSERT INTO `exp_security_hashes` VALUES(4879, 1304506451, '192.168.244.1', '7c6407ac4327e58b8ac7907be2ec4aff777c78ac');
INSERT INTO `exp_security_hashes` VALUES(4878, 1304506411, '0.0.0.0', 'f6ae0053629deb022faf384db1bd057bbba8a8a1');
INSERT INTO `exp_security_hashes` VALUES(4877, 1304506411, '0.0.0.0', 'b2e566715de0db4e8fc51137bfb405f4de545db9');
INSERT INTO `exp_security_hashes` VALUES(4876, 1304506402, '0.0.0.0', '3620de8e7892ce2d9235b75780a5e27d3d7ba1da');
INSERT INTO `exp_security_hashes` VALUES(4875, 1304506402, '0.0.0.0', '897746cdc3a1a58aff2646d21cb82d317fd557ca');
INSERT INTO `exp_security_hashes` VALUES(4746, 1304371869, '192.168.244.1', '2b125f362c0eda6467502d018e0d1ad464678597');
INSERT INTO `exp_security_hashes` VALUES(4874, 1304506402, '0.0.0.0', '959736d371d51f736b27aeeb31558aa512f21ef3');
INSERT INTO `exp_security_hashes` VALUES(4873, 1304506390, '0.0.0.0', 'c231251a883c9d453f0844f1bee5f6f9d545e79b');
INSERT INTO `exp_security_hashes` VALUES(4872, 1304506375, '0.0.0.0', '21eb4340943b54f4b5abb9d3a61c35fbb6cb1f52');
INSERT INTO `exp_security_hashes` VALUES(4871, 1304506374, '0.0.0.0', 'cf585fc0ff9a7a8b84ffe9787ecf3786dacc7d7f');
INSERT INTO `exp_security_hashes` VALUES(4870, 1304506330, '0.0.0.0', '9dfe685068bfb686b8744f015d2c081d99afa02b');
INSERT INTO `exp_security_hashes` VALUES(4869, 1304506315, '0.0.0.0', 'eb03afbf9e7fb6a34996ff10ab3009f83788df1b');
INSERT INTO `exp_security_hashes` VALUES(4868, 1304506270, '0.0.0.0', '368d2c01cfc295fc36a5cdb6dcb0b5bb51dc9651');
INSERT INTO `exp_security_hashes` VALUES(4867, 1304506255, '0.0.0.0', '70f1845860c6bf95d605c454ae81fd909715d78f');
INSERT INTO `exp_security_hashes` VALUES(4866, 1304506255, '0.0.0.0', 'a3603fa39a4690bee47d79ed115ada3df56b793f');
INSERT INTO `exp_security_hashes` VALUES(4865, 1304506255, '0.0.0.0', '281331c708230562219049e6b44bd2e75b811e21');
INSERT INTO `exp_security_hashes` VALUES(4864, 1304506241, '0.0.0.0', 'dc87990f95eeb106ba6732bdf77c6c85fbc703a4');
INSERT INTO `exp_security_hashes` VALUES(4863, 1304506241, '0.0.0.0', 'fd017444f444dfca03b945f2eed3c2e1e8fdc0d3');
INSERT INTO `exp_security_hashes` VALUES(4862, 1304506210, '0.0.0.0', '301e12cb369883cfa3abef08c8542b23a837bd25');
INSERT INTO `exp_security_hashes` VALUES(4861, 1304506201, '0.0.0.0', '05b02f068d297db0574738e66a296a5a6dab7259');
INSERT INTO `exp_security_hashes` VALUES(4860, 1304506201, '0.0.0.0', '247fd98c1402740e08df36512e73f7e7a3134978');
INSERT INTO `exp_security_hashes` VALUES(4859, 1304506200, '0.0.0.0', 'ba342af48df1bee90f022d9b926db530130f9773');
INSERT INTO `exp_security_hashes` VALUES(4858, 1304506196, '0.0.0.0', '6cdb6582716ece6261bb5d506c67cc41587a4ef5');
INSERT INTO `exp_security_hashes` VALUES(4857, 1304506196, '0.0.0.0', 'f371f2959c85168f0caaaf62b8fab55372ea19e1');
INSERT INTO `exp_security_hashes` VALUES(4743, 1304371869, '192.168.244.1', 'd7561f91e1500b13b021752bce628d2df6d80174');
INSERT INTO `exp_security_hashes` VALUES(4742, 1304371868, '192.168.244.1', 'e9e64170df96cd6866dc53056d1296c547438537');
INSERT INTO `exp_security_hashes` VALUES(4856, 1304506176, '0.0.0.0', 'f7822257466ef479a221509b7cd190fc2c661db1');
INSERT INTO `exp_security_hashes` VALUES(4741, 1304371859, '192.168.244.1', 'c31dc0ad7e2eece2914e6ebc88557d9e3937120f');
INSERT INTO `exp_security_hashes` VALUES(4740, 1304371859, '192.168.244.1', '4c5271bca0c7cd210645ce75f9fd62b9d8f33578');
INSERT INTO `exp_security_hashes` VALUES(4739, 1304371859, '192.168.244.1', '25cd293a1bb5907af0303ee28b9c2c0b9f1c62e4');
INSERT INTO `exp_security_hashes` VALUES(4738, 1304371858, '192.168.244.1', '185d34fcfb0dbf4dd580acb0ffb799618c11b6de');
INSERT INTO `exp_security_hashes` VALUES(4855, 1304506150, '0.0.0.0', '3e364c8b606268f8365ac079aaf5c4c506e31f23');
INSERT INTO `exp_security_hashes` VALUES(4737, 1304371856, '192.168.244.1', '6fe01c66a09a61ca2c738d2fef1d2cba7d305f1b');
INSERT INTO `exp_security_hashes` VALUES(4736, 1304371856, '192.168.244.1', 'ccf460453a80fcb1be19bbb03be24f38bcd683c9');
INSERT INTO `exp_security_hashes` VALUES(4854, 1304506116, '0.0.0.0', '16138f01242d1428d98e21a25e15093e11aa5d70');
INSERT INTO `exp_security_hashes` VALUES(4853, 1304506090, '0.0.0.0', '1aec075181860d6c1f212d1f78f4e7b2d053e1b3');
INSERT INTO `exp_security_hashes` VALUES(4733, 1304371854, '192.168.244.1', 'fefad2b99122be73f770c1a75c3f28588cc4e38a');
INSERT INTO `exp_security_hashes` VALUES(4732, 1304371852, '192.168.244.1', '787c13cd26b09ebbb8d4c529612fcbbc6b02a537');
INSERT INTO `exp_security_hashes` VALUES(4731, 1304371851, '192.168.244.1', '81022421c1822b58d76d3449ee2393ed5a113813');
INSERT INTO `exp_security_hashes` VALUES(4852, 1304506056, '0.0.0.0', 'd008efeef49a5d8ce86d98b4cc7050ec295453be');
INSERT INTO `exp_security_hashes` VALUES(4729, 1304371851, '192.168.244.1', '4db562356a788a0f112ae3de12da2680bd895386');
INSERT INTO `exp_security_hashes` VALUES(4851, 1304506056, '0.0.0.0', 'b42c18b6348977d248ac299c99985f82a2108a7b');
INSERT INTO `exp_security_hashes` VALUES(4728, 1304371851, '192.168.244.1', 'eaece275521bd02326dbcf8aac43415cc2f550b4');
INSERT INTO `exp_security_hashes` VALUES(4850, 1304506056, '0.0.0.0', 'd3b051baf07aebdd8ecbe1ab2862a123718c7f8a');
INSERT INTO `exp_security_hashes` VALUES(4849, 1304506052, '0.0.0.0', 'f7db01281df7f44ad5dfa68d2e1ce555d42c3536');
INSERT INTO `exp_security_hashes` VALUES(4848, 1304506052, '0.0.0.0', 'd896eb292c15bf93a1842f7688a10109b88b65a3');
INSERT INTO `exp_security_hashes` VALUES(4847, 1304506036, '0.0.0.0', '5314b7e6e28be82863181c6aceec8e4b8d3f2ab6');
INSERT INTO `exp_security_hashes` VALUES(4846, 1304506036, '0.0.0.0', '1efcce107f8fbf6b4e5e40b47afa035262096500');
INSERT INTO `exp_security_hashes` VALUES(4845, 1304506035, '0.0.0.0', '852136ab3062d2b4fb61e0abf74a17507bbdb4b2');
INSERT INTO `exp_security_hashes` VALUES(4844, 1304506034, '0.0.0.0', 'a7910a82cd7672fefe4ad6e25afd2ef74b37f77a');
INSERT INTO `exp_security_hashes` VALUES(4843, 1304506033, '0.0.0.0', '805e5f6e3f1f3238208e73741d19748c8479424b');
INSERT INTO `exp_security_hashes` VALUES(4842, 1304506030, '0.0.0.0', 'c926ebc2ada09f61e92deb2ec77c584714dede7b');
INSERT INTO `exp_security_hashes` VALUES(4841, 1304506030, '0.0.0.0', 'da27fea640b1848ee4213549a9ba235d74bdfa40');
INSERT INTO `exp_security_hashes` VALUES(4840, 1304506029, '0.0.0.0', '8500eb2b0b570cf348daa1635ebcdfb148c57d4e');
INSERT INTO `exp_security_hashes` VALUES(4839, 1304506027, '0.0.0.0', '8a3ce03eca494def76e5a52f6f4e96a9353dcdfc');
INSERT INTO `exp_security_hashes` VALUES(4838, 1304506026, '0.0.0.0', '05c1d83dfa0f80dd311758e0a5dbc5c6bd994a86');
INSERT INTO `exp_security_hashes` VALUES(4837, 1304506024, '0.0.0.0', '4d1d9e577ba91b3e4e62677e9a99c01f2ed40556');
INSERT INTO `exp_security_hashes` VALUES(4836, 1304505243, '192.168.244.1', '26b5f9a774887dcfc55667bcda9d322618fd95f7');
INSERT INTO `exp_security_hashes` VALUES(4835, 1304505242, '0.0.0.0', '8a6de201e8efefae6513089169463f01dc991f57');
INSERT INTO `exp_security_hashes` VALUES(4834, 1304505239, '0.0.0.0', '58fa00734581f825a988cc0b1dbf83475717b933');
INSERT INTO `exp_security_hashes` VALUES(4833, 1304505239, '0.0.0.0', 'ac277d94a180f9d0d3e283fe473aaf82b1a4c80b');
INSERT INTO `exp_security_hashes` VALUES(4727, 1304371850, '192.168.244.1', 'ce11dab463ec60068c5677be4ee0be62c02986e9');

-- --------------------------------------------------------

--
-- Table structure for table `exp_sessions`
--

CREATE TABLE `exp_sessions` (
  `session_id` varchar(40) NOT NULL DEFAULT '0',
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `member_id` int(10) NOT NULL DEFAULT '0',
  `admin_sess` tinyint(1) NOT NULL DEFAULT '0',
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `user_agent` varchar(50) NOT NULL,
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`session_id`),
  KEY `member_id` (`member_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_sessions`
--

INSERT INTO `exp_sessions` VALUES('c3573ebf69b6c535bd1228d3d89b1f0b44a8f475', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304508290);
INSERT INTO `exp_sessions` VALUES('0f32e534d58cfa2b568718d68efda97195565ac1', 1, 1, 1, '192.168.244.1', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304508473);
INSERT INTO `exp_sessions` VALUES('c5241fcf84f1968226f69ed4078fe28ce7a963f3', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304508660);
INSERT INTO `exp_sessions` VALUES('f4ccae946ea89b9b7e929ce3331c7d5e36c8ba07', 1, 1, 1, '192.168.244.1', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304508691);
INSERT INTO `exp_sessions` VALUES('95d71838f50fc77c57f527baa4de27f537931e3c', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304508797);
INSERT INTO `exp_sessions` VALUES('1b93070677753d259135528a8bdebcc15cf0dce3', 1, 1, 1, '192.168.244.1', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304509056);
INSERT INTO `exp_sessions` VALUES('95d4bc782d2d0db0a77cc01d33bb87bd553dcda7', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304509795);
INSERT INTO `exp_sessions` VALUES('5060e44b72a0f2b4570f4be84a99de5ee11415a9', 1, 1, 1, '192.168.244.1', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304509958);
INSERT INTO `exp_sessions` VALUES('291c65f7e36f6ea845b250c6a1de12924a512e1b', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304513877);
INSERT INTO `exp_sessions` VALUES('e8747fff22100cd53af5040c93ec5c0ad92b13c7', 1, 1, 1, '192.168.244.1', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304505484);
INSERT INTO `exp_sessions` VALUES('7147665e4ee9f55f1966262748746fb2523c33c2', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304505340);
INSERT INTO `exp_sessions` VALUES('4d55f7fd308b89a4c91939302c446ca471063b61', 1, 1, 1, '192.168.244.1', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304505298);
INSERT INTO `exp_sessions` VALUES('897a363ccdb91ed82285b92a43d29b1f79c073d0', 1, 1, 1, '0.0.0.0', 'Mozilla/5.0 (Macintosh; U; Intel Mac OS X 10_6_7; ', 1304505298);

-- --------------------------------------------------------

--
-- Table structure for table `exp_sites`
--

CREATE TABLE `exp_sites` (
  `site_id` int(5) unsigned NOT NULL AUTO_INCREMENT,
  `site_label` varchar(100) NOT NULL DEFAULT '',
  `site_name` varchar(50) NOT NULL DEFAULT '',
  `site_description` text,
  `site_system_preferences` mediumtext NOT NULL,
  `site_mailinglist_preferences` mediumtext NOT NULL,
  `site_member_preferences` mediumtext NOT NULL,
  `site_template_preferences` mediumtext NOT NULL,
  `site_channel_preferences` text NOT NULL,
  `site_bootstrap_checksums` text NOT NULL,
  PRIMARY KEY (`site_id`),
  KEY `site_name` (`site_name`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exp_sites`
--

INSERT INTO `exp_sites` VALUES(1, 'Daniel Mall', 'default_site', '', 'YTo5ODp7czoxNToiZW5jcnlwdGlvbl90eXBlIjtzOjQ6InNoYTEiO3M6MTA6InNpdGVfaW5kZXgiO3M6MDoiIjtzOjk6InNpdGVfbmFtZSI7czoxMToiRGFuaWVsIE1hbGwiO3M6ODoic2l0ZV91cmwiO3M6MjI6Imh0dHA6Ly9kYW4ubG9jYWw6ODg4OC8iO3M6MTY6InRoZW1lX2ZvbGRlcl91cmwiO3M6Mjk6Imh0dHA6Ly9kYW4ubG9jYWw6ODg4OC90aGVtZXMvIjtzOjE1OiJ3ZWJtYXN0ZXJfZW1haWwiO3M6MTg6ImRhbkBkYW5pZWxtYWxsLmNvbSI7czoxNDoid2VibWFzdGVyX25hbWUiO3M6MDoiIjtzOjE5OiJ3ZWJsb2dfbm9tZW5jbGF0dXJlIjtzOjY6IndlYmxvZyI7czoxMDoibWF4X2NhY2hlcyI7czozOiIxNTAiO3M6MTE6ImNhcHRjaGFfdXJsIjtzOjM4OiJodHRwOi8vZGFuLmxvY2FsOjg4ODgvaW1hZ2VzL2NhcHRjaGFzLyI7czoxMjoiY2FwdGNoYV9wYXRoIjtzOjU3OiIvVXNlcnMvZGFuaWVsbWFsbC9TaXRlcy9oeWJyaWQvdHJ1bmsvYmluL2ltYWdlcy9jYXB0Y2hhcy8iO3M6MTI6ImNhcHRjaGFfZm9udCI7czoxOiJ5IjtzOjEyOiJjYXB0Y2hhX3JhbmQiO3M6MToieSI7czoyMzoiY2FwdGNoYV9yZXF1aXJlX21lbWJlcnMiO3M6MToibiI7czoxNzoiZW5hYmxlX2RiX2NhY2hpbmciO3M6MToieSI7czoxODoiZW5hYmxlX3NxbF9jYWNoaW5nIjtzOjE6Im4iO3M6MTg6ImZvcmNlX3F1ZXJ5X3N0cmluZyI7czoxOiJuIjtzOjE4OiJ0ZW1wbGF0ZV9kZWJ1Z2dpbmciO3M6MToibiI7czoxNToiaW5jbHVkZV9zZWNvbmRzIjtzOjE6Im4iO3M6MTM6ImNvb2tpZV9kb21haW4iO3M6MDoiIjtzOjExOiJjb29raWVfcGF0aCI7czowOiIiO3M6MTc6InVzZXJfc2Vzc2lvbl90eXBlIjtzOjE6ImMiO3M6MTg6ImFkbWluX3Nlc3Npb25fdHlwZSI7czoyOiJjcyI7czoyMToiYWxsb3dfdXNlcm5hbWVfY2hhbmdlIjtzOjE6InkiO3M6MTg6ImFsbG93X211bHRpX2xvZ2lucyI7czoxOiJ5IjtzOjE2OiJwYXNzd29yZF9sb2Nrb3V0IjtzOjE6InkiO3M6MjU6InBhc3N3b3JkX2xvY2tvdXRfaW50ZXJ2YWwiO3M6MToiMSI7czoyMDoicmVxdWlyZV9pcF9mb3JfbG9naW4iO3M6MToibiI7czoyMjoicmVxdWlyZV9pcF9mb3JfcG9zdGluZyI7czoxOiJ5IjtzOjE4OiJhbGxvd19tdWx0aV9lbWFpbHMiO3M6MToibiI7czoyNDoicmVxdWlyZV9zZWN1cmVfcGFzc3dvcmRzIjtzOjE6Im4iO3M6MTk6ImFsbG93X2RpY3Rpb25hcnlfcHciO3M6MToieSI7czoyMzoibmFtZV9vZl9kaWN0aW9uYXJ5X2ZpbGUiO3M6MDoiIjtzOjE3OiJ4c3NfY2xlYW5fdXBsb2FkcyI7czoxOiJ5IjtzOjE1OiJyZWRpcmVjdF9tZXRob2QiO3M6ODoicmVkaXJlY3QiO3M6OToiZGVmdF9sYW5nIjtzOjc6ImVuZ2xpc2giO3M6ODoieG1sX2xhbmciO3M6MjoiZW4iO3M6NzoiY2hhcnNldCI7czo1OiJ1dGYtOCI7czoxMjoic2VuZF9oZWFkZXJzIjtzOjE6InkiO3M6MTE6Imd6aXBfb3V0cHV0IjtzOjE6Im4iO3M6MTM6ImxvZ19yZWZlcnJlcnMiO3M6MToieSI7czoxMzoibWF4X3JlZmVycmVycyI7czozOiI1MDAiO3M6MTE6InRpbWVfZm9ybWF0IjtzOjI6InVzIjtzOjE1OiJzZXJ2ZXJfdGltZXpvbmUiO3M6MzoiVU01IjtzOjEzOiJzZXJ2ZXJfb2Zmc2V0IjtzOjA6IiI7czoxNjoiZGF5bGlnaHRfc2F2aW5ncyI7czoxOiJ5IjtzOjIxOiJkZWZhdWx0X3NpdGVfdGltZXpvbmUiO3M6MzoiVU01IjtzOjE2OiJkZWZhdWx0X3NpdGVfZHN0IjtzOjE6Im4iO3M6MTU6Imhvbm9yX2VudHJ5X2RzdCI7czoxOiJ5IjtzOjEzOiJtYWlsX3Byb3RvY29sIjtzOjQ6Im1haWwiO3M6MTE6InNtdHBfc2VydmVyIjtzOjA6IiI7czoxMzoic210cF91c2VybmFtZSI7czowOiIiO3M6MTM6InNtdHBfcGFzc3dvcmQiO3M6MDoiIjtzOjExOiJlbWFpbF9kZWJ1ZyI7czoxOiJuIjtzOjEzOiJlbWFpbF9jaGFyc2V0IjtzOjU6InV0Zi04IjtzOjE1OiJlbWFpbF9iYXRjaG1vZGUiO3M6MToibiI7czoxNjoiZW1haWxfYmF0Y2hfc2l6ZSI7czowOiIiO3M6MTE6Im1haWxfZm9ybWF0IjtzOjU6InBsYWluIjtzOjk6IndvcmRfd3JhcCI7czoxOiJ5IjtzOjIyOiJlbWFpbF9jb25zb2xlX3RpbWVsb2NrIjtzOjE6IjUiO3M6MjI6ImxvZ19lbWFpbF9jb25zb2xlX21zZ3MiO3M6MToieSI7czo4OiJjcF90aGVtZSI7czo3OiJkZWZhdWx0IjtzOjIxOiJlbWFpbF9tb2R1bGVfY2FwdGNoYXMiO3M6MToibiI7czoxNjoibG9nX3NlYXJjaF90ZXJtcyI7czoxOiJ5IjtzOjEyOiJzZWN1cmVfZm9ybXMiO3M6MToieSI7czoxOToiZGVueV9kdXBsaWNhdGVfZGF0YSI7czoxOiJ5IjtzOjI0OiJyZWRpcmVjdF9zdWJtaXR0ZWRfbGlua3MiO3M6MToibiI7czoxNjoiZW5hYmxlX2NlbnNvcmluZyI7czoxOiJuIjtzOjE0OiJjZW5zb3JlZF93b3JkcyI7czowOiIiO3M6MTg6ImNlbnNvcl9yZXBsYWNlbWVudCI7czowOiIiO3M6MTA6ImJhbm5lZF9pcHMiO3M6MDoiIjtzOjEzOiJiYW5uZWRfZW1haWxzIjtzOjA6IiI7czoxNjoiYmFubmVkX3VzZXJuYW1lcyI7czowOiIiO3M6MTk6ImJhbm5lZF9zY3JlZW5fbmFtZXMiO3M6MDoiIjtzOjEwOiJiYW5fYWN0aW9uIjtzOjg6InJlc3RyaWN0IjtzOjExOiJiYW5fbWVzc2FnZSI7czozNDoiVGhpcyBzaXRlIGlzIGN1cnJlbnRseSB1bmF2YWlsYWJsZSI7czoxNToiYmFuX2Rlc3RpbmF0aW9uIjtzOjIxOiJodHRwOi8vd3d3LnlhaG9vLmNvbS8iO3M6MTY6ImVuYWJsZV9lbW90aWNvbnMiO3M6MToieSI7czoxMzoiZW1vdGljb25fcGF0aCI7czozNzoiaHR0cDovL2Rhbi5sb2NhbDo4ODg4L2ltYWdlcy9zbWlsZXlzLyI7czoxOToicmVjb3VudF9iYXRjaF90b3RhbCI7czo0OiIxMDAwIjtzOjEzOiJyZW1hcF9wbV91cmxzIjtzOjE6Im4iO3M6MTM6InJlbWFwX3BtX2Rlc3QiO3M6MDoiIjtzOjE3OiJuZXdfdmVyc2lvbl9jaGVjayI7czoxOiJ5IjtzOjIwOiJwdWJsaXNoX3RhYl9iZWhhdmlvciI7czo1OiJob3ZlciI7czoxODoic2l0ZXNfdGFiX2JlaGF2aW9yIjtzOjU6ImhvdmVyIjtzOjE3OiJlbmFibGVfdGhyb3R0bGluZyI7czoxOiJuIjtzOjE3OiJiYW5pc2hfbWFza2VkX2lwcyI7czoxOiJ5IjtzOjE0OiJtYXhfcGFnZV9sb2FkcyI7czoyOiIxMCI7czoxMzoidGltZV9pbnRlcnZhbCI7czoxOiI4IjtzOjEyOiJsb2Nrb3V0X3RpbWUiO3M6MjoiMzAiO3M6MTU6ImJhbmlzaG1lbnRfdHlwZSI7czo3OiJtZXNzYWdlIjtzOjE0OiJiYW5pc2htZW50X3VybCI7czowOiIiO3M6MTg6ImJhbmlzaG1lbnRfbWVzc2FnZSI7czo1MDoiWW91IGhhdmUgZXhjZWVkZWQgdGhlIGFsbG93ZWQgcGFnZSBsb2FkIGZyZXF1ZW5jeS4iO3M6MTc6ImVuYWJsZV9zZWFyY2hfbG9nIjtzOjE6InkiO3M6MTk6Im1heF9sb2dnZWRfc2VhcmNoZXMiO3M6MzoiNTAwIjtzOjE3OiJ0aGVtZV9mb2xkZXJfcGF0aCI7czo1NzoiL1VzZXJzL2RhbmllbG1hbGwvU2l0ZXMvaHlicmlkL2JyYW5jaGVzL2VlMi4xL2Jpbi90aGVtZXMvIjtzOjEwOiJpc19zaXRlX29uIjtzOjE6InkiO3M6MTM6InNob3dfcHJvZmlsZXIiO3M6MToibiI7fQ==', 'YTozOntzOjE5OiJtYWlsaW5nbGlzdF9lbmFibGVkIjtzOjE6InkiO3M6MTg6Im1haWxpbmdsaXN0X25vdGlmeSI7czoxOiJuIjtzOjI1OiJtYWlsaW5nbGlzdF9ub3RpZnlfZW1haWxzIjtzOjA6IiI7fQ==', 'YTo0NDp7czoxMDoidW5fbWluX2xlbiI7czoxOiI0IjtzOjEwOiJwd19taW5fbGVuIjtzOjE6IjUiO3M6MjU6ImFsbG93X21lbWJlcl9yZWdpc3RyYXRpb24iO3M6MToieSI7czoyNToiYWxsb3dfbWVtYmVyX2xvY2FsaXphdGlvbiI7czoxOiJ5IjtzOjE4OiJyZXFfbWJyX2FjdGl2YXRpb24iO3M6NToiZW1haWwiO3M6MjM6Im5ld19tZW1iZXJfbm90aWZpY2F0aW9uIjtzOjE6Im4iO3M6MjM6Im1icl9ub3RpZmljYXRpb25fZW1haWxzIjtzOjA6IiI7czoyNDoicmVxdWlyZV90ZXJtc19vZl9zZXJ2aWNlIjtzOjE6InkiO3M6MjI6InVzZV9tZW1iZXJzaGlwX2NhcHRjaGEiO3M6MToibiI7czoyMDoiZGVmYXVsdF9tZW1iZXJfZ3JvdXAiO3M6MToiNSI7czoxNToicHJvZmlsZV90cmlnZ2VyIjtzOjY6Im1lbWJlciI7czoxMjoibWVtYmVyX3RoZW1lIjtzOjc6ImRlZmF1bHQiO3M6MTQ6ImVuYWJsZV9hdmF0YXJzIjtzOjE6InkiO3M6MjA6ImFsbG93X2F2YXRhcl91cGxvYWRzIjtzOjE6Im4iO3M6MTA6ImF2YXRhcl91cmwiO3M6Mzc6Imh0dHA6Ly9kYW4ubG9jYWw6ODg4OC9pbWFnZXMvYXZhdGFycy8iO3M6MTE6ImF2YXRhcl9wYXRoIjtzOjU2OiIvVXNlcnMvZGFuaWVsbWFsbC9TaXRlcy9oeWJyaWQvdHJ1bmsvYmluL2ltYWdlcy9hdmF0YXJzLyI7czoxNjoiYXZhdGFyX21heF93aWR0aCI7czozOiIxMDAiO3M6MTc6ImF2YXRhcl9tYXhfaGVpZ2h0IjtzOjM6IjEwMCI7czoxMzoiYXZhdGFyX21heF9rYiI7czoyOiI1MCI7czoxMzoiZW5hYmxlX3Bob3RvcyI7czoxOiJuIjtzOjk6InBob3RvX3VybCI7czo0MzoiaHR0cDovL2Rhbi5sb2NhbDo4ODg4L2ltYWdlcy9tZW1iZXJfcGhvdG9zLyI7czoxMDoicGhvdG9fcGF0aCI7czo2MjoiL1VzZXJzL2RhbmllbG1hbGwvU2l0ZXMvaHlicmlkL3RydW5rL2Jpbi9pbWFnZXMvbWVtYmVyX3Bob3Rvcy8iO3M6MTU6InBob3RvX21heF93aWR0aCI7czozOiIxMDAiO3M6MTY6InBob3RvX21heF9oZWlnaHQiO3M6MzoiMTAwIjtzOjEyOiJwaG90b19tYXhfa2IiO3M6MjoiNTAiO3M6MTY6ImFsbG93X3NpZ25hdHVyZXMiO3M6MToieSI7czoxMzoic2lnX21heGxlbmd0aCI7czozOiI1MDAiO3M6MjE6InNpZ19hbGxvd19pbWdfaG90bGluayI7czoxOiJuIjtzOjIwOiJzaWdfYWxsb3dfaW1nX3VwbG9hZCI7czoxOiJuIjtzOjExOiJzaWdfaW1nX3VybCI7czo1MToiaHR0cDovL2Rhbi5sb2NhbDo4ODg4L2ltYWdlcy9zaWduYXR1cmVfYXR0YWNobWVudHMvIjtzOjEyOiJzaWdfaW1nX3BhdGgiO3M6NzA6Ii9Vc2Vycy9kYW5pZWxtYWxsL1NpdGVzL2h5YnJpZC90cnVuay9iaW4vaW1hZ2VzL3NpZ25hdHVyZV9hdHRhY2htZW50cy8iO3M6MTc6InNpZ19pbWdfbWF4X3dpZHRoIjtzOjM6IjQ4MCI7czoxODoic2lnX2ltZ19tYXhfaGVpZ2h0IjtzOjI6IjgwIjtzOjE0OiJzaWdfaW1nX21heF9rYiI7czoyOiIzMCI7czoxOToicHJ2X21zZ191cGxvYWRfcGF0aCI7czo2MzoiL1VzZXJzL2RhbmllbG1hbGwvU2l0ZXMvaHlicmlkL3RydW5rL2Jpbi9pbWFnZXMvcG1fYXR0YWNobWVudHMvIjtzOjIzOiJwcnZfbXNnX21heF9hdHRhY2htZW50cyI7czoxOiIzIjtzOjIyOiJwcnZfbXNnX2F0dGFjaF9tYXhzaXplIjtzOjM6IjI1MCI7czoyMDoicHJ2X21zZ19hdHRhY2hfdG90YWwiO3M6MzoiMTAwIjtzOjE5OiJwcnZfbXNnX2h0bWxfZm9ybWF0IjtzOjQ6InNhZmUiO3M6MTg6InBydl9tc2dfYXV0b19saW5rcyI7czoxOiJ5IjtzOjE3OiJwcnZfbXNnX21heF9jaGFycyI7czo0OiI2MDAwIjtzOjE5OiJtZW1iZXJsaXN0X29yZGVyX2J5IjtzOjExOiJ0b3RhbF9wb3N0cyI7czoyMToibWVtYmVybGlzdF9zb3J0X29yZGVyIjtzOjQ6ImRlc2MiO3M6MjA6Im1lbWJlcmxpc3Rfcm93X2xpbWl0IjtzOjI6IjIwIjt9', 'YTo2OntzOjExOiJzdHJpY3RfdXJscyI7czoxOiJ5IjtzOjg6InNpdGVfNDA0IjtzOjA6IiI7czoxOToic2F2ZV90bXBsX3JldmlzaW9ucyI7czoxOiJ5IjtzOjE4OiJtYXhfdG1wbF9yZXZpc2lvbnMiO3M6MToiNSI7czoxNToic2F2ZV90bXBsX2ZpbGVzIjtzOjE6InkiO3M6MTg6InRtcGxfZmlsZV9iYXNlcGF0aCI7czo1NDoiL1VzZXJzL2hhbWJvZGV2ZWxvcG1lbnQvU2l0ZXMvZGFubWFsbC9hc3NldHMvdGVtcGxhdGVzIjt9', 'YTo5OntzOjIxOiJpbWFnZV9yZXNpemVfcHJvdG9jb2wiO3M6MzoiZ2QyIjtzOjE4OiJpbWFnZV9saWJyYXJ5X3BhdGgiO3M6MDoiIjtzOjE2OiJ0aHVtYm5haWxfcHJlZml4IjtzOjU6InRodW1iIjtzOjE0OiJ3b3JkX3NlcGFyYXRvciI7czo0OiJkYXNoIjtzOjE3OiJ1c2VfY2F0ZWdvcnlfbmFtZSI7czoxOiJuIjtzOjIyOiJyZXNlcnZlZF9jYXRlZ29yeV93b3JkIjtzOjg6ImNhdGVnb3J5IjtzOjIzOiJhdXRvX2NvbnZlcnRfaGlnaF9hc2NpaSI7czoxOiJuIjtzOjIyOiJuZXdfcG9zdHNfY2xlYXJfY2FjaGVzIjtzOjE6InkiO3M6MjM6ImF1dG9fYXNzaWduX2NhdF9wYXJlbnRzIjtzOjE6InkiO30=', 'YTo0OntzOjc6ImVtYWlsZWQiO2E6MDp7fXM6NTk6Ii9Vc2Vycy9kYW5pZWxtYWxsL1NpdGVzL2h5YnJpZC9icmFuY2hlcy9lZTIuMS9iaW4vaW5kZXgucGhwIjtzOjMyOiJlODM2YzBlMjliYTUzNjczNjhmODNhODJjMTMzZTJhNSI7czo1MDoiL1VzZXJzL2RhbmllbG1hbGwvU2l0ZXMvaHlicmlkL3RydW5rL2Jpbi9pbmRleC5waHAiO3M6MzI6IjA1OWNiZmVmMzQwZjNmOWIwODIwZThlMzRjZGY4ZDcwIjtzOjQ2OiIvVXNlcnMvZGFuaWVsbWFsbC9TaXRlcy9tYWhvZ2FueS9iaW4vaW5kZXgucGhwIjtzOjMyOiJlODM2YzBlMjliYTUzNjczNjhmODNhODJjMTMzZTJhNSI7fQ==');

-- --------------------------------------------------------

--
-- Table structure for table `exp_snippets`
--

CREATE TABLE `exp_snippets` (
  `snippet_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) NOT NULL,
  `snippet_name` varchar(75) NOT NULL,
  `snippet_contents` text,
  PRIMARY KEY (`snippet_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM DEFAULT CHARSET=latin1 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_snippets`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_specialty_templates`
--

CREATE TABLE `exp_specialty_templates` (
  `template_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `enable_template` char(1) NOT NULL DEFAULT 'y',
  `template_name` varchar(50) NOT NULL,
  `data_title` varchar(80) NOT NULL,
  `template_data` mediumtext NOT NULL,
  PRIMARY KEY (`template_id`),
  KEY `template_name` (`template_name`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=19 ;

--
-- Dumping data for table `exp_specialty_templates`
--

INSERT INTO `exp_specialty_templates` VALUES(1, 1, 'y', 'offline_template', '', '<html>\n<head>\n\n<title>System Offline</title>\n\n<style type="text/css">\n\nbody { \nbackground-color:	#ffffff; \nmargin:				50px; \nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size:			11px;\ncolor:				#000;\nbackground-color:	#fff;\n}\n\na {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nletter-spacing:		.09em;\ntext-decoration:	none;\ncolor:              #330099;\nbackground-color:   transparent;\n}\n  \na:visited {\ncolor:				#330099;\nbackground-color:	transparent;\n}\n\na:hover {\ncolor:				#000;\ntext-decoration:    underline;\nbackground-color:	transparent;\n}\n\n#content  {\nborder:				#999999 1px solid;\npadding:			22px 25px 14px 25px;\n}\n\nh1 {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nfont-size:			14px;\ncolor:				#000;\nmargin-top: 		0;\nmargin-bottom:		14px;\n}\n\np {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		12px;\nmargin-bottom: 		14px;\ncolor: 				#000;\n}\n</style>\n\n</head>\n\n<body>\n\n<div id="content">\n\n<h1>System Offline</h1>\n\n<p>This site is currently offline</p>\n\n</div>\n\n</body>\n\n</html>');
INSERT INTO `exp_specialty_templates` VALUES(2, 1, 'y', 'message_template', '', '<html>\n<head>\n\n<title>{title}</title>\n\n<meta http-equiv=''content-type'' content=''text/html; charset={charset}'' />\n\n{meta_refresh}\n\n<style type="text/css">\n\nbody { \nbackground-color:	#ffffff; \nmargin:				50px; \nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size:			11px;\ncolor:				#000;\nbackground-color:	#fff;\n}\n\na {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nletter-spacing:		.09em;\ntext-decoration:	none;\ncolor:              #330099;\nbackground-color:   transparent;\n}\n  \na:visited {\ncolor:				#330099;\nbackground-color:	transparent;\n}\n\na:active {\ncolor:				#ccc;\nbackground-color:	transparent;\n}\n\na:hover {\ncolor:				#000;\ntext-decoration:    underline;\nbackground-color:	transparent;\n}\n\n#content  {\nborder:				#000 1px solid;\nbackground-color: 	#DEDFE3;\npadding:			22px 25px 14px 25px;\n}\n\nh1 {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-weight:		bold;\nfont-size:			14px;\ncolor:				#000;\nmargin-top: 		0;\nmargin-bottom:		14px;\n}\n\np {\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		12px;\nmargin-bottom: 		14px;\ncolor: 				#000;\n}\n\nul {\nmargin-bottom: 		16px;\n}\n\nli {\nlist-style:			square;\nfont-family:		Verdana, Arial, Tahoma, Trebuchet MS, Sans-serif;\nfont-size: 			12px;\nfont-weight: 		normal;\nmargin-top: 		8px;\nmargin-bottom: 		8px;\ncolor: 				#000;\n}\n\n</style>\n\n</head>\n\n<body>\n\n<div id="content">\n\n<h1>{heading}</h1>\n\n{content}\n\n<p>{link}</p>\n\n</div>\n\n</body>\n\n</html>');
INSERT INTO `exp_specialty_templates` VALUES(3, 1, 'y', 'admin_notify_reg', 'Notification of new member registration', 'The following person has submitted a new member registration: {name}\n\nAt: {site_name}\n\nYour control panel URL: {control_panel_url}');
INSERT INTO `exp_specialty_templates` VALUES(4, 1, 'y', 'admin_notify_entry', 'A new weblog entry has been posted', 'A new entry has been posted in the following weblog:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nPosted by: {name}\nEmail: {email}\n\nTo read the entry please visit: \n{entry_url}\n');
INSERT INTO `exp_specialty_templates` VALUES(5, 1, 'y', 'admin_notify_mailinglist', 'Someone has subscribed to your mailing list', 'A new mailing list subscription has been accepted.\n\nEmail Address: {email}\nMailing List: {mailing_list}');
INSERT INTO `exp_specialty_templates` VALUES(6, 1, 'y', 'admin_notify_comment', 'You have just received a comment', 'You have just received a comment for the following weblog:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nLocated at: \n{comment_url}\n\nPosted by: {name}\nEmail: {email}\nURL: {url}\nLocation: {location}\n\n{comment}');
INSERT INTO `exp_specialty_templates` VALUES(9, 1, 'y', 'mbr_activation_instructions', 'Enclosed is your activation code', 'Thank you for your new member registration.\n\nTo activate your new account, please visit the following URL:\n\n{unwrap}{activation_url}{/unwrap}\n\nThank You!\n\n{site_name}\n\n{site_url}');
INSERT INTO `exp_specialty_templates` VALUES(10, 1, 'y', 'forgot_password_instructions', 'Login information', '{name},\n\nTo reset your password, please go to the following page:\n\n{reset_url}\n\nYour password will be automatically reset, and a new password will be emailed to you.\n\nIf you do not wish to reset your password, ignore this message. It will expire in 24 hours.\n\n{site_name}\n{site_url}');
INSERT INTO `exp_specialty_templates` VALUES(11, 1, 'y', 'reset_password_notification', 'New Login Information', '{name},\n\nHere is your new login information:\n\nUsername: {username}\nPassword: {password}\n\n{site_name}\n{site_url}');
INSERT INTO `exp_specialty_templates` VALUES(12, 1, 'y', 'validated_member_notify', 'Your membership account has been activated', '{name},\n\nYour membership account has been activated and is ready for use.\n\nThank You!\n\n{site_name}\n{site_url}');
INSERT INTO `exp_specialty_templates` VALUES(13, 1, 'y', 'decline_member_validation', 'Your membership account has been declined', '{name},\n\nWe''re sorry but our staff has decided not to validate your membership.\n\n{site_name}\n{site_url}');
INSERT INTO `exp_specialty_templates` VALUES(14, 1, 'y', 'mailinglist_activation_instructions', 'Email Confirmation', 'Thank you for joining the "{mailing_list}" mailing list!\n\nPlease click the link below to confirm your email.\n\nIf you do not want to be added to our list, ignore this email.\n\n{unwrap}{activation_url}{/unwrap}\n\nThank You!\n\n{site_name}');
INSERT INTO `exp_specialty_templates` VALUES(15, 1, 'y', 'comment_notification', 'Someone just responded to your comment', 'Someone just responded to the entry you subscribed to at:\n{channel_name}\n\nThe title of the entry is:\n{entry_title}\n\nYou can see the comment at the following URL:\n{comment_url}\n\n{comment}\n\nTo stop receiving notifications for this comment, click here:\n{notification_removal_url}');
INSERT INTO `exp_specialty_templates` VALUES(17, 1, 'y', 'private_message_notification', 'Someone has sent you a Private Message', '\n{recipient_name},\n\n{sender_name} has just sent you a Private Message titled ''{message_subject}''.\n\nYou can see the Private Message by logging in and viewing your InBox at:\n{site_url}\n\nTo stop receiving notifications of Private Messages, turn the option off in your Email Settings.');
INSERT INTO `exp_specialty_templates` VALUES(18, 1, 'y', 'pm_inbox_full', 'Your private message mailbox is full', '{recipient_name},\n\n{sender_name} has just attempted to send you a Private Message,\nbut your InBox is full, exceeding the maximum of {pm_storage_limit}.\n\nPlease log in and remove unwanted messages from your InBox at:\n{site_url}');

-- --------------------------------------------------------

--
-- Table structure for table `exp_stats`
--

CREATE TABLE `exp_stats` (
  `stat_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `total_members` mediumint(7) NOT NULL DEFAULT '0',
  `recent_member_id` int(10) NOT NULL DEFAULT '0',
  `recent_member` varchar(50) NOT NULL,
  `total_entries` mediumint(8) NOT NULL DEFAULT '0',
  `total_forum_topics` mediumint(8) NOT NULL DEFAULT '0',
  `total_forum_posts` mediumint(8) NOT NULL DEFAULT '0',
  `total_comments` mediumint(8) NOT NULL DEFAULT '0',
  `last_entry_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_forum_post_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_comment_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_visitor_date` int(10) unsigned NOT NULL DEFAULT '0',
  `most_visitors` mediumint(7) NOT NULL DEFAULT '0',
  `most_visitor_date` int(10) unsigned NOT NULL DEFAULT '0',
  `last_cache_clear` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`stat_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

--
-- Dumping data for table `exp_stats`
--

INSERT INTO `exp_stats` VALUES(1, 1, 2, 2, 'Steven Hambleton', 21, 0, 0, 4, 1304508068, 0, 1280402031, 1304510412, 18, 1297168369, 1304682357);

-- --------------------------------------------------------

--
-- Table structure for table `exp_statuses`
--

CREATE TABLE `exp_statuses` (
  `status_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(4) unsigned NOT NULL,
  `status` varchar(50) NOT NULL,
  `status_order` int(3) unsigned NOT NULL,
  `highlight` varchar(30) NOT NULL,
  PRIMARY KEY (`status_id`),
  KEY `group_id` (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

--
-- Dumping data for table `exp_statuses`
--

INSERT INTO `exp_statuses` VALUES(1, 1, 1, 'open', 1, '009933');
INSERT INTO `exp_statuses` VALUES(2, 1, 1, 'closed', 2, '990000');
INSERT INTO `exp_statuses` VALUES(3, 1, 2, 'open', 2, '009933');
INSERT INTO `exp_statuses` VALUES(4, 1, 2, 'closed', 3, '990000');
INSERT INTO `exp_statuses` VALUES(6, 1, 2, 'draft', 1, '');

-- --------------------------------------------------------

--
-- Table structure for table `exp_status_groups`
--

CREATE TABLE `exp_status_groups` (
  `group_id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_name` varchar(50) NOT NULL,
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `exp_status_groups`
--

INSERT INTO `exp_status_groups` VALUES(1, 1, 'Default Status Group');
INSERT INTO `exp_status_groups` VALUES(2, 1, 'article');

-- --------------------------------------------------------

--
-- Table structure for table `exp_status_no_access`
--

CREATE TABLE `exp_status_no_access` (
  `status_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`status_id`,`member_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_status_no_access`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_templates`
--

CREATE TABLE `exp_templates` (
  `template_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_id` int(6) unsigned NOT NULL,
  `template_name` varchar(50) NOT NULL,
  `save_template_file` char(1) NOT NULL DEFAULT 'n',
  `template_type` varchar(16) NOT NULL DEFAULT 'webpage',
  `template_data` mediumtext,
  `template_notes` text,
  `edit_date` int(10) NOT NULL DEFAULT '0',
  `last_author_id` int(10) NOT NULL DEFAULT '0',
  `cache` char(1) NOT NULL DEFAULT 'n',
  `refresh` int(6) unsigned NOT NULL DEFAULT '0',
  `no_auth_bounce` varchar(50) NOT NULL DEFAULT '',
  `enable_http_auth` char(1) NOT NULL DEFAULT 'n',
  `allow_php` char(1) NOT NULL DEFAULT 'n',
  `php_parse_location` char(1) NOT NULL DEFAULT 'o',
  `hits` int(10) unsigned NOT NULL DEFAULT '0',
  PRIMARY KEY (`template_id`),
  KEY `group_id` (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=44 ;

--
-- Dumping data for table `exp_templates`
--

INSERT INTO `exp_templates` VALUES(1, 1, 1, 'index', 'y', 'webpage', '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n\n<div id="blog">\n\n{exp:channel:category_heading channel="{my_channel}"}\n<h2>{category_name}</h2>\n{if category_description}\n<p>{category_description}</p>\n{/if}\n{/exp:channel:category_heading}\n\n\n{exp:channel:entries channel="{my_channel}" orderby="date" sort="desc" limit="15" disable="member_data|trackbacks"}\n\n<div class="entry">\n\n{date_heading}\n<h3 class="date">{entry_date format='' %l, %F %d, %Y ''}</h3>\n{/date_heading}\n\n<h2 class="title">{title}</h2>\n{summary}\n\n{body}\n\n{extended}\n\n<div class="posted">Posted by <a href="{profile_path=member/index}">{author}</a> on {entry_date format=''%m/%d''} at {entry_date format=''%h:%i %A''}\n\n<br />\n\n{categories}\n<a href="{path=site_index}">{category_name}</a> &#8226;\n{/categories}\n\n{if allow_comments}\n({comment_total}) <a href="{url_title_path="{my_template_group}/comments"}">Comments</a> &#8226;\n{/if}\n\n{if allow_trackbacks}\n({trackback_total}) <a href="{trackback_path="{my_template_group}/trackbacks"}">Trackbacks</a> &#8226;\n{/if}\n<a href="{title_permalink={my_template_group}/index}">Permalink</a>\n\n</div>\n\n{paginate}\n\n<div class="paginate">\n\n<span class="pagecount">Page {current_page} of {total_pages} pages</span>  {pagination_links}\n\n</div>\n\n{/paginate}\n\n</div>\n\n{/exp:channel:entries}\n\n</div>\n\n<div id="sidebar">\n\n\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n{exp:channel:calendar switch="calendarToday|calendarCell"}\n\n<table class="calendarBG" border="0" cellpadding="5" cellspacing="1" summary="My Calendar">\n<tr>\n<th class="calendarHeader"><div class="calendarMonthLinks"><a href="{previous_path={my_template_group}/index}">&lt;&lt;</a></div></th>\n<th class="calendarHeader" colspan="5">{date format="%F %Y"}</th>\n<th class="calendarHeader"><div class="calendarMonthLinks"><a class="calendarMonthLinks" href="{next_path={my_template_group}/index}">&gt;&gt;</a></div></th>\n</tr>\n<tr>\n{calendar_heading}\n<td class="calendarDayHeading">{lang:weekday_abrev}</td>\n{/calendar_heading}\n</tr>\n{calendar_rows }\n{row_start}<tr>{/row_start}\n{if entries}<td class=''{switch}'' align=''center''><a href="{day_path={my_template_group}/index}">{day_number}</a></td>{/if}\n{if not_entries}<td class=''{switch}'' align=''center''>{day_number}</td>{/if}\n{if blank}<td class=''calendarBlank''>&nbsp;</td>{/if}\n{row_end}</tr>{/row_end}\n{/calendar_rows}\n</table>\n{/exp:channel:calendar}\n\n\n{exp:search:simple_form search_in="everywhere"}\n<h2 class="sidetitle">Search</h2>\n<p>\n<input type="text" name="keywords" value="" class="input" size="18" maxlength="100" />\n<br />\n<a href="{path=search/index}">Advanced Search</a>\n</p>\n\n<p><input type="submit" value="submit"  class="submit" /></p>\n\n{/exp:search:simple_form}\n\n\n<h2 class="sidetitle">Categories</h2>\n<p>\n{exp:channel:categories channel="{my_channel}" style="nested"}\n<a href="{path={my_template_group}/index}">{category_name}</a>\n{/exp:channel:categories}\n</p>\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n\n\n\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\n<div class="entry">\n<h2 class="sidetitle">Site Statistics</h2>\n\n<p>\nThis page has been viewed {hits} times<br />\nPage rendered in {elapsed_time} seconds<br />\n\n{exp:stats}\nTotal Entries: {total_entries}<br />\nTotal Comments: {total_comments}<br />\nTotal Trackbacks: {total_trackbacks}<br />\nMost Recent Entry: {last_entry_date format="%m/%d/%Y %h:%i %a"}<br />\nMost Recent Comment on:  {last_comment_date format="%m/%d/%Y %h:%i %a"}<br />\nTotal Members: {total_members}<br />\nTotal Logged in members: {total_logged_in}<br />\nTotal guests: {total_guests}<br />\nTotal anonymous users: {total_anon}<br />\nMost Recent Visitor on:  {last_visitor_date format="%m/%d/%Y %h:%i %a"}<br />\nThe most visitors ever was {most_visitors} on  {most_visitor_date format="%m/%d/%Y %h:%i %a"}\n\n{if member_names}\n<p>Current Logged-in Members:&nbsp;\n{member_names  backspace=''6''}\n<a href="{member_path=member/index}">{name}</a>&nbsp;\n{/member_names}\n</p>\n{/if}\n\n{/exp:stats}\n</p>\n\n<p><a href="{path={my_template_group}/referrers}">Referrers</a></p>\n</div>\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n', '', 1279521723, 1, 'n', 0, '', 'n', 'y', 'o', 195);
INSERT INTO `exp_templates` VALUES(2, 1, 1, 'about', 'n', 'webpage', '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n\n<div id="blog">\n<div class="entry">\n\n<h2 class="title">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n</div>\n\n<p><a href="{homepage}">&lt;&lt; Back to main</a></p>\n\n</div>\n\n\n<div id="sidebar">\n\n\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\nThis page has been viewed {hits} times &#8226;\nPage rendered in {elapsed_time} seconds &#8226;\n\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(3, 1, 1, 'archives', 'n', 'webpage', '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n\n<div id="blog">\n<div class="entry">\n{exp:channel:entries orderby="date" sort="desc" limit="100" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n\n{date_heading display="yearly"}\n<h2 class="title">{entry_date format="%Y"}</h2>\n{/date_heading}\n\n{date_heading display="monthly"}\n<h3 class="date">{entry_date format="%F"}</h3>\n{/date_heading}\n\n<ul>\n<li><a href="{title_permalink="{my_template_group}/index"}">{title}</a></li>\n</ul>\n\n{/exp:channel:entries}\n</div>\n\n<p><a href="{homepage}">&lt;&lt; Back to main</a></p>\n\n</div>\n\n\n<div id="sidebar">\n\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\nThis page has been viewed {hits} times &#8226;\nPage rendered in {elapsed_time} seconds &#8226;\n\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(4, 1, 1, 'categories', 'n', 'webpage', '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n\n<div id="blog">\n\n<h2 class="sidetitle">Categories</h2>\n<div class="entry">\n{exp:channel:category_archive channel="{my_channel}"}\n\n{categories}<h4>{category_name}</h4>{/categories}\n\n{entry_titles}<a href="{path={my_template_group}/comments}">{title}</a>{/entry_titles}\n\n{/exp:channel:category_archive}\n</div>\n<p><a href="{homepage}">&lt;&lt; Back to main</a></p>\n\n</div>\n\n\n<div id="sidebar">\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\nThis page has been viewed {hits} times &#8226;\nPage rendered in {elapsed_time} seconds &#8226;\n\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(5, 1, 1, 'comments', 'n', 'webpage', '\n{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n<div id="blog">\n\n{exp:channel:entries limit="1" disable="member_data|trackbacks"}\n<div class="entry">\n<h2 class="title">{title}</h2>\n\n{summary}\n\n{body}\n\n<div class="posted">\nPosted by {url_or_email_as_author} on {entry_date format=''%m/%d''} at {entry_date format=''%h:%i %A''}\n</div>\n</div>\n{/exp:channel:entries}\n\n{exp:comment:entries channel="{my_channel}" limit="25"}\n<div class="entry">\n{comment}\n\n<div class="posted">Posted by {url_or_email_as_author}  &nbsp;on&nbsp; {comment_date format=''%m/%d''} &nbsp;at&nbsp; {comment_date format=''%h:%i %A''}</div>\n\n{paginate}\n<div class="paginate">\n<span class="pagecount">Page {current_page} of {total_pages} pages</span>  {pagination_links}\n</div>\n{/paginate}\n\n</div>\n\n{/exp:comment:entries}\n\n\n<div class="entry">\n{exp:comment:form preview="{my_template_group}/comment_preview"}\n\n{if logged_out}\n<p>\nName:<br />\n<input type="text" name="name" value="{name}" size="50" />\n</p>\n<p>\nEmail:<br />\n<input type="text" name="email" value="{email}" size="50" />\n</p>\n<p>\nLocation:<br />\n<input type="text" name="location" value="{location}" size="50" />\n</p>\n<p>\nURL:<br />\n<input type="text" name="url" value="{url}" size="50" />\n</p>\n\n{/if}\n\n<p>\n<a href="{path={my_template_group}/smileys}" onclick="window.open(this.href, ''_blank'', ''width=400,height=440'');return false;" onkeypress="this.onclick()">Smileys</a>\n</p>\n\n\n<p>\n<textarea name="comment" cols="50" rows="12">{comment}</textarea>\n</p>\n\n{if logged_out}\n<p><input type="checkbox" name="save_info" value="yes" {save_info} /> Remember my personal information</p>\n{/if}\n\n<p><input type="checkbox" name="notify_me" value="yes" {notify_me} /> Notify me of follow-up comments?</p>\n\n{if captcha}\n<p>Submit the word you see below:</p>\n<p>\n{captcha}\n<br />\n<input type="text" name="captcha" value="" size="20" maxlength="20" style="width:140px;" />\n</p>\n{/if}\n\n<input type="submit" name="submit" value="Submit" />\n<input type="submit" name="preview" value="Preview" />\n\n{/exp:comment:form}\n</div>\n\n<div class="center">\n\n{exp:channel:next_entry channel="{my_channel}"}\n<p>Next entry: <a href="{path={my_template_group}/comments}">{title}</a></p>\n{/exp:channel:next_entry}\n\n{exp:channel:prev_entry channel="{my_channel}"}\n<p>Previous entry: <a href="{path={my_template_group}/comments}">{title}</a></p>\n{/exp:channel:prev_entry}\n\n</div>\n\n\n<p><a href="{homepage}">&lt;&lt; Back to main</a></p>\n\n\n</div>\n<div id="sidebar">\n\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n</div>\n</div>\n\n<br class="spacer" />\n<div id="footer">\n\nThis page has been viewed {hits} times &#8226;\nPage rendered in {elapsed_time} seconds &#8226;\n\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(6, 1, 1, 'comment_preview', 'n', 'webpage', '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n<div id="blog">\n\n<div class="entry">\n{exp:comment:preview}\n{comment}\n{/exp:comment:preview}\n</div>\n\n<div class="entry">\n{exp:comment:form}\n\n{if logged_out}\n<p>\nName:<br />\n<input type="text" name="name" value="{name}" size="50" />\n</p>\n<p>\nEmail:<br />\n<input type="text" name="email" value="{email}" size="50" />\n</p>\n<p>\nLocation:<br />\n<input type="text" name="location" value="{location}" size="50" />\n</p>\n<p>\nURL:<br />\n<input type="text" name="url" value="{url}" size="50" />\n</p>\n\n{/if}\n\n<p>\n<a href="{path={my_template_group}/smileys}" onclick="window.open(this.href, ''_blank'', ''width=400,height=440'');return false;" onkeypress="this.onclick()">Smileys</a>\n</p>\n\n<p>\n<textarea name="comment" cols="50" rows="12">{comment}</textarea>\n</p>\n\n{if logged_out}\n<p><input type="checkbox" name="save_info" value="yes" {save_info} /> Remember my personal information</p>\n{/if}\n\n<p><input type="checkbox" name="notify_me" value="yes" {notify_me} /> Notify me of follow-up comments?</p>\n\n{if captcha}\n<p>Submit the word you see below:</p>\n<p>\n{captcha}\n<br />\n<input type="text" name="captcha" value="" size="20" maxlength="20" style="width:140px;" />\n</p>\n{/if}\n\n<input type="submit" name="submit" value="Submit" />\n<input type="submit" name="preview" value="Preview" />\n\n{/exp:comment:form}\n</div>\n\n<p><a href="{homepage}">&lt;&lt; Back to main</a></p>\n</div>\n\n\n<div id="sidebar">\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\nThis page has been viewed {hits} times &#8226;\nPage rendered in {elapsed_time} seconds &#8226;\n\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(7, 1, 1, 'trackbacks', 'n', 'webpage', '{preload_replace:my_channel="default_site"}\n{preload_replace:my_template_group="site"}\n\n<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml">\n\n<head>\n<title>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</title>\n<meta http-equiv="Content-Type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet={my_template_group}/site_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet={my_template_group}/site_css}";</style>\n\n<link rel="alternate" type="application/rss+xml" title="RSS" href="{path={my_template_group}/rss_2.0}" />\n<link rel="alternate" type="application/atom+xml" title="Atom" href="{path={my_template_group}/atom}" />\n\n</head>\n\n<body>\n\n<div id="topbar"></div>\n<div class="secondbar"></div>\n\n\n<div id="wrapper">\n<div id="header">\n\n<ul id="navbar">\n  <li id="home"><a href="{homepage}" title="Home">Home</a></li>\n  <li id="about"><a href="{path={my_template_group}/about}" title="About">About</a></li>\n  <li id="archives"><a href="{path={my_template_group}/archives}" title="Archives">Archives</a></li>\n  <li id="contact">{encode="{webmaster_email}" title="Contact"}</li>\n</ul>\n\n<div id="blogtitle"><h1>{exp:channel:info channel="{my_channel}"}{channel_title}{/exp:channel:info}</h1></div>\n<div class="spacer"></div>\n</div>\n<div class="secondbar"></div>\n\n<div class="spacer"></div>\n\n<div id="content">\n\n\n<div id="blog">\n\n<h2 class="title">The trackback URL for this entry is:</h2>\n\n<form action="">\n<input type="text" value="{exp:trackback:url}" size="60" class="input" />\n</form>\n\n\n<h2 class="title">Trackbacks:</h2>\n\n<ol>\n{exp:trackback:entries}\n\n<li><strong>{title}</strong><br /><br />\n\n{content}\n\n<div class="posted">Tracked on: <a href="{trackback_url}">{channel_name}</a> ({trackback_ip}) at {trackback_date format="%Y %m %d %H:%i:%s"}</div></li>\n\n{/exp:trackback:entries}\n</ol>\n<p><a href="{homepage}">&lt;&lt; Back to main</a></p>\n\n</div>\n\n<div id="sidebar">\n\n\n\n<h2 class="sidetitle">About</h2>\n<p>Quote meon an estimate et non interruptus stadium. Sic tempus fugit esperanto hiccup estrogen. Glorious baklava ex librus hup hey ad infinitum. Non sequitur condominium facile et geranium incognito.</p>\n\n\n<h2 class="sidetitle">Monthly Archives</h2>\n<ul>\n{exp:channel:month_links channel="{my_channel}"}\n<li><a href="{path={my_template_group}/index}">{month} {year}</a></li>\n{/exp:channel:month_links}\n<li><a href="{path={my_template_group}/archives}">Complete Archives</a></li>\n<li><a href="{path={my_template_group}/categories}">Category Archives</a></li>\n</ul>\n\n\n<h2 class="sidetitle">Most recent entries</h2>\n<ul>\n{exp:channel:entries orderby="date" sort="desc" limit="15" channel="{my_channel}" dynamic="off" disable="pagination|custom_fields|categories|member_data|trackbacks"}\n<li><a href="{title_permalink={my_template_group}/index}">{title}</a></li>\n{/exp:channel:entries}\n</ul>\n\n\n<h2 class="sidetitle">Syndicate</h2>\n<ul>\n<li><a href="{path={my_template_group}/atom}">Atom</a></li>\n<li><a href="{path={my_template_group}/rss_2.0}">RSS 2.0</a></li>\n\n</ul>\n\n</div>\n</div>\n<br class="spacer" />\n<div id="footer">\n\nThis page has been viewed {hits} times &#8226;\nPage rendered in {elapsed_time} seconds &#8226;\n\n<p><br /><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></p>\n\n</div>\n</div>\n</body>\n</html>\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(8, 1, 1, 'referrers', 'n', 'webpage', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{lang}" lang="{lang}">\n\n<head>\n<meta http-equiv="content-type" content="text/html; charset={charset}" />\n<title>Referrers</title>\n\n<style type="text/css">\n\nbody {\n background-color: #ffffff;\n margin-left: 40px;\n margin-right: 40px;\n margin-top: 30px;\n font-size: 11px;\n font-family: verdana,trebuchet,sans-serif;\n}\nh4 {\n font-size: 14px;\n font-family: verdana,trebuchet,sans-serif;\n}\na:link {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: underline;\n}\na:visited {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: underline;\n}\na:active {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: underline;\n}\na:hover {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: none;\n}\n\n</style>\n</head>\n<body>\n\n<h4>Referrers</h4>\n\n<table border="0" width="100%" cellpadding="6" cellspacing="1">\n<tr>\n<td>From</td>\n<td>To</td>\n<td>IP Address</td>\n<td>Date</td>\n</tr>\n\n{exp:referrer limit="50" popup="yes"}\n<tr class="row">\n<td><div>{ref_from}</div></td>\n<td><div>{ref_to}</div></td>\n<td><div>{ref_ip}</div></td>\n<td><div>{ref_date format="%m/%d/%Y"}</div></td>\n</tr>\n{/exp:referrer}\n\n</table>\n\n</body>\n</html>\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(9, 1, 1, 'smileys', 'n', 'webpage', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{lang}" lang="{lang}">\n<head>\n<meta http-equiv="content-type" content="text/html; charset={charset}" />\n<title>Smileys</title>\n\n<style type="text/css">\n\nbody {\n background-color: #ffffff;\n margin-left: 40px;\n margin-right: 40px;\n margin-top: 30px;\n font-size: 11px;\n font-family: verdana,trebuchet,sans-serif;\n}\na:link {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: underline;\n}\na:visited {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: underline;\n}\na:active {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: underline;\n}\na:hover {\n color: #990000;\n font-size: 11px;\n font-weight: normal;\n text-decoration: none;\n}\n\n</style>\n\n<script language="javascript">\n<!--\n\nfunction add_smiley(smiley)\n{\n    opener.document.getElementById(''comment_form'').comment.value += " " + smiley + " ";\n    opener.window.document.getElementById(''comment_form'').comment.focus();\n    window.close();\n}\n//-->\n</script>\n\n</head>\n<body>\n\n<p>Click on an image to add it to your comment</p>\n\n<table border="0" width="100%" cellpadding="6" cellspacing="1">\n\n{exp:emoticon columns="4"}\n<tr>\n<td><div>{smiley}</div></td>\n</tr>\n{/exp:emoticon}\n\n</table>\n\n</body>\n</html>\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(10, 1, 1, 'site_css', 'n', 'css', 'body\n{\n	margin: 0 auto;\n	padding: 0;\n	color: #333;\n	background: #585756 url("./themes/site_themes/default/bg.gif") repeat;\n	font-size: 80%\n}\n\nh1, h2, h3 {\nfont-family: georgia, times new roman, times, serif;\nletter-spacing: 0.09em;\n}\n\nh4 {\nfont-family: lucida grande, verdana, arial, helvetica, sans-serif;\nmargin-bottom: 4px;\n}\n\np {\nfont-family: times new roman, times, serif;\n}\n\nol {\n	margin-bottom: 10px;\n}\n\n.center {\ntext-align: center;\n}\n\nblockquote {\nfont-family: trebuchet ms, verdana, arial, helvetica, sans-serif;\n}\n\nul {\nlist-style: square;\nmargin-top: 3px;\nmargin-bottom: 3px;\nmargin-left: 1em;\npadding-left: 1em;\n}\n\nimg {\nmargin: 0;\npadding: 0;\nborder: 0;\n}\n\na:link { background-color: transparent; text-decoration: none; color: #663300; }\na:hover { background-color: #663300; text-decoration: none; color: #fff; }\na:visited { background-color: transparent; text-decoration: none; color: #663300; }\n\n#topbar {\nmargin:0 auto;\npadding:0;\nheight: 45px;\nbackground: #FBFAF4;\nborder-top: 8px solid #232863;\nborder-bottom: 1px solid #333;\n}\n\n.secondbar {\nmargin:0 1px 0 0;\npadding:0;\nheight: 1px;\nbackground: #3C3B3A;\nborder-top: 1px solid #31302F;\nborder-bottom: 1px solid #50504E;\n}\n\n#wrapper {\nmargin: -57px auto 0 auto;\npadding-bottom: 10px;\nwidth: 740px;\nborder-top: 8px solid #232863;\nbackground: #585756 url("./themes/site_themes/default/bg.gif") repeat;\ncolor: #333;\n}\n\n#navbar {\nmargin:0 0 0 125px;\npadding:3px 0 3px 0;\nbackground: #FBFAF4;\nfont: 16px lucida grande, verdana, arial, helvetica, sans-serif;\ntext-align: center;\n}\n\n#navbar ul {\nlist-style: none;\n}\n\n#navbar li {\nfloat: left;\npadding: 0 23px 0 23px;\nmargin-right: 5px;\nlist-style: none;\n}\n\n#navbar li a {	display: block; \npadding: 0.75em 0 0.25em; \ntext-transform: uppercase; \ncolor: #000;}\n\n#navbar a:hover {background: transparent;}\n\n#header {\nmargin: 0 0 0 0;\npadding: 0 10px 5px 20px;\nborder-bottom: 1px solid #ccc;\nbackground: #FBFAF4;\nborder-left: 1px solid #333;\nborder-right: 1px solid #333;\nborder-bottom: 1px solid #333;\n}\n\n#blogtitle {\nfont-size: 1.25em;\ncolor: #2F4C12;\nfloat: left;\nmargin: 7px 0 0 0;\npadding: 8px 4px 4px 4px;\nwidth: 700px;\nborder-top: 1px solid #333;\n}\n\n#blogtitle h1 {\nmargin: 0;\npadding-top: 5px;\nfont: 160% Georgia, Times, serif;\nletter-spacing: 0.1em;\ntext-align: left;\n}\n\n#nav {\nfloat: left;\nmargin: 0;\npadding: 0;\nwidth: 350px;\ntext-align: right;\nbackground: transparent;\ncolor: #333;\nfont-size: 70%;\nfont-variant: small-caps;\nletter-spacing: 0.09em;\n}\n\n#content {\nfloat: left;\nmargin: 15px 0 10px 0;\npadding: 10px 10px 0 10px;\nbackground: #FfFfFa;\nborder-left: 1px solid #000;\nborder-top: 1px solid #000;\nborder-right: 1px solid #000;\n}\n\n#blog {\nfloat: left;\nmargin-right: 5px;\npadding: 0 10px 10px 10px;\nwidth: 440px;\ncolor: #333;\ntext-align: left;\n}\n\n.entry {\nmargin-top: 10px;\npadding: 0 10px 10px 10px;\nborder: 1px solid #ccc;\nbackground: #F9F8F2;\ncolor: #333;\n}\n\n#sidebar {\nfloat: left;\nmargin-left: 5px;\npadding: 10px 10px 10px 15px;\nborder: 1px solid #ccc;\nwidth: 219px;\nbackground: #F9F8F2;\ncolor: #333;\ntext-align: left;\n}\n\n#footer {\nmargin: 0;\npadding: 5px 10px;\nborder-top: 1px solid #ccc;\nborder-bottom: 1px solid #ccc;\nbackground: #fff;\ncolor: #333;\nfont-size: 70%;\nletter-spacing: 0.09em;\n}\n\n.date {\nfont-size: 120%;\nbackground: transparent;\ncolor: #000;\n}\n\n.title {\nfont-size: 130%;\nfont-weight: normal;\nbackground: transparent;\ncolor: #336600;\nborder-bottom: 1px solid #ddd;\n}\n\n.posted {\nmargin-bottom: 10px;\nfont: 10px lucida grande, verdana, arial, helvetica, sans-serif;\nbackground: transparent;\ncolor: #666;\n}\n\n.sidetitle {\nmargin: 18px 0 7px 0;\nfont-size: 115%;\nletter-spacing: 0.09em;\nfont-weight: normal;\nbackground: transparent;\ncolor: #666600;\nborder-bottom: 1px dotted #ccc;\n}\n\n.spacer {\nclear: both;\n}\n\n.paginate {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			12px;\n font-weight: 		normal;\n letter-spacing:	.1em;\n padding:			10px 6px 10px 4px;\n margin:			0;\n background-color:	transparent;\n}\n\n.pagecount {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			10px;\n color:				#666;\n font-weight:		normal;\n background-color: transparent;\n}\n\n.calendarBG {\n background-color: #000;\n}\n\n.calendarBlank {\n background-color: #9DB7A7;\n}\n\n.calendarHeader {\n font-weight: bold;\n color: #fff;\n text-align: center;\n background-color: #000;\n}\n\n.calendarMonthLinks {\n font-family:       Arial, Trebuchet MS, Tahoma, Verdana, Sans-serif;\n font-size:         11px;\n font-weight:		bold;\n letter-spacing:	.1em;\n text-decoration:   none;\n color:             #fff;\n background-color:  transparent;\n}\n\n.calendarMonthLinks a {\n color:             #fff;\n text-decoration:   none;\n background-color:  transparent;\n}\n\n.calendarMonthLinks a:visited {\n color:             #fff;\n text-decoration:   none;\n background-color:  transparent;\n}\n\n.calendarMonthLinks a:hover {\n color:             #ccc;\n text-decoration:   underline;\n background-color:  transparent;\n}\n\n.calendarDayHeading {\n font-weight: bold;\n font-size:	11px;\n color: #fff;\n background-color: #195337;\n text-align:  center;\n vertical-align: middle;\n}\n\n.calendarToday {\n font-family:       Arial, Trebuchet MS, Tahoma, Verdana, Sans-serif;\n font-size:         12px;\n font-weight:		bold;\n letter-spacing:	.1em;\n text-decoration:   none;\n text-align:  center;\n vertical-align: middle;\n color:             #000;\n background-color: 	#ccc;\n}\n\n.calendarCell {\n font-family:       Arial, Trebuchet MS, Tahoma, Verdana, Sans-serif;\n font-size:         12px;\n font-weight:		bold;\n letter-spacing:	.1em;\n text-decoration:   none;\n text-align:  center;\n vertical-align: middle;\n color:             #666;\n background-color:  #fff;\n}\n\n.calendarCell a {\n color:             #000;\n text-decoration:   underline;\n background-color:  transparent;\n}\n\n.calendarCell a:visited {\n color:             #000;\n text-decoration:   underline;\n background-color:  transparent;\n}\n\n.calendarCell a:hover {\n color:             #fff;\n text-decoration:   none;\n background-color:  transparent;\n}\n\n.input {\nborder-top:        1px solid #999999;\nborder-left:       1px solid #999999;\nbackground-color:  #fff;\ncolor:             #000;\nfont-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\nfont-size:         11px;\nheight:            1.6em;\npadding:           .3em 0 0 2px;\nmargin-top:        6px;\nmargin-bottom:     3px;\n}\n\n.textarea {\nborder-top:        1px solid #999999;\nborder-left:       1px solid #999999;\nbackground-color:  #fff;\ncolor:             #000;\nfont-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\nfont-size:         11px;\nmargin-top:        3px;\nmargin-bottom:     3px;\n}\n\n.checkbox {\nbackground-color:  transparent;\nmargin:            3px;\npadding:           0;\nborder:            0;\n}\n\n.submit {\nbackground-color:  #fff;\nfont-family:       Arial, Verdana, Sans-serif;\nfont-size:         11px;\nfont-weight:       normal;\nletter-spacing:    .1em;\npadding:           1px 3px 1px 3px;\nmargin-top:        6px;\nmargin-bottom:     4px;\ntext-transform:    uppercase;\ncolor:             #000;\n}\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(11, 1, 1, 'rss_2.0', 'n', 'feed', '{preload_replace:master_channel_name="default_site"}\n{exp:rss:feed channel="{master_channel_name}"}\n\n<?xml version="1.0" encoding="{encoding}"?>\n<rss version="2.0"\n    xmlns:dc="http://purl.org/dc/elements/1.1/"\n    xmlns:sy="http://purl.org/rss/1.0/modules/syndication/"\n    xmlns:admin="http://webns.net/mvcb/"\n    xmlns:rdf="http://www.w3.org/1999/02/22-rdf-syntax-ns#"\n    xmlns:content="http://purl.org/rss/1.0/modules/content/">\n\n    <channel>\n    \n    <title>{exp:xml_encode}{channel_name}{/exp:xml_encode}</title>\n    <link>{channel_url}</link>\n    <description>{channel_description}</description>\n    <dc:language>{channel_language}</dc:language>\n    <dc:creator>{email}</dc:creator>\n    <dc:rights>Copyright {gmt_date format="%Y"}</dc:rights>\n    <dc:date>{gmt_date format="%Y-%m-%dT%H:%i:%s%Q"}</dc:date>\n    <admin:generatorAgent rdf:resource="http://expressionengine.com/" />\n    \n{exp:channel:entries channel="{master_channel_name}" limit="10" rdf="off" dynamic_start="on" disable="member_data|trackbacks"}\n    <item>\n      <title>{exp:xml_encode}{title}{/exp:xml_encode}</title>\n      <link>{title_permalink=site/index}</link>\n      <guid>{title_permalink=site/index}#When:{gmt_entry_date format="%H:%i:%sZ"}</guid>\n      <description>{exp:xml_encode}{summary}{body}{/exp:xml_encode}</description>\n      <dc:subject>{exp:xml_encode}{categories backspace="1"}{category_name}, {/categories}{/exp:xml_encode}</dc:subject>\n      <dc:date>{gmt_entry_date format="%Y-%m-%dT%H:%i:%s%Q"}</dc:date>\n    </item>\n{/exp:channel:entries}\n    \n    </channel>\n</rss>\n\n{/exp:rss:feed}\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(12, 1, 1, 'atom', 'n', 'feed', '{preload_replace:master_channel_name="default_site"}\n{preload_replace:atom_feed_location="site/atom"}\n\n{exp:rss:feed channel="{master_channel_name}"}\n\n<?xml version="1.0" encoding="{encoding}"?>\n<feed xmlns="http://www.w3.org/2005/Atom" xml:lang="{channel_language}">\n\n    <title type="text">{exp:xml_encode}{channel_name}{/exp:xml_encode}</title>\n    <subtitle type="text">{exp:xml_encode}{channel_name}:{channel_description}{/exp:xml_encode}</subtitle>\n    <link rel="alternate" type="text/html" href="{channel_url}" />\n    <link rel="self" type="application/atom+xml" href="{path={atom_feed_location}}" />\n    <updated>{gmt_edit_date format=''%Y-%m-%dT%H:%i:%sZ''}</updated>\n    <rights>Copyright (c) {gmt_date format="%Y"}, {author}</rights>\n    <generator uri="http://expressionengine.com/" version="{version}">ExpressionEngine</generator>\n    <id>tag:{trimmed_url},{gmt_date format="%Y:%m:%d"}</id>\n\n{exp:channel:entries channel="{master_channel_name}" limit="15" rdf="off" dynamic_start="on" disable="member_data|trackbacks"}\n    <entry>\n      <title>{exp:xml_encode}{title}{/exp:xml_encode}</title>\n      <link rel="alternate" type="text/html" href="{url_title_path=site/index}" />\n      <id>tag:{trimmed_url},{gmt_entry_date format="%Y"}:{relative_url}/{channel_id}.{entry_id}</id>\n      <published>{gmt_entry_date format="%Y-%m-%dT%H:%i:%sZ"}</published>\n      <updated>{gmt_edit_date format=''%Y-%m-%dT%H:%i:%sZ''}</updated>\n      <author>\n            <name>{author}</name>\n            <email>{email}</email>\n            {if url}<uri>{url}</uri>{/if}\n      </author>\n{categories}\n      <category term="{exp:xml_encode}{category_name}{/exp:xml_encode}"\n        scheme="{path=site/index}"\n        label="{exp:xml_encode}{category_name}{/exp:xml_encode}" />{/categories}\n      <content type="html"><![CDATA[\n        {body} {extended}\n      ]]></content>\n    </entry>\n{/exp:channel:entries}\n\n</feed>\n\n{/exp:rss:feed}\n', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(13, 1, 2, 'index', 'n', 'webpage', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{lang}" lang="{lang}">\n\n<head>\n<title>{lang:search}</title>\n\n<meta http-equiv="content-type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet=search/search_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet=search/search_css}";</style>\n\n</head>\n<body>\n\n<div id=''pageheader''>\n<div class="heading">{lang:search_engine}</div>\n</div>\n\n<div id="content">\n\n<div class=''breadcrumb''>\n<span class="defaultBold">&nbsp; <a href="{homepage}">{site_name}</a>&nbsp;&#8250;&nbsp;&nbsp;{lang:search}</span>\n</div>\n\n<div class=''outerBorder''>\n<div class=''tablePad''>\n\n{exp:search:advanced_form result_page="search/results" cat_style="nested"}\n\n<table cellpadding=''4'' cellspacing=''6'' border=''0'' width=''100%''>\n<tr>\n<td width="50%">\n\n<fieldset class="fieldset">\n<legend>{lang:search_by_keyword}</legend>\n\n<input type="text" class="input" maxlength="100" size="40" name="keywords" style="width:100%;" />\n\n<div class="default">\n<select name="search_in">\n<option value="titles" selected="selected">{lang:search_in_titles}</option>\n<option value="entries">{lang:search_in_entries}</option>\n<option value="everywhere" >{lang:search_everywhere}</option>\n</select>\n\n</div>\n\n<div class="default">\n<select name="where">\n<option value="exact" selected="selected">{lang:exact_phrase_match}</option>\n<option value="any">{lang:search_any_words}</option>\n<option value="all" >{lang:search_all_words}</option>\n<option value="word" >{lang:search_exact_word}</option>\n</select>\n</div>\n\n</fieldset>\n\n<div class="default"><br /></div>\n\n<table cellpadding=''0'' cellspacing=''0'' border=''0''>\n<tr>\n<td valign="top">\n\n<div class="defaultBold">{lang:weblogs}</div>\n\n<select id="channel_id" name=''channel_id[]'' class=''multiselect'' size=''12'' multiple=''multiple'' onchange=''changemenu(this.selectedIndex);''>\n{channel_names}\n</select>\n\n</td>\n<td valign="top" width="16">&nbsp;</td>\n<td valign="top">\n\n<div class="defaultBold">{lang:categories}</div>\n\n<select name=''cat_id[]'' size=''12''  class=''multiselect'' multiple=''multiple''>\n<option value=''all'' selected="selected">{lang:any_category}</option>\n</select>\n\n</td>\n</tr>\n</table>\n\n\n\n</td><td width="50%" valign="top">\n\n\n<fieldset class="fieldset">\n<legend>{lang:search_by_member_name}</legend>\n\n<input type="text" class="input" maxlength="100" size="40" name="member_name" style="width:100%;" />\n<div class="default"><input type="checkbox" class="checkbox" name="exact_match" value="y"  /> {lang:exact_name_match}</div>\n\n</fieldset>\n\n<div class="default"><br /></div>\n\n\n<fieldset class="fieldset">\n<legend>{lang:search_entries_from}</legend>\n\n<select name="date" style="width:150px">\n<option value="0" selected="selected">{lang:any_date}</option>\n<option value="1" >{lang:today_and}</option>\n<option value="7" >{lang:this_week_and}</option>\n<option value="30" >{lang:one_month_ago_and}</option>\n<option value="90" >{lang:three_months_ago_and}</option>\n<option value="180" >{lang:six_months_ago_and}</option>\n<option value="365" >{lang:one_year_ago_and}</option>\n</select>\n\n<div class="default">\n<input type=''radio'' name=''date_order'' value=''newer'' class=''radio'' checked="checked" />&nbsp;{lang:newer}\n<input type=''radio'' name=''date_order'' value=''older'' class=''radio'' />&nbsp;{lang:older}\n</div>\n\n</fieldset>\n\n<div class="default"><br /></div>\n\n<fieldset class="fieldset">\n<legend>{lang:sort_results_by}</legend>\n\n<select name="orderby">\n<option value="date" >{lang:date}</option>\n<option value="title" >{lang:title}</option>\n<option value="most_comments" >{lang:most_comments}</option>\n<option value="recent_comment" >{lang:recent_comment}</option>\n</select>\n\n<div class="default">\n<input type=''radio'' name=''sort_order'' class="radio" value=''desc'' checked="checked" /> {lang:descending}\n<input type=''radio'' name=''sort_order'' class="radio" value=''asc'' /> {lang:ascending}\n</div>\n</fieldset>\n\n</td>\n</tr>\n</table>\n\n\n<div class=''searchSubmit''>\n\n<input type=''submit'' value=''Search'' class=''submit'' />\n\n</div>\n\n{/exp:search:advanced_form}\n\n<div class=''copyright''><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></div>\n\n\n</div>\n</div>\n</div>\n\n</body>\n</html>', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(14, 1, 2, 'results', 'n', 'webpage', '<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"\n"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">\n<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="{lang}" lang="{lang}">\n\n<head>\n<title>{lang:search}</title>\n\n<meta http-equiv="content-type" content="text/html; charset={charset}" />\n\n<link rel=''stylesheet'' type=''text/css'' media=''all'' href=''{stylesheet=search/search_css}'' />\n<style type=''text/css'' media=''screen''>@import "{stylesheet=search/search_css}";</style>\n\n</head>\n<body>\n\n<div id=''pageheader''>\n<div class="heading">{lang:search_results}</div>\n</div>\n\n<div id="content">\n\n<table class=''breadcrumb'' border=''0'' cellpadding=''0'' cellspacing=''0'' width=''99%''>\n<tr>\n<td><span class="defaultBold">&nbsp; <a href="{homepage}">{site_name}</a>&nbsp;&#8250;&nbsp;&nbsp;<a href="{path=search/index}">{lang:search}</a>&nbsp;&#8250;&nbsp;&nbsp;{lang:search_results}</span></td>\n<td align="center"><span class="defaultBold">{lang:keywords} {exp:search:keywords}</span></td>\n<td align="right"><span class="defaultBold">{lang:total_search_results} {exp:search:total_results}</span></td>\n</tr>\n</table>\n\n<div class=''outerBorder''>\n<div class=''tablePad''>\n\n<table border="0" cellpadding="6" cellspacing="1" width="100%">\n<tr>\n<td class="resultHead">{lang:title}</td>\n<td class="resultHead">{lang:excerpt}</td>\n<td class="resultHead">{lang:author}</td>\n<td class="resultHead">{lang:date}</td>\n<td class="resultHead">{lang:total_comments}</td>\n<td class="resultHead">{lang:recent_comments}</td>\n</tr>\n\n{exp:search:search_results switch="resultRowOne|resultRowTwo"}\n\n<tr>\n<td class="{switch}" width="30%" valign="top"><b><a href="{auto_path}">{title}</a></b></td>\n<td class="{switch}" width="30%" valign="top">{excerpt}</td>\n<td class="{switch}" width="10%" valign="top"><a href="{member_path=member/index}">{author}</a></td>\n<td class="{switch}" width="10%" valign="top">{entry_date format="%m/%d/%y"}</td>\n<td class="{switch}" width="10%" valign="top">{comment_total}</td>\n<td class="{switch}" width="10%" valign="top">{recent_comment_date format="%m/%d/%y"}</td>\n</tr>\n\n{/exp:search:search_results}\n\n</table>\n\n\n{if paginate}\n\n<div class=''paginate''>\n\n<span class=''pagecount''>{page_count}</span>&nbsp; {paginate}\n\n</div>\n\n{/if}\n\n\n</td>\n</tr>\n</table>\n\n<div class=''copyright''><a href="http://expressionengine.com/">Powered by ExpressionEngine</a></div>\n\n</div>\n</div>\n</div>\n\n</body>\n</html>', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(15, 1, 2, 'search_css', 'n', 'css', 'body {\n margin:0;\n padding:0;\n font-family:Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:11px;\n color:#000;\n background-color:#fff;\n}\n\na {\n text-decoration:none; color:#330099; background-color:transparent;\n}\na:visited {\n color:#330099; background-color:transparent;\n}\na:hover {\n color:#000; text-decoration:underline; background-color:transparent;\n}\n\n#pageheader {  \n background-color: #4C5286;\n border-top: 1px solid #fff;\n border-bottom: 1px solid #fff;\n padding:  20px 0 20px 0;\n}\n\n.heading {  \n font-family:		Georgia, Times New Roman, Times, Serif, Arial;\n font-size: 		16px;\n font-weight:		bold;\n letter-spacing:	.05em;\n color:			#fff;\n margin: 			0;\n padding:			0 0 0 28px;\n}\n\n#content {\n left:				0px;\n right:				10px;\n margin:			10px 25px 10px 25px;\n padding:			8px 0 0 0;\n}\n\n.outerBorder {\n border:		1px solid #4B5388;\n}\n\n.header {\n margin:			0 0 14px 0;\n padding:			2px 0 2px 0;\n border:			1px solid #000770;\n background-color:	#797EB8;\n text-align:		center;\n}\n\nh1 {\n font-family:		Georgia, Times New Roman, Times, Serif, Arial;\n font-size: 		20px;\n font-weight:		bold;\n letter-spacing:	.05em;\n color:				#fff;\n margin: 			3px 0 3px 0;\n padding:			0 0 0 10px;\n}\n\np {\n font-family:	Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:		11px;\n font-weight:	normal;\n color:			#000;\n background:	transparent;\n margin: 		6px 0 6px 0;\n}\n\n.searchSubmit {\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n color:             #000;\n text-align: center;\n padding:           6px 10px 6px 6px;\n border-top:        1px solid #4B5388;\n border-bottom:     1px solid #4B5388;\n background-color:  #C6C9CF;\n}\n\n.fieldset {\n border:        1px solid #999;\n padding: 10px;\n}\n\n.breadcrumb {\n margin:			0 0 10px 0;\n background-color:	transparent;\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			10px;\n}\n\n.default, .defaultBold {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			11px;\n color:				#000;\n padding:			3px 0 3px 0;\n background-color:	transparent;\n}\n\n.defaultBold {\n font-weight:		bold;\n}\n\n.paginate {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			12px;\n font-weight: 		normal;\n letter-spacing:	.1em;\n padding:			10px 6px 10px 4px;\n margin:			0;\n background-color:	transparent;\n}\n\n.pagecount {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			10px;\n color:				#666;\n font-weight:		normal;\n background-color: transparent;\n}\n\n.tablePad {\n padding:			3px 3px 5px 3px;\n background-color:	#fff;\n}\n\n.resultRowOne {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:			11px;\n color:				#000;\n padding:           6px 6px 6px 8px;\n background-color:	#DADADD;\n}\n\n.resultRowTwo {\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n color:             #000;\n padding:           6px 6px 6px 8px;\n background-color:  #eee;\n}\n\n.resultHead {\n font-family:		Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size: 		11px;\n font-weight: 		bold;\n color:				#000;\n padding: 			8px 0 8px 8px;\n border-bottom:		1px solid #999;\n background-color:	transparent;\n}\n\n.copyright {\n text-align:        center;\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         9px;\n color:             #999;\n margin-top:        15px;\n margin-bottom:     15px;\n}\n\n\nform {\n margin:            0;\n padding:           0;\n border:            0;\n}\n.hidden {\n margin:            0;\n padding:           0;\n border:            0;\n}\n.input {\n border-top:        2px solid #979AC2;\n border-left:       2px solid #979AC2;\n border-bottom:     1px solid #979AC2;\n border-right:      1px solid #979AC2;\n color:             #333;\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n height:            1.7em;\n padding:           0;\n margin:        	0;\n} \n.textarea {\n border-top:        2px solid #979AC2;\n border-left:       2px solid #979AC2;\n border-bottom:     1px solid #979AC2;\n border-right:      1px solid #979AC2;\n color:             #333;\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n padding:           0;\n margin:        	0;\n}\n.select {\n background-color:  #fff;\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n font-weight:       normal;\n letter-spacing:    .1em;\n color:             #333;\n margin-top:        2px;\n margin-bottom:     2px;\n} \n.multiselect {\n border-top:        2px solid #979AC2;\n border-left:       2px solid #979AC2;\n border-bottom:     1px solid #979AC2;\n border-right:      1px solid #979AC2;\n background-color:  #fff;\n color:             #333;\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n margin-top:        2px;\n margin-top:        2px;\n} \n.radio {\n color:             transparent;\n background-color:  transparent;\n margin-top:        4px;\n margin-bottom:     4px;\n padding:           0;\n border:            0;\n}\n.checkbox {\n background-color:  transparent;\n color:				transparent;\n padding:           0;\n border:            0;\n}\n.submit {\n background-color:  #fff;\n font-family:       Verdana, Geneva, Tahoma, Trebuchet MS, Arial, Sans-serif;\n font-size:         11px;\n font-weight:       normal;\n border-top:		1px solid #989AB6;\n border-left:		1px solid #989AB6;\n border-right:		1px solid #434777;\n border-bottom:		1px solid #434777;\n letter-spacing:    .1em;\n padding:           1px 3px 2px 3px;\n margin:        	0;\n background-color:  #6C73B4;\n color:             #fff;\n}  ', '', 1279046957, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(16, 1, 3, 'index', 'y', 'webpage', '', '', 1279623746, 1, 'n', 0, '', 'n', 'y', 'o', 127);
INSERT INTO `exp_templates` VALUES(17, 1, 4, 'index', 'y', 'webpage', '', '', 1279619149, 1, 'n', 0, '', 'n', 'y', 'o', 111);
INSERT INTO `exp_templates` VALUES(18, 1, 5, 'index', 'y', 'webpage', '', '', 1279619215, 1, 'n', 0, '', 'n', 'y', 'o', 61);
INSERT INTO `exp_templates` VALUES(19, 1, 6, 'index', 'y', 'webpage', '', '', 1279619225, 1, 'n', 0, '', 'n', 'y', 'o', 52);
INSERT INTO `exp_templates` VALUES(20, 1, 4, 'article', 'y', 'webpage', '', '', 1279619156, 1, 'n', 0, '', 'n', 'y', 'o', 108);
INSERT INTO `exp_templates` VALUES(38, 1, 10, '.fusion', 'y', 'webpage', '<div id="fusion">\n    \n    <span class="fusionentire"> <a href="#"><img src="/i/fusion-test.png" width="130" height="100" alt="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." title="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." border="0" class="fusionimg"></a><br><span class="fusiontext"><a href="#">Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple.</a></span></span><div id="beacon_a57a4f432e" style="position: absolute; left: 0px; top: 0px; visibility: hidden;" class="fusionbeacon"></div>\n    <br><a class="powered" href="#" title="Powered by Fusion Ads">Powered by Fusion</a>\n\n    \n\n</div><?php ''/#fusion'' ?>', '', 1280396062, 1, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(37, 1, 14, 'index', 'y', 'webpage', '', NULL, 1279672587, 1, 'n', 0, '', 'n', 'n', 'o', 0);
INSERT INTO `exp_templates` VALUES(26, 1, 10, 'index', 'n', 'webpage', '', NULL, 1279619462, 0, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(27, 1, 10, '.close', 'y', 'webpage', '</body>\n</html>\n', '', 1279619492, 1, 'n', 0, '', 'n', 'y', 'o', 1);
INSERT INTO `exp_templates` VALUES(28, 1, 10, '.cssReference', 'y', 'webpage', '', '', 1279619518, 1, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(29, 1, 10, '.doctype', 'y', 'webpage', '<!DOCTYPE html> \n<html dir="ltr" lang="en-US">\n', '', 1279619937, 1, 'n', 0, '', 'n', 'y', 'o', 1);
INSERT INTO `exp_templates` VALUES(30, 1, 10, '.footer', 'y', 'webpage', '<footer>\n	\n	<ul>\n		<li>&copy; 2005&ndash;<?php echo date(''Y''); ?> Dan Mall.</li>\n		<li><a href="#"><abbr title="HyperText Markup Language">HTML</abbr>5</a></li>\n		<li><a href="#"><abbr title="Cascading Style Sheets">CSS</abbr></a></li>\n		<li>Powered by <a href="http://www.expressionengine.com/">ExpressionEngine</a></li>\n		<li>Hosted by <a href="http://www.mediatemple.net/">MediaTemple</a></li>\n	</ul>\n	\n</footer>', '', 1279619647, 1, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(31, 1, 10, '.header', 'y', 'webpage', '<div id="masthead-wrap">\n    \n    <section id="masthead" role="banner">\n        <header>\n            <h1><a href="/">Daniel Mall</a></h1>\n        </header>\n	\n    	<nav id="nav">\n        	<ul>\n        		<li><a href="/work/">Work</a></li>\n        		<li><a href="/articles/">Articles</a></li>\n        		<li><a href="/about/">About</a></li>\n        		<li><a href="/contact/">Contact</a></li>\n        	</ul>\n        </nav><?php ''/#nav'' ?>\n\n        <?php /* ?>\n    	<form id="site-search" action="#" method="post">\n	\n    		<p>\n    			<label for="site-search-box">Search this site</label>\n    			<input type="text" class="filled" id="site-search-box" value="Semantic Flash" />\n    		</p>\n    		<p class="submit"><input type="image" src="/i/widgets/search.gif" alt="Search" /></p>\n	\n    	</form><?php ''/#site-search'' */ ?>\n\n\n    </section><?php ''/#masthead'' ?>\n    \n\n</div><?php ''/#masthead-wrap'' ?>', '', 1279619664, 1, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(32, 1, 10, '.jsReference', 'y', 'webpage', '', '', 1279619694, 1, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(33, 1, 10, '.meta', 'y', 'webpage', '<meta charset="UTF-8" /> \n    <meta name="author" content="Dan Mall" />\n    <meta name="description" content="" />\n    <meta name="viewport" content="width=800" />\n    <link rel="shortcut icon" type="image/ico" href="/favicon.ico" />', '', 1279619723, 1, 'n', 0, '', 'n', 'y', 'o', 0);
INSERT INTO `exp_templates` VALUES(39, 1, 4, 'preview', 'y', 'webpage', '', '', 1280666646, 1, 'n', 0, '', 'n', 'n', 'o', 3);
INSERT INTO `exp_templates` VALUES(40, 1, 3, 'speaking', 'y', 'webpage', '', '', 1280745117, 1, 'n', 0, '', 'n', 'n', 'o', 22);
INSERT INTO `exp_templates` VALUES(41, 1, 3, 'publications', 'y', 'webpage', '', '', 1280745111, 1, 'n', 0, '', 'n', 'n', 'o', 19);
INSERT INTO `exp_templates` VALUES(42, 1, 3, 'detail', 'y', 'webpage', '{exp:channel:entries channel="work" limit="1" orderby="work-order" sort="desc" status="open" show_future_entries="yes"}\n{embed="_inc/.doctype"}\n<head>\n    <title>&ldquo;{title},&rdquo; work by Dan Mall</title>\n    {embed="_inc/.meta"}\n    {embed="_inc/.cssReference"}\n    {embed="_inc/.jsReference"}   \n    {if work-head != ""}\n    \n    <!-- custom styles and script for this page -->\n    {work-head}\n    {/if}\n</head>\n\n<body id="work">	\n	\n	{embed="_inc/.header"}\n	\n	<div id="work-area-wrap">\n	    \n	    <section id="work-area" class="wrap800">\n	        \n	        <nav class="breadcrumbs">	            \n	            <ul>\n	                <li id="breadcrumbs-home"><a href="/">Home</a></li>\n	                <li id="breadcrumbs-work"><a href="/work/">Work</a></li>\n	            </ul>\n	        </nav><!-- .breadcrumbs -->\n	        \n	        <div id="project-header">\n    	        <hgroup>\n        	        <h1 class="page-title phark">{title}</h1>\n        	        {if work-subtitle}<h2 class="project-subtitle">{work-subtitle}</h2>{/if}\n        	    </hgroup>\n        	    \n        	    <ul id="project-nav" class="no-marker">\n        	        {if work-prev}\n        	        <li class="prev">        	            \n            	        {work-prev}\n        	        </li>\n        	        {/if}\n        	        {if work-next}\n        	        <li class="next">            	        \n            	        {work-next}            	        \n        	        </li>\n        	        {/if}\n        	    </ul><!-- #project-nav -->\n        	    \n    	    </div><!-- #project-header -->\n	        \n	    </section><!-- #work-area -->\n	    \n	    {work-body-file}\n	    \n	    <?php\n\n	        $yeyeyeye = \\{work-body-file\\};\n	        \n	    ?>\n	    \n	    \n	</div><!-- #work-area-wrap -->\n	\n	{/exp:channel:entries}\n	\n	<div class="wrap">\n    	\n    	{embed="_inc/.footer"}\n    	\n    	\n    </div><!-- #wrap -->\n    \n	\n{embed="_inc/.close"}', '', 1301847083, 1, 'n', 0, '', 'n', 'y', 'o', 293);
INSERT INTO `exp_templates` VALUES(43, 1, 10, '.carbon', 'y', 'webpage', '<div id="fusion">\n    \n    <span class="fusionentire"> <a href="#"><img src="/i/fusion-test.png" width="130" height="100" alt="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." title="Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple." border="0" class="fusionimg"></a><br><span class="fusiontext"><a href="#">Introducing (ve) Server - A high-performance, utility VPS from (mt) Media Temple.</a></span></span><div id="beacon_a57a4f432e" style="position: absolute; left: 0px; top: 0px; visibility: hidden;" class="fusionbeacon"></div>\n    <br><a class="powered" href="#" title="Powered by Fusion Ads">Powered by Fusion</a>\n\n    \n\n</div><?php ''/#fusion'' ?>', '', 1299298788, 1, 'n', 0, '', 'n', 'y', 'o', 1);

-- --------------------------------------------------------

--
-- Table structure for table `exp_template_groups`
--

CREATE TABLE `exp_template_groups` (
  `group_id` int(6) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `group_name` varchar(50) NOT NULL,
  `group_order` int(3) unsigned NOT NULL,
  `is_site_default` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`group_id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `exp_template_groups`
--

INSERT INTO `exp_template_groups` VALUES(1, 1, 'danielmall', 1, 'y');
INSERT INTO `exp_template_groups` VALUES(2, 1, 'search', 3, 'n');
INSERT INTO `exp_template_groups` VALUES(3, 1, 'work', 3, 'n');
INSERT INTO `exp_template_groups` VALUES(4, 1, 'articles', 4, 'n');
INSERT INTO `exp_template_groups` VALUES(5, 1, 'about', 5, 'n');
INSERT INTO `exp_template_groups` VALUES(6, 1, 'contact', 6, 'n');
INSERT INTO `exp_template_groups` VALUES(14, 1, '_external', 8, 'n');
INSERT INTO `exp_template_groups` VALUES(10, 1, '_inc', 10, 'n');

-- --------------------------------------------------------

--
-- Table structure for table `exp_template_member_groups`
--

CREATE TABLE `exp_template_member_groups` (
  `group_id` smallint(4) unsigned NOT NULL,
  `template_group_id` mediumint(5) unsigned NOT NULL,
  PRIMARY KEY (`group_id`,`template_group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_template_member_groups`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_template_no_access`
--

CREATE TABLE `exp_template_no_access` (
  `template_id` int(6) unsigned NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`template_id`,`member_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_template_no_access`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_throttle`
--

CREATE TABLE `exp_throttle` (
  `throttle_id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ip_address` varchar(16) NOT NULL DEFAULT '0',
  `last_activity` int(10) unsigned NOT NULL DEFAULT '0',
  `hits` int(10) unsigned NOT NULL,
  `locked_out` char(1) NOT NULL DEFAULT 'n',
  PRIMARY KEY (`throttle_id`),
  KEY `ip_address` (`ip_address`),
  KEY `last_activity` (`last_activity`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

--
-- Dumping data for table `exp_throttle`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_upload_no_access`
--

CREATE TABLE `exp_upload_no_access` (
  `upload_id` int(6) unsigned NOT NULL,
  `upload_loc` varchar(3) NOT NULL,
  `member_group` smallint(4) unsigned NOT NULL,
  PRIMARY KEY (`upload_id`,`member_group`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

--
-- Dumping data for table `exp_upload_no_access`
--


-- --------------------------------------------------------

--
-- Table structure for table `exp_upload_prefs`
--

CREATE TABLE `exp_upload_prefs` (
  `id` int(4) unsigned NOT NULL AUTO_INCREMENT,
  `site_id` int(4) unsigned NOT NULL DEFAULT '1',
  `is_user_blog` char(1) NOT NULL DEFAULT 'n',
  `name` varchar(50) NOT NULL,
  `server_path` varchar(150) NOT NULL DEFAULT '',
  `url` varchar(100) NOT NULL,
  `allowed_types` varchar(3) NOT NULL DEFAULT 'img',
  `max_size` varchar(16) DEFAULT NULL,
  `max_height` varchar(6) DEFAULT NULL,
  `max_width` varchar(6) DEFAULT NULL,
  `properties` varchar(120) DEFAULT NULL,
  `pre_format` varchar(120) DEFAULT NULL,
  `post_format` varchar(120) DEFAULT NULL,
  `file_properties` varchar(120) DEFAULT NULL,
  `file_pre_format` varchar(120) DEFAULT NULL,
  `file_post_format` varchar(120) DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `site_id` (`site_id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

--
-- Dumping data for table `exp_upload_prefs`
--

INSERT INTO `exp_upload_prefs` VALUES(1, 1, 'n', 'Main Upload Directory', '/Users/danielmall/Sites/hybrid/trunk/bin/images/uploads/', 'http://dan.local:8888/images/uploads/', 'all', '', '', '', 'style="border: 0;" alt="image"', '', '', '', '', '');
INSERT INTO `exp_upload_prefs` VALUES(2, 1, 'n', 'Link Images', '/Users/danielmall/Sites/hybrid/branches/ee2.1/bin/i/links/', 'http://dan.local:8888/i/links/', 'all', '', '', '', '', '', '', '', '', '');
